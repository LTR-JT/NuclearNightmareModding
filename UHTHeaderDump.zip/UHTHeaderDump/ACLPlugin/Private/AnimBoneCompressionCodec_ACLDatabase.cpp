#include "AnimBoneCompressionCodec_ACLDatabase.h"

UAnimBoneCompressionCodec_ACLDatabase::UAnimBoneCompressionCodec_ACLDatabase() {
    this->DatabaseAsset = NULL;
}


