#include "AnimBoneCompressionCodec_ACLSafe.h"

UAnimBoneCompressionCodec_ACLSafe::UAnimBoneCompressionCodec_ACLSafe() {
}


