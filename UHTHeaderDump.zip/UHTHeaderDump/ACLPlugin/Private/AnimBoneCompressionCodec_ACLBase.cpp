#include "AnimBoneCompressionCodec_ACLBase.h"

UAnimBoneCompressionCodec_ACLBase::UAnimBoneCompressionCodec_ACLBase() {
}


