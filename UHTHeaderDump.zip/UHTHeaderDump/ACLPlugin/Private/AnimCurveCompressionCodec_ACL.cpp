#include "AnimCurveCompressionCodec_ACL.h"

UAnimCurveCompressionCodec_ACL::UAnimCurveCompressionCodec_ACL() {
}


