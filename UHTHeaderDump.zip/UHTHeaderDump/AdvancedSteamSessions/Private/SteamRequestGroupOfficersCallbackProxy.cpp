#include "SteamRequestGroupOfficersCallbackProxy.h"

USteamRequestGroupOfficersCallbackProxy::USteamRequestGroupOfficersCallbackProxy() {
}

USteamRequestGroupOfficersCallbackProxy* USteamRequestGroupOfficersCallbackProxy::GetSteamGroupOfficerList(UObject* WorldContextObject, FBPUniqueNetId GroupUniqueNetID) {
    return NULL;
}


