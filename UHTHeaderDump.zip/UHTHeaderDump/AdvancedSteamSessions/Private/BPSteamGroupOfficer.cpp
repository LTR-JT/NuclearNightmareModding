#include "BPSteamGroupOfficer.h"

FBPSteamGroupOfficer::FBPSteamGroupOfficer() {
    this->bIsOwner = false;
}

