#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FDefaultGameModuleImpl, AdvancedSteamSessions);
