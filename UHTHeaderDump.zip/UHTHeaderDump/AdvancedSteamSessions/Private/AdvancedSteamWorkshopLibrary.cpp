#include "AdvancedSteamWorkshopLibrary.h"

UAdvancedSteamWorkshopLibrary::UAdvancedSteamWorkshopLibrary() {
}

TArray<FBPSteamWorkshopID> UAdvancedSteamWorkshopLibrary::GetSubscribedWorkshopItems(int32& NumberOfItems) {
    return TArray<FBPSteamWorkshopID>();
}

void UAdvancedSteamWorkshopLibrary::GetNumSubscribedWorkshopItems(int32& NumberOfItems) {
}


