#include "BPSteamGroupInfo.h"

FBPSteamGroupInfo::FBPSteamGroupInfo() {
    this->numOnline = 0;
    this->numInGame = 0;
    this->numChatting = 0;
}

