#pragma once
#include "CoreMinimal.h"
#include "BPSteamWorkshopID.generated.h"

USTRUCT(BlueprintType)
struct FBPSteamWorkshopID {
    GENERATED_BODY()
public:
    ADVANCEDSTEAMSESSIONS_API FBPSteamWorkshopID();
};

