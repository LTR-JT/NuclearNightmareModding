#include "FindFriendSessionCallbackProxy.h"

UFindFriendSessionCallbackProxy::UFindFriendSessionCallbackProxy() {
}

UFindFriendSessionCallbackProxy* UFindFriendSessionCallbackProxy::FindFriendSession(UObject* WorldContextObject, APlayerController* PlayerController, const FBPUniqueNetId& FriendUniqueNetId) {
    return NULL;
}


