#include "GetFriendsCallbackProxy.h"

UGetFriendsCallbackProxy::UGetFriendsCallbackProxy() {
}

UGetFriendsCallbackProxy* UGetFriendsCallbackProxy::GetAndStoreFriendsList(UObject* WorldContextObject, APlayerController* PlayerController) {
    return NULL;
}


