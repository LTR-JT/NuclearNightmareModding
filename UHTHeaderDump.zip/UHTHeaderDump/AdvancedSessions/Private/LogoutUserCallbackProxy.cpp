#include "LogoutUserCallbackProxy.h"

ULogoutUserCallbackProxy::ULogoutUserCallbackProxy() {
}

ULogoutUserCallbackProxy* ULogoutUserCallbackProxy::LogoutUser(UObject* WorldContextObject, APlayerController* PlayerController) {
    return NULL;
}


