#include "UpdateSessionCallbackProxyAdvanced.h"

UUpdateSessionCallbackProxyAdvanced::UUpdateSessionCallbackProxyAdvanced() {
}

UUpdateSessionCallbackProxyAdvanced* UUpdateSessionCallbackProxyAdvanced::UpdateSession(UObject* WorldContextObject, const TArray<FSessionPropertyKeyPair>& ExtraSettings, int32 PublicConnections, int32 PrivateConnections, bool bUseLAN, bool bAllowInvites, bool bAllowJoinInProgress, bool bRefreshOnlineData, bool bIsDedicatedServer, bool bShouldAdvertise) {
    return NULL;
}


