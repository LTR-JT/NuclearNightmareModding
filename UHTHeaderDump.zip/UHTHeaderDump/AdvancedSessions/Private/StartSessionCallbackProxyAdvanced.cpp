#include "StartSessionCallbackProxyAdvanced.h"

UStartSessionCallbackProxyAdvanced::UStartSessionCallbackProxyAdvanced() {
}

UStartSessionCallbackProxyAdvanced* UStartSessionCallbackProxyAdvanced::StartAdvancedSession(UObject* WorldContextObject) {
    return NULL;
}


