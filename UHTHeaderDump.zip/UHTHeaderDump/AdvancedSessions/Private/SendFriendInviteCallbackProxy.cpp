#include "SendFriendInviteCallbackProxy.h"

USendFriendInviteCallbackProxy::USendFriendInviteCallbackProxy() {
}

USendFriendInviteCallbackProxy* USendFriendInviteCallbackProxy::SendFriendInvite(UObject* WorldContextObject, APlayerController* PlayerController, const FBPUniqueNetId& UniqueNetIDInvited) {
    return NULL;
}


