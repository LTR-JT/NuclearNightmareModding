#include "SessionsSearchSetting.h"

FSessionsSearchSetting::FSessionsSearchSetting() {
}

