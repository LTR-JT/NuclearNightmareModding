#include "AdvancedIdentityLibrary.h"

UAdvancedIdentityLibrary::UAdvancedIdentityLibrary() {
}

void UAdvancedIdentityLibrary::SetUserAccountAttribute(const FBPUserOnlineAccount& AccountInfo, const FString& AttributeName, const FString& NewAttributeValue, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetUserID(const FBPUserOnlineAccount& AccountInfo, FBPUniqueNetId& UniqueNetId) {
}

void UAdvancedIdentityLibrary::GetUserAccountRealName(const FBPUserOnlineAccount& AccountInfo, FString& UserName) {
}

void UAdvancedIdentityLibrary::GetUserAccountDisplayName(const FBPUserOnlineAccount& AccountInfo, FString& DisplayName) {
}

void UAdvancedIdentityLibrary::GetUserAccountAuthAttribute(const FBPUserOnlineAccount& AccountInfo, const FString& AttributeName, FString& AuthAttribute, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetUserAccountAttribute(const FBPUserOnlineAccount& AccountInfo, const FString& AttributeName, FString& AttributeValue, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetUserAccountAccessToken(const FBPUserOnlineAccount& AccountInfo, FString& AccessToken) {
}

void UAdvancedIdentityLibrary::GetUserAccount(UObject* WorldContextObject, const FBPUniqueNetId& UniqueNetId, FBPUserOnlineAccount& AccountInfo, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetPlayerNickname(UObject* WorldContextObject, const FBPUniqueNetId& UniqueNetId, FString& PlayerNickname) {
}

void UAdvancedIdentityLibrary::GetPlayerAuthToken(UObject* WorldContextObject, APlayerController* PlayerController, FString& AuthToken, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetLoginStatus(UObject* WorldContextObject, const FBPUniqueNetId& UniqueNetId, EBPLoginStatus& LoginStatus, EBlueprintResultSwitch& Result) {
}

void UAdvancedIdentityLibrary::GetAllUserAccounts(UObject* WorldContextObject, TArray<FBPUserOnlineAccount>& AccountInfos, EBlueprintResultSwitch& Result) {
}


