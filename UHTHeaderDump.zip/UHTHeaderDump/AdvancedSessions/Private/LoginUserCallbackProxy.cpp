#include "LoginUserCallbackProxy.h"

ULoginUserCallbackProxy::ULoginUserCallbackProxy() {
}

ULoginUserCallbackProxy* ULoginUserCallbackProxy::LoginUser(UObject* WorldContextObject, APlayerController* PlayerController, const FString& UserId, const FString& UserToken, const FString& AuthType) {
    return NULL;
}


