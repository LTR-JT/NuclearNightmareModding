#include "GetUserPrivilegeCallbackProxy.h"

UGetUserPrivilegeCallbackProxy::UGetUserPrivilegeCallbackProxy() {
}

UGetUserPrivilegeCallbackProxy* UGetUserPrivilegeCallbackProxy::GetUserPrivilege(UObject* WorldContextObject, const EBPUserPrivileges& PrivilegeToCheck, const FBPUniqueNetId& PlayerUniqueNetID) {
    return NULL;
}


