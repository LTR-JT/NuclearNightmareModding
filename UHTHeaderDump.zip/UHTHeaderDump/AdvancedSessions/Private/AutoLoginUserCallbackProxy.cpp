#include "AutoLoginUserCallbackProxy.h"

UAutoLoginUserCallbackProxy::UAutoLoginUserCallbackProxy() {
}

UAutoLoginUserCallbackProxy* UAutoLoginUserCallbackProxy::AutoLoginUser(UObject* WorldContextObject, int32 LocalUserNum) {
    return NULL;
}


