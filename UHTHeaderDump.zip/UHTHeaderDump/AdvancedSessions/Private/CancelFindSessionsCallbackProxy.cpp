#include "CancelFindSessionsCallbackProxy.h"

UCancelFindSessionsCallbackProxy::UCancelFindSessionsCallbackProxy() {
}

UCancelFindSessionsCallbackProxy* UCancelFindSessionsCallbackProxy::CancelFindSessions(UObject* WorldContextObject, APlayerController* PlayerController) {
    return NULL;
}


