#include "GetRecentPlayersCallbackProxy.h"

UGetRecentPlayersCallbackProxy::UGetRecentPlayersCallbackProxy() {
}

UGetRecentPlayersCallbackProxy* UGetRecentPlayersCallbackProxy::GetAndStoreRecentPlayersList(UObject* WorldContextObject, const FBPUniqueNetId& UniqueNetId) {
    return NULL;
}


