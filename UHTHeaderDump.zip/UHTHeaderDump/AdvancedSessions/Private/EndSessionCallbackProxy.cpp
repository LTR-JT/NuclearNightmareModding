#include "EndSessionCallbackProxy.h"

UEndSessionCallbackProxy::UEndSessionCallbackProxy() {
}

UEndSessionCallbackProxy* UEndSessionCallbackProxy::EndSession(UObject* WorldContextObject, APlayerController* PlayerController) {
    return NULL;
}


