#include "BPOnlineRecentPlayer.h"

FBPOnlineRecentPlayer::FBPOnlineRecentPlayer() {
}

