#include "BPFriendInfo.h"

FBPFriendInfo::FBPFriendInfo() {
    this->OnlineState = EBPOnlinePresenceState::Online;
    this->bIsPlayingSameGame = false;
}

