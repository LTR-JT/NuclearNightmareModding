#include "BPOnlineUser.h"

FBPOnlineUser::FBPOnlineUser() {
}

