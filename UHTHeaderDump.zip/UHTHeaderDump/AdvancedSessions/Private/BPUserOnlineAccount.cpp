#include "BPUserOnlineAccount.h"

FBPUserOnlineAccount::FBPUserOnlineAccount() {
}

