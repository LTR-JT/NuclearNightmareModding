#pragma once
#include "CoreMinimal.h"
#include "SessionsSearchSetting.generated.h"

USTRUCT(BlueprintType)
struct FSessionsSearchSetting {
    GENERATED_BODY()
public:
    ADVANCEDSESSIONS_API FSessionsSearchSetting();
};

