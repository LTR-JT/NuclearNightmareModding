#pragma once
#include "CoreMinimal.h"
#include "BPUniqueNetId.generated.h"

USTRUCT(BlueprintType)
struct FBPUniqueNetId {
    GENERATED_BODY()
public:
    ADVANCEDSESSIONS_API FBPUniqueNetId();
};

