#pragma once
#include "CoreMinimal.h"
#include "SessionPropertyKeyPair.generated.h"

USTRUCT(BlueprintType)
struct FSessionPropertyKeyPair {
    GENERATED_BODY()
public:
    ADVANCEDSESSIONS_API FSessionPropertyKeyPair();
};

