#pragma once
#include "CoreMinimal.h"
#include "BPUserOnlineAccount.generated.h"

USTRUCT(BlueprintType)
struct FBPUserOnlineAccount {
    GENERATED_BODY()
public:
    ADVANCEDSESSIONS_API FBPUserOnlineAccount();
};

