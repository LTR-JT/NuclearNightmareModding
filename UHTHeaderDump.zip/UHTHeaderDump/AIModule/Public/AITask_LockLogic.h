#pragma once
#include "CoreMinimal.h"
#include "AITask.h"
#include "AITask_LockLogic.generated.h"

UCLASS(Blueprintable, MinimalAPI)
class UAITask_LockLogic : public UAITask {
    GENERATED_BODY()
public:
    UAITask_LockLogic();

};

