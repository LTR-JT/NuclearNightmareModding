#pragma once
#include "CoreMinimal.h"
#include "AISenseConfig.h"
#include "AISenseConfig_Team.generated.h"

UCLASS(Blueprintable, EditInlineNew, MinimalAPI)
class UAISenseConfig_Team : public UAISenseConfig {
    GENERATED_BODY()
public:
    UAISenseConfig_Team();

};

