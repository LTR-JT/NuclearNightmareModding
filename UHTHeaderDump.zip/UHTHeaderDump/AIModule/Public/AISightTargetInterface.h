#pragma once
#include "CoreMinimal.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=CoreUObject -ObjectName=Interface -FallbackName=Interface
#include "AISightTargetInterface.generated.h"

UINTERFACE(MinimalAPI)
class UAISightTargetInterface : public UInterface {
    GENERATED_BODY()
};

class IAISightTargetInterface : public IInterface {
    GENERATED_BODY()
public:
};

