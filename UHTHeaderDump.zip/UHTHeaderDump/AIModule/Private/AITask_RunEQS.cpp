#include "AITask_RunEQS.h"

UAITask_RunEQS::UAITask_RunEQS() : UAITask(FObjectInitializer::Get()) {
}

UAITask_RunEQS* UAITask_RunEQS::RunEQS(AAIController* Controller, UEnvQuery* QueryTemplate) {
    return NULL;
}


