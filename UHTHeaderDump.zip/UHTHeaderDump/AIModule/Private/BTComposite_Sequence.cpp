#include "BTComposite_Sequence.h"

UBTComposite_Sequence::UBTComposite_Sequence() {
    this->NodeName = TEXT("Sequence");
}


