#include "EnvQueryItemType_Point.h"

UEnvQueryItemType_Point::UEnvQueryItemType_Point() {
}


