#include "BTDecorator_CompareBBEntries.h"

UBTDecorator_CompareBBEntries::UBTDecorator_CompareBBEntries() {
    this->NodeName = TEXT("Compare Blackboard entries");
    this->Operator = EBlackBoardEntryComparison::Equal;
}


