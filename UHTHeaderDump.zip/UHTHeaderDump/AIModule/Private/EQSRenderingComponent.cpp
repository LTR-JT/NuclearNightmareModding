#include "EQSRenderingComponent.h"

UEQSRenderingComponent::UEQSRenderingComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {
}


