#include "SimpleIndexedHandleBase.h"

FSimpleIndexedHandleBase::FSimpleIndexedHandleBase() {
}

