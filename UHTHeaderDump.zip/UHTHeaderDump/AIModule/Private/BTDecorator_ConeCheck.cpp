#include "BTDecorator_ConeCheck.h"

UBTDecorator_ConeCheck::UBTDecorator_ConeCheck() {
    this->NodeName = TEXT("Cone Check");
    this->ConeHalfAngle = 45.00f;
}


