#include "AISenseEvent.h"

UAISenseEvent::UAISenseEvent() {
}


