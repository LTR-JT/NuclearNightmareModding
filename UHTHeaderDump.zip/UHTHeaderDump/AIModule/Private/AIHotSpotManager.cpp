#include "AIHotSpotManager.h"

UAIHotSpotManager::UAIHotSpotManager() {
}


