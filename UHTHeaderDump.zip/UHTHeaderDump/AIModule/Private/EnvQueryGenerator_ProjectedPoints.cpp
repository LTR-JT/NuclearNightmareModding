#include "EnvQueryGenerator_ProjectedPoints.h"
#include "EnvQueryItemType_Point.h"

UEnvQueryGenerator_ProjectedPoints::UEnvQueryGenerator_ProjectedPoints() {
    this->ItemType = UEnvQueryItemType_Point::StaticClass();
}


