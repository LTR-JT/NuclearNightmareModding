#include "EnvQueryTypes.h"

UEnvQueryTypes::UEnvQueryTypes() {
}


