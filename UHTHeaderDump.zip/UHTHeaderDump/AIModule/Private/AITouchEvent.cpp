#include "AITouchEvent.h"

FAITouchEvent::FAITouchEvent() {
    this->TouchReceiver = NULL;
    this->OtherActor = NULL;
}

