#include "AIDataProviderTypedValue.h"

FAIDataProviderTypedValue::FAIDataProviderTypedValue() {
    this->PropertyType = NULL;
}

