#include "IndexedHandleBase.h"

FIndexedHandleBase::FIndexedHandleBase() {
}

