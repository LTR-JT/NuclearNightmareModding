#include "AISense_Damage.h"

UAISense_Damage::UAISense_Damage() {
}

void UAISense_Damage::ReportDamageEvent(UObject* WorldContextObject, AActor* DamagedActor, AActor* Instigator, float DamageAmount, FVector EventLocation, FVector HitLocation, FName Tag) {
}


