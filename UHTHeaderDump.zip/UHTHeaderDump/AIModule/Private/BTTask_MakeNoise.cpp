#include "BTTask_MakeNoise.h"

UBTTask_MakeNoise::UBTTask_MakeNoise() {
    this->NodeName = TEXT("MakeNoise");
    this->Loudnes = 1.00f;
}


