#include "AISenseConfig_Team.h"

UAISenseConfig_Team::UAISenseConfig_Team() {
}


