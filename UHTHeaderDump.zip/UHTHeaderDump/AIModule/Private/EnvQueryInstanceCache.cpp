#include "EnvQueryInstanceCache.h"

FEnvQueryInstanceCache::FEnvQueryInstanceCache() {
    this->Template = NULL;
}

