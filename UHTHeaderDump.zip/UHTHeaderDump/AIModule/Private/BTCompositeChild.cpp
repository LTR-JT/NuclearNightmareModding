#include "BTCompositeChild.h"

FBTCompositeChild::FBTCompositeChild() {
    this->ChildComposite = NULL;
    this->ChildTask = NULL;
}

