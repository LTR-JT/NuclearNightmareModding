#include "BTTask_BlackboardBase.h"

UBTTask_BlackboardBase::UBTTask_BlackboardBase() {
    this->NodeName = TEXT("BlackboardBase");
}


