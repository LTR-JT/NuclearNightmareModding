#include "AIRequestID.h"

FAIRequestID::FAIRequestID() {
    this->RequestID = 0;
}

