#include "BlackboardKeyType_Int.h"

UBlackboardKeyType_Int::UBlackboardKeyType_Int() {
    this->DefaultValue = 0;
}


