#include "EnvQueryGenerator_PathingGrid.h"

UEnvQueryGenerator_PathingGrid::UEnvQueryGenerator_PathingGrid() {
    this->NavigationFilter = NULL;
}


