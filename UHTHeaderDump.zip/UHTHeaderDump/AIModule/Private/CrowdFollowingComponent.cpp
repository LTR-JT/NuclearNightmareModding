#include "CrowdFollowingComponent.h"

UCrowdFollowingComponent::UCrowdFollowingComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {
}

void UCrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend) {
}


