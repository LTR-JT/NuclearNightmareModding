#include "BTTask_RunBehavior.h"

UBTTask_RunBehavior::UBTTask_RunBehavior() {
    this->NodeName = TEXT("Run Behavior");
    this->BehaviorAsset = NULL;
}


