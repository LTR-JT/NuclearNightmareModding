#include "AIMoveRequest.h"

FAIMoveRequest::FAIMoveRequest() {
}

