#include "AIResource_Logic.h"

UAIResource_Logic::UAIResource_Logic() {
}


