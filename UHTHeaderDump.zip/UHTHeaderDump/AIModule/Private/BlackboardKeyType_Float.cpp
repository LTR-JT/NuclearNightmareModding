#include "BlackboardKeyType_Float.h"

UBlackboardKeyType_Float::UBlackboardKeyType_Float() {
    this->DefaultValue = 0.00f;
}


