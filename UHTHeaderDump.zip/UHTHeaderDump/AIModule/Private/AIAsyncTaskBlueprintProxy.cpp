#include "AIAsyncTaskBlueprintProxy.h"

UAIAsyncTaskBlueprintProxy::UAIAsyncTaskBlueprintProxy() {
}

void UAIAsyncTaskBlueprintProxy::OnMoveCompleted(FAIRequestID RequestID, TEnumAsByte<EPathFollowingResult::Type> MovementResult) {
}


