#include "AIStimulus.h"

FAIStimulus::FAIStimulus() {
    this->Age = 0.00f;
    this->ExpirationAge = 0.00f;
    this->Strength = 0.00f;
    this->bSuccessfullySensed = false;
}

