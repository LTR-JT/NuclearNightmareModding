#include "BlackboardKeyType_Rotator.h"

UBlackboardKeyType_Rotator::UBlackboardKeyType_Rotator() {
    this->bUseDefaultValue = false;
}


