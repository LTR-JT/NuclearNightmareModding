#include "BTDecorator_IsBBEntryOfClass.h"

UBTDecorator_IsBBEntryOfClass::UBTDecorator_IsBBEntryOfClass() {
    this->NodeName = TEXT("Is BlackBoard value of given Class");
    this->TestClass = NULL;
}


