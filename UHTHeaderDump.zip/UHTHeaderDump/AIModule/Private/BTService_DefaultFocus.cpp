#include "BTService_DefaultFocus.h"

UBTService_DefaultFocus::UBTService_DefaultFocus() {
    this->NodeName = TEXT("Set default focus");
    this->FocusPriority = 0;
}


