#include "BTTask_WaitBlackboardTime.h"

UBTTask_WaitBlackboardTime::UBTTask_WaitBlackboardTime() {
    this->NodeName = TEXT("Wait Blackboard Time");
}


