#include "AISightEvent.h"

FAISightEvent::FAISightEvent() {
    this->SeenActor = NULL;
    this->Observer = NULL;
}

