#include "RecastGraphWrapper.h"

FRecastGraphWrapper::FRecastGraphWrapper() {
    this->RecastNavMeshActor = NULL;
}

