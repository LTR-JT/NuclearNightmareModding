#include "EnvQueryItemType_Actor.h"

UEnvQueryItemType_Actor::UEnvQueryItemType_Actor() {
}


