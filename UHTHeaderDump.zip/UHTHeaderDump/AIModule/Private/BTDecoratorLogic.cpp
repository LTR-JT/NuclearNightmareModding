#include "BTDecoratorLogic.h"

FBTDecoratorLogic::FBTDecoratorLogic() {
    this->Operation = EBTDecoratorLogic::Invalid;
    this->Number = 0;
}

