#include "EnvQueryTest_Dot.h"

UEnvQueryTest_Dot::UEnvQueryTest_Dot() {
    this->TestMode = EEnvTestDot::Dot3D;
    this->bAbsoluteValue = false;
}


