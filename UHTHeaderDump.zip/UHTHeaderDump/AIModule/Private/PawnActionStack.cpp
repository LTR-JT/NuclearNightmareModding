#include "PawnActionStack.h"

FPawnActionStack::FPawnActionStack() {
    this->TopAction = NULL;
}

