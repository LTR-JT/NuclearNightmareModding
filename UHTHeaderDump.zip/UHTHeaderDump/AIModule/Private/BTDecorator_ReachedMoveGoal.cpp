#include "BTDecorator_ReachedMoveGoal.h"

UBTDecorator_ReachedMoveGoal::UBTDecorator_ReachedMoveGoal() {
    this->NodeName = TEXT("Reached move goal");
}


