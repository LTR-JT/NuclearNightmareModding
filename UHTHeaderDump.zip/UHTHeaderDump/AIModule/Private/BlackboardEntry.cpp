#include "BlackboardEntry.h"

FBlackboardEntry::FBlackboardEntry() {
    this->KeyType = NULL;
    this->bInstanceSynced = false;
}

