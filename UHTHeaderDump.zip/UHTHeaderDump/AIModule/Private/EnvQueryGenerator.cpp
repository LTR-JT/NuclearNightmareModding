#include "EnvQueryGenerator.h"

UEnvQueryGenerator::UEnvQueryGenerator() {
    this->ItemType = NULL;
    this->bAutoSortTests = true;
}


