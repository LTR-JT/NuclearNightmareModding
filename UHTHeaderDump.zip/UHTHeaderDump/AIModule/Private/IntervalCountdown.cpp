#include "IntervalCountdown.h"

FIntervalCountdown::FIntervalCountdown() {
    this->Interval = 0.00f;
}

