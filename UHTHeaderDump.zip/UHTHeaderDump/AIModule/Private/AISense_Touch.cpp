#include "AISense_Touch.h"

UAISense_Touch::UAISense_Touch() {
}

void UAISense_Touch::ReportTouchEvent(UObject* WorldContextObject, AActor* TouchReceiver, AActor* OtherActor, FVector Location) {
}


