#include "PawnAction_Wait.h"

UDEPRECATED_PawnAction_Wait::UDEPRECATED_PawnAction_Wait() {
    this->TimeToWait = 0.00f;
}


