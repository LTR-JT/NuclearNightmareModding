#include "BTDecorator_ForceSuccess.h"

UBTDecorator_ForceSuccess::UBTDecorator_ForceSuccess() {
    this->NodeName = TEXT("Force Success");
}


