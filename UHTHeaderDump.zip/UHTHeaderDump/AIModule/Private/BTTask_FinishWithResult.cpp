#include "BTTask_FinishWithResult.h"

UBTTask_FinishWithResult::UBTTask_FinishWithResult() {
    this->NodeName = TEXT("FinishWithResult");
    this->Result = EBTNodeResult::Succeeded;
}


