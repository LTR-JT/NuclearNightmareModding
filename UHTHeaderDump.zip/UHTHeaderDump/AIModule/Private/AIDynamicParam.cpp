#include "AIDynamicParam.h"

FAIDynamicParam::FAIDynamicParam() {
    this->ParamType = EAIParamType::Float;
    this->Value = 0.00f;
}

