#include "VisualLoggerExtension.h"

UVisualLoggerExtension::UVisualLoggerExtension() {
}


