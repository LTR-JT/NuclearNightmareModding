#include "AIResource_Movement.h"

UAIResource_Movement::UAIResource_Movement() {
}


