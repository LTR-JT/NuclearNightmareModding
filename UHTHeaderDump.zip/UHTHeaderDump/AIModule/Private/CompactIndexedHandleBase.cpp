#include "CompactIndexedHandleBase.h"

FCompactIndexedHandleBase::FCompactIndexedHandleBase() {
}

