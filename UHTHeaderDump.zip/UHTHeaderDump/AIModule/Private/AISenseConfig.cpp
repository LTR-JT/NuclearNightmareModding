#include "AISenseConfig.h"

UAISenseConfig::UAISenseConfig() {
    this->MaxAge = 0.00f;
    this->bStartsEnabled = true;
}


