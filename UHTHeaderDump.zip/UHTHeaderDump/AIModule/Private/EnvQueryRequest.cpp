#include "EnvQueryRequest.h"

FEnvQueryRequest::FEnvQueryRequest() {
    this->QueryTemplate = NULL;
    this->Owner = NULL;
    this->World = NULL;
}

