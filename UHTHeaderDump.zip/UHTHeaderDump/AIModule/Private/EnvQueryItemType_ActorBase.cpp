#include "EnvQueryItemType_ActorBase.h"

UEnvQueryItemType_ActorBase::UEnvQueryItemType_ActorBase() {
}


