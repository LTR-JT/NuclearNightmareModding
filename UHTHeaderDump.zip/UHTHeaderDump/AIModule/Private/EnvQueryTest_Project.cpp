#include "EnvQueryTest_Project.h"

UEnvQueryTest_Project::UEnvQueryTest_Project() {
    this->FilterType = EEnvTestFilterType::Match;
    this->ScoringEquation = EEnvTestScoreEquation::Constant;
}


