#include "BTTask_RunBehaviorDynamic.h"

UBTTask_RunBehaviorDynamic::UBTTask_RunBehaviorDynamic() {
    this->NodeName = TEXT("Run Behavior Dynamic");
    this->DefaultBehaviorAsset = NULL;
    this->BehaviorAsset = NULL;
}


