#include "AINoiseEvent.h"

FAINoiseEvent::FAINoiseEvent() {
    this->Loudness = 0.00f;
    this->MaxRange = 0.00f;
    this->Instigator = NULL;
}

