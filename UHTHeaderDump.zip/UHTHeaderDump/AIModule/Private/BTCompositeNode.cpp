#include "BTCompositeNode.h"

UBTCompositeNode::UBTCompositeNode() {
    this->NodeName = TEXT("UnknownComposite");
    this->bApplyDecoratorScope = false;
}


