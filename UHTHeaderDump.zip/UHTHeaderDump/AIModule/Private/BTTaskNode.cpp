#include "BTTaskNode.h"

UBTTaskNode::UBTTaskNode() {
    this->bIgnoreRestartSelf = false;
}


