#include "BlackboardKeyType_Bool.h"

UBlackboardKeyType_Bool::UBlackboardKeyType_Bool() {
    this->bDefaultValue = false;
}


