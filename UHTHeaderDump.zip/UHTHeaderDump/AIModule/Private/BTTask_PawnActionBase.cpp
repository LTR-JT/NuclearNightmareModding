#include "BTTask_PawnActionBase.h"

UBTTask_PawnActionBase::UBTTask_PawnActionBase() {
    this->NodeName = TEXT("Action Base");
}


