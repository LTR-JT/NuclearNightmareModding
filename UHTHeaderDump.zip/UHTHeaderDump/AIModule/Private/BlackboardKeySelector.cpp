#include "BlackboardKeySelector.h"

FBlackboardKeySelector::FBlackboardKeySelector() {
    this->SelectedKeyType = NULL;
    this->SelectedKeyID = 0;
    this->bNoneIsAllowedValue = false;
}

