#include "BlackboardKeyType_Name.h"

UBlackboardKeyType_Name::UBlackboardKeyType_Name() {
}


