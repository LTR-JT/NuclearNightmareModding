#include "SequentialIDBase.h"

FSequentialIDBase::FSequentialIDBase() {
    this->Value = 0;
}

