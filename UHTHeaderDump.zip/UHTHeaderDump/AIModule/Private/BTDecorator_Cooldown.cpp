#include "BTDecorator_Cooldown.h"

UBTDecorator_Cooldown::UBTDecorator_Cooldown() {
    this->NodeName = TEXT("Cooldown");
    this->CoolDownTime = 5.00f;
}


