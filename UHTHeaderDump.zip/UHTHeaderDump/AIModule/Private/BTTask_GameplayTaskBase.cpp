#include "BTTask_GameplayTaskBase.h"

UBTTask_GameplayTaskBase::UBTTask_GameplayTaskBase() {
    this->NodeName = TEXT("GameplayTask Base");
    this->bWaitForGameplayTask = true;
}


