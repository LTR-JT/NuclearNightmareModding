#include "EnvQueryTest_Overlap.h"

UEnvQueryTest_Overlap::UEnvQueryTest_Overlap() {
    this->FilterType = EEnvTestFilterType::Match;
    this->ScoringEquation = EEnvTestScoreEquation::Constant;
}


