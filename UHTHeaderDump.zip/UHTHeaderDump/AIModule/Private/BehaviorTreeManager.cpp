#include "BehaviorTreeManager.h"

UBehaviorTreeManager::UBehaviorTreeManager() {
    this->MaxDebuggerSteps = 100;
}


