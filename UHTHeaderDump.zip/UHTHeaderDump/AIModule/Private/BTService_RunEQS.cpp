#include "BTService_RunEQS.h"

UBTService_RunEQS::UBTService_RunEQS() {
    this->NodeName = TEXT("Run EQS query on a regular basis");
    this->bUpdateBBOnFail = true;
}


