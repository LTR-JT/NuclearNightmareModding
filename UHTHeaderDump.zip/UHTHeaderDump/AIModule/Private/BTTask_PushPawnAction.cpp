#include "BTTask_PushPawnAction.h"

UBTTask_PushPawnAction::UBTTask_PushPawnAction() {
    this->NodeName = TEXT("Push PawnAction");
    this->Action = NULL;
}


