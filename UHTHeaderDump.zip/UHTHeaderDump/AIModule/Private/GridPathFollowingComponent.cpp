#include "GridPathFollowingComponent.h"

UGridPathFollowingComponent::UGridPathFollowingComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {
    this->GridManager = NULL;
}


