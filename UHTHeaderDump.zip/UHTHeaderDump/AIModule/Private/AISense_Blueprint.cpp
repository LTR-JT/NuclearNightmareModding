#include "AISense_Blueprint.h"

UAISense_Blueprint::UAISense_Blueprint() {
    this->ListenerDataType = NULL;
}






void UAISense_Blueprint::GetAllListenerComponents(TArray<UAIPerceptionComponent*>& ListenerComponents) const {
}

void UAISense_Blueprint::GetAllListenerActors(TArray<AActor*>& ListenerActors) const {
}


