#include "BTService_BlackboardBase.h"

UBTService_BlackboardBase::UBTService_BlackboardBase() {
    this->NodeName = TEXT("BlackboardBase");
}


