#include "EnvDirection.h"

FEnvDirection::FEnvDirection() {
    this->LineFrom = NULL;
    this->LineTo = NULL;
    this->Rotation = NULL;
    this->DirMode = EEnvDirection::TwoPoints;
}

