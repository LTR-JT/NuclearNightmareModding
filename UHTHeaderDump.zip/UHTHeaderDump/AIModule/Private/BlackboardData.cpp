#include "BlackboardData.h"

UBlackboardData::UBlackboardData() {
    this->Parent = NULL;
    this->bHasSynchronizedKeys = false;
}


