#include "LayersBlueprintLibrary.h"

ULayersBlueprintLibrary::ULayersBlueprintLibrary() {
}

void ULayersBlueprintLibrary::RemoveActorFromLayer(AActor* InActor, const FActorLayer& Layer) {
}

TArray<AActor*> ULayersBlueprintLibrary::GetActors(UObject* WorldContextObject, const FActorLayer& ActorLayer) {
    return TArray<AActor*>();
}

void ULayersBlueprintLibrary::AddActorToLayer(AActor* InActor, const FActorLayer& Layer) {
}


