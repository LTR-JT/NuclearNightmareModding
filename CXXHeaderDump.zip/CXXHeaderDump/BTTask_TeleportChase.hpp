#ifndef UE4SS_SDK_BTTask_TeleportChase_HPP
#define UE4SS_SDK_BTTask_TeleportChase_HPP

class UBTTask_TeleportChase_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_6D8C87F4426E7310216A5E9EAE53D4DE(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_6D8C87F4426E7310216A5E9EAE53D4DE(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_762B6F4A49D67F62ED693381F9C454F3(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_762B6F4A49D67F62ED693381F9C454F3(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_TeleportChase(int32 EntryPoint);
}; // Size: 0xB0

#endif
