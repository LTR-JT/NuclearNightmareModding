#ifndef UE4SS_SDK_Dog_Infected_AI_HPP
#define UE4SS_SDK_Dog_Infected_AI_HPP

class ADog_Infected_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0678 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0680 (size: 0x8)
    class UNiagaraComponent* NS_Pg_Veins_NearestSurface1;                             // 0x0688 (size: 0x8)
    class UNiagaraComponent* NS_Pg_Veins_NearestSurface;                              // 0x0690 (size: 0x8)
    class USkeletalMeshComponent* CharacterMesh2;                                     // 0x0698 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh3;                                      // 0x06A0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh2;                                      // 0x06A8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x06B0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x06B8 (size: 0x8)
    class USkeletalMeshComponent* CharacterMesh1;                                     // 0x06C0 (size: 0x8)
    class UStaticMeshComponent* Door;                                                 // 0x06C8 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x06D0 (size: 0x1)
    char padding_0[0x7];                                                              // 0x06D1 (size: 0x7)
    class ABP_FirstPersonCharacter_C* HuskyOwner;                                     // 0x06D8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Target;                                         // 0x06E0 (size: 0x8)
    bool Attacking?;                                                                  // 0x06E8 (size: 0x1)
    bool dead;                                                                        // 0x06E9 (size: 0x1)
    char padding_1[0x6];                                                              // 0x06EA (size: 0x6)
    class AMusicManager_C* MusicManager;                                              // 0x06F0 (size: 0x8)
    FVector Location;                                                                 // 0x06F8 (size: 0x18)
    bool DeSpawn;                                                                     // 0x0710 (size: 0x1)
    char padding_2[0x7];                                                              // 0x0711 (size: 0x7)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0718 (size: 0x10)

    void OnNotifyEnd_8B2816654A403101F27AD4889D0C0FA9(FName NotifyName);
    void OnNotifyBegin_8B2816654A403101F27AD4889D0C0FA9(FName NotifyName);
    void OnInterrupted_8B2816654A403101F27AD4889D0C0FA9(FName NotifyName);
    void OnBlendOut_8B2816654A403101F27AD4889D0C0FA9(FName NotifyName);
    void OnCompleted_8B2816654A403101F27AD4889D0C0FA9(FName NotifyName);
    void ReceiveTick(float DeltaSeconds);
    void StartAI();
    void ReceivePossessed(class AController* NewController);
    void AttackPlayer();
    void ReceiveBeginPlay();
    void AttackAll();
    void Attack();
    void Shoot(FVector Location, FName bone, bool Fire, bool Pickaxe);
    void ShootAll(FVector Location, FName bone, bool Pickaxe);
    void BndEvt__Dog_Infected_AI_Mesh_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void FlareGunAll(FVector Location, FName Name);
    void BndEvt__Dog_Infected_AI_SkeletalMesh_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Dog_Infected_AI_SkeletalMesh3_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Dog_Infected_AI_SkeletalMesh1_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Dog_Infected_AI_SkeletalMesh2_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void Despawn Logic();
    void DespawnAll();
    void StopAttack();
    void StopAttackRPC();
    void ExecuteUbergraph_Dog_Infected_AI(int32 EntryPoint);
}; // Size: 0x728

#endif
