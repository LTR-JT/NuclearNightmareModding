#ifndef UE4SS_SDK_BTT_MoveToNoiseMAD_HPP
#define UE4SS_SDK_BTT_MoveToNoiseMAD_HPP

class UBTT_MoveToNoiseMAD_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector NoiseLocation;                                             // 0x00B0 (size: 0x28)
    bool FinishExecute?;                                                              // 0x00D8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x00D9 (size: 0x7)
    FBlackboardKeySelector Player;                                                    // 0x00E0 (size: 0x28)

    void OnFail_BD462734428A89FBF029518773273FE5(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_BD462734428A89FBF029518773273FE5(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MoveToNoiseMAD(int32 EntryPoint);
}; // Size: 0x108

#endif
