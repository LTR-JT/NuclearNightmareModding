#ifndef UE4SS_SDK_BTT_ChasePlayer_HPP
#define UE4SS_SDK_BTT_ChasePlayer_HPP

class UBTT_ChasePlayer_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class AStalker_AI_C* As Stalker AI;                                               // 0x00B0 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B8 (size: 0x28)

    void OnFail_541B7E0E49001EE3A7ED108FD9529984(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_541B7E0E49001EE3A7ED108FD9529984(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_C47BEE384796DE541BFEA6AB3CA58561(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_C47BEE384796DE541BFEA6AB3CA58561(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_ChasePlayer(int32 EntryPoint);
}; // Size: 0xE0

#endif
