#ifndef UE4SS_SDK_ControlLabel_HPP
#define UE4SS_SDK_ControlLabel_HPP

class UControlLabel_C : public UUserWidget
{
    class UImage* Image_31;                                                           // 0x02E0 (size: 0x8)
    class UTextBlock* TextBlock_39;                                                   // 0x02E8 (size: 0x8)
    FText Category Name;                                                              // 0x02F0 (size: 0x10)

    FText GetText();
}; // Size: 0x300

#endif
