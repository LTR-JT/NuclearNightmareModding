#ifndef UE4SS_SDK_BTTask_HuskyFoundItem_HPP
#define UE4SS_SDK_BTTask_HuskyFoundItem_HPP

class UBTTask_HuskyFoundItem_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_913D512744D1B65816C9EFA02C7D5206(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_913D512744D1B65816C9EFA02C7D5206(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_HuskyFoundItem(int32 EntryPoint);
}; // Size: 0xB0

#endif
