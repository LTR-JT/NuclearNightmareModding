#ifndef UE4SS_SDK_Mimic_AI_HPP
#define UE4SS_SDK_Mimic_AI_HPP

class AMimic_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0678 (size: 0x8)
    class UParticleSystemComponent* Fire;                                             // 0x0680 (size: 0x8)
    class UAudioComponent* Creature02_Cue;                                            // 0x0688 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0690 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0698 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x06A0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x06A8 (size: 0x8)
    class USkeletalMeshComponent* Shoes;                                              // 0x06B0 (size: 0x8)
    class USkeletalMeshComponent* Pants;                                              // 0x06B8 (size: 0x8)
    class USkeletalMeshComponent* Jacket;                                             // 0x06C0 (size: 0x8)
    class USkeletalMeshComponent* Head;                                               // 0x06C8 (size: 0x8)
    float Timeline_NewTrack_0_92035FB1410412D6786498B1D2657B55;                       // 0x06D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_92035FB1410412D6786498B1D2657B55; // 0x06D4 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x06D8 (size: 0x8)
    TEnumAsByte<EMimicState::Type> Behavior;                                          // 0x06E0 (size: 0x1)
    class ABP_FirstPersonCharacter_C* CurrentPlayerTarget;                            // 0x06E8 (size: 0x8)
    TEnumAsByte<EMimicAttackState::Type> AttackState;                                 // 0x06F0 (size: 0x1)
    FVector PlayerTargetLocationUndetected;                                           // 0x06F8 (size: 0x18)
    class ABP_FirstPersonCharacter_C* PrecisionTarget;                                // 0x0710 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Found Player2;                                  // 0x0718 (size: 0x8)
    class ABP_FirstPersonCharacter_C* FoundPlayer;                                    // 0x0720 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Target;                                         // 0x0728 (size: 0x8)
    bool ElusiveFighter;                                                              // 0x0730 (size: 0x1)
    bool AttackingPlayer;                                                             // 0x0731 (size: 0x1)
    FRotator OldControlRot;                                                           // 0x0738 (size: 0x18)
    bool HasAttacked;                                                                 // 0x0750 (size: 0x1)
    bool Dead?;                                                                       // 0x0751 (size: 0x1)
    double mimichealth;                                                               // 0x0758 (size: 0x8)
    class UStaticMeshComponent* Door;                                                 // 0x0760 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x0768 (size: 0x1)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0770 (size: 0x10)
    bool DeSpawn;                                                                     // 0x0780 (size: 0x1)

    void CheckPrecisionForAttack(bool& State);
    void SetClothesFromPlayer(class ABP_FirstPersonCharacter_C* Skeletal);
    void FindClosestPlayer(class ABP_FirstPersonCharacter_C*& Char, double& Distance);
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_3C73087C44E34AE1B44F348D75E21803(FName NotifyName);
    void OnNotifyBegin_3C73087C44E34AE1B44F348D75E21803(FName NotifyName);
    void OnInterrupted_3C73087C44E34AE1B44F348D75E21803(FName NotifyName);
    void OnBlendOut_3C73087C44E34AE1B44F348D75E21803(FName NotifyName);
    void OnCompleted_3C73087C44E34AE1B44F348D75E21803(FName NotifyName);
    void OnNotifyEnd_7DAE10574BE0478EEF9A91A590842766(FName NotifyName);
    void OnNotifyBegin_7DAE10574BE0478EEF9A91A590842766(FName NotifyName);
    void OnInterrupted_7DAE10574BE0478EEF9A91A590842766(FName NotifyName);
    void OnBlendOut_7DAE10574BE0478EEF9A91A590842766(FName NotifyName);
    void OnCompleted_7DAE10574BE0478EEF9A91A590842766(FName NotifyName);
    void OnNotifyEnd_2F21922D4DA3F10AE1861ABE2D1899D3(FName NotifyName);
    void OnNotifyBegin_2F21922D4DA3F10AE1861ABE2D1899D3(FName NotifyName);
    void OnInterrupted_2F21922D4DA3F10AE1861ABE2D1899D3(FName NotifyName);
    void OnBlendOut_2F21922D4DA3F10AE1861ABE2D1899D3(FName NotifyName);
    void OnCompleted_2F21922D4DA3F10AE1861ABE2D1899D3(FName NotifyName);
    void OnNotifyEnd_DDE8E52B48E35A5BE5BED1BBD20BE813(FName NotifyName);
    void OnNotifyBegin_DDE8E52B48E35A5BE5BED1BBD20BE813(FName NotifyName);
    void OnInterrupted_DDE8E52B48E35A5BE5BED1BBD20BE813(FName NotifyName);
    void OnBlendOut_DDE8E52B48E35A5BE5BED1BBD20BE813(FName NotifyName);
    void OnCompleted_DDE8E52B48E35A5BE5BED1BBD20BE813(FName NotifyName);
    void OnNotifyEnd_0550199D4BF1EFF9C9D0C0B3CF52D444(FName NotifyName);
    void OnNotifyBegin_0550199D4BF1EFF9C9D0C0B3CF52D444(FName NotifyName);
    void OnInterrupted_0550199D4BF1EFF9C9D0C0B3CF52D444(FName NotifyName);
    void OnBlendOut_0550199D4BF1EFF9C9D0C0B3CF52D444(FName NotifyName);
    void OnCompleted_0550199D4BF1EFF9C9D0C0B3CF52D444(FName NotifyName);
    void OnNotifyEnd_FC8A5E0B4F6314F23523598E8B3F0EC3(FName NotifyName);
    void OnNotifyBegin_FC8A5E0B4F6314F23523598E8B3F0EC3(FName NotifyName);
    void OnInterrupted_FC8A5E0B4F6314F23523598E8B3F0EC3(FName NotifyName);
    void OnBlendOut_FC8A5E0B4F6314F23523598E8B3F0EC3(FName NotifyName);
    void OnCompleted_FC8A5E0B4F6314F23523598E8B3F0EC3(FName NotifyName);
    void OnNotifyEnd_41F07FD84758FE97A991D9BD4DE9CDE6(FName NotifyName);
    void OnNotifyBegin_41F07FD84758FE97A991D9BD4DE9CDE6(FName NotifyName);
    void OnInterrupted_41F07FD84758FE97A991D9BD4DE9CDE6(FName NotifyName);
    void OnBlendOut_41F07FD84758FE97A991D9BD4DE9CDE6(FName NotifyName);
    void OnCompleted_41F07FD84758FE97A991D9BD4DE9CDE6(FName NotifyName);
    void OnNotifyEnd_9138C30E49BE6594289D04B6321FFC31(FName NotifyName);
    void OnNotifyBegin_9138C30E49BE6594289D04B6321FFC31(FName NotifyName);
    void OnInterrupted_9138C30E49BE6594289D04B6321FFC31(FName NotifyName);
    void OnBlendOut_9138C30E49BE6594289D04B6321FFC31(FName NotifyName);
    void OnCompleted_9138C30E49BE6594289D04B6321FFC31(FName NotifyName);
    void OnFailure_6B50D9894844BE30A05E018B5F2653A7();
    void OnSuccess_6B50D9894844BE30A05E018B5F2653A7();
    void OnFailure_3210D2B6453ABD2E7F3962809C129544(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_3210D2B6453ABD2E7F3962809C129544(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void RPCMimic(class ABP_FirstPersonCharacter_C* Character);
    void RPCMimicServer(class ABP_FirstPersonCharacter_C* Character);
    void ReceivePossessed(class AController* NewController);
    void PlaySpawnAnimation();
    void RPCSpawnAnimation();
    void ServiceStart();
    void ReceiveTick(float DeltaSeconds);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void AttackMulti(double Chance, class ABP_FirstPersonCharacter_C* Target);
    void AttackServer(class ABP_FirstPersonCharacter_C* Target);
    void FindNewTarget();
    void DelayedReveal();
    void DeathMulti();
    void DeathSkip();
    void dEATHsEVER();
    void BulletHit(FName BoneName, FVector HitLocation, bool Sniper);
    void BulletHitRPC(FName BoneName, FVector HitLocation, bool Sniper);
    void OpenDoor(class UObject* Target);
    void OpenDoorMulti(class UObject* Target);
    void DeSpawnServer();
    void DeSpawnFully();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_Mimic_AI(int32 EntryPoint);
}; // Size: 0x781

#endif
