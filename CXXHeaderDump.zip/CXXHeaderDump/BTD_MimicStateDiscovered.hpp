#ifndef UE4SS_SDK_BTD_MimicStateDiscovered_HPP
#define UE4SS_SDK_BTD_MimicStateDiscovered_HPP

class UBTD_MimicStateDiscovered_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
