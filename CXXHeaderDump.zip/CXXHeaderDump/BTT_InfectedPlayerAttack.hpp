#ifndef UE4SS_SDK_BTT_InfectedPlayerAttack_HPP
#define UE4SS_SDK_BTT_InfectedPlayerAttack_HPP

class UBTT_InfectedPlayerAttack_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)

    void OnFail_508989A74FCD7B6F1A641984072BD7EE(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_508989A74FCD7B6F1A641984072BD7EE(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_InfectedPlayerAttack(int32 EntryPoint);
}; // Size: 0xD8

#endif
