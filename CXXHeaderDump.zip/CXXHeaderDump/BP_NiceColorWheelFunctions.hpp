#ifndef UE4SS_SDK_BP_NiceColorWheelFunctions_HPP
#define UE4SS_SDK_BP_NiceColorWheelFunctions_HPP

class UBP_NiceColorWheelFunctions_C : public UBlueprintFunctionLibrary
{

    void FindFormattedColorWheelHandleIndex(FString SaveDataString, FString SaveGameID, class UObject* __WorldContext, bool& bFound, int32& Index, FS_HSV& FoundHSV);
    void LoadHSV_OfColorWheelOrValueSlider(FString SaveGameID, class UObject* __WorldContext, bool& bFoundSaveGame, FS_HSV& HSV);
    void SaveHSV_OfColorWheelOrValueSlider(class UBP_NiceColorWheel_SaveGame_C*& SaveGameRef, FString SaveGameID, const FS_HSV& HSV, class UObject* __WorldContext);
    void GetColorByWheelAndSliderRefs(class UWB_ColorWheel_C* ColorWheel, class UWB_Slider_ColorWheelValue_C* Slider, class UObject* __WorldContext, FLinearColor& LinearColor);
}; // Size: 0x28

#endif
