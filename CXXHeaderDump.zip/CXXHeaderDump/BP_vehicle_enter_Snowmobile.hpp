#ifndef UE4SS_SDK_BP_vehicle_enter_Snowmobile_HPP
#define UE4SS_SDK_BP_vehicle_enter_Snowmobile_HPP

class UBP_vehicle_enter_Snowmobile_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    bool bNear_vehicle_?;                                                             // 0x00A8 (size: 0x1)
    bool bUse_vehicle;                                                                // 0x00A9 (size: 0x1)
    class ABP_SnowmobileOld_C* Vehicle_P;                                             // 0x00B0 (size: 0x8)

    void Enter_vehicle(class AController* Controller, class ABP_FirstPersonCharacter_C* Character);
    void Display_text();
    void ExecuteUbergraph_BP_vehicle_enter_Snowmobile(int32 EntryPoint);
}; // Size: 0xB8

#endif
