#ifndef UE4SS_SDK_ChaosVehiclesEngine_HPP
#define UE4SS_SDK_ChaosVehiclesEngine_HPP

class UChaosVehicles : public UObject
{
}; // Size: 0x28

#endif
