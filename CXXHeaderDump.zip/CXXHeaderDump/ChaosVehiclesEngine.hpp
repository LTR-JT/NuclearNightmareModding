#ifndef UE4SS_SDK_ChaosVehiclesEngine_HPP
#define UE4SS_SDK_ChaosVehiclesEngine_HPP

class UChaosVehicles : public UObject
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)
}; // Size: 0x28

#endif
