#ifndef UE4SS_SDK_BP_Slider_HPP
#define UE4SS_SDK_BP_Slider_HPP

class ABP_Slider_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_SliderBase_Cap1;                                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_SliderBase_Cap;                                    // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* base;                                                 // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Slider;                                               // 0x02B0 (size: 0x8)
    class USceneComponent* Scene1;                                                    // 0x02B8 (size: 0x8)
    float Timeline_0_Position_A34D66C54CEBD205FD943AB3CD6B55E1;                       // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_A34D66C54CEBD205FD943AB3CD6B55E1; // 0x02C4 (size: 0x1)
    char padding_0[0x3];                                                              // 0x02C5 (size: 0x3)
    class UTimelineComponent* Timeline_0;                                             // 0x02C8 (size: 0x8)
    FVector Start;                                                                    // 0x02D0 (size: 0x18)
    FVector End;                                                                      // 0x02E8 (size: 0x18)
    bool InUse;                                                                       // 0x0300 (size: 0x1)
    char padding_1[0x7];                                                              // 0x0301 (size: 0x7)
    double Sensetivity;                                                               // 0x0308 (size: 0x8)
    double Value;                                                                     // 0x0310 (size: 0x8)
    double StartValue;                                                                // 0x0318 (size: 0x8)
    bool Vertical;                                                                    // 0x0320 (size: 0x1)
    bool bIsActive;                                                                   // 0x0321 (size: 0x1)
    bool IsHovered;                                                                   // 0x0322 (size: 0x1)
    bool bIsNotClamped;                                                               // 0x0323 (size: 0x1)
    bool bAllowScroll;                                                                // 0x0324 (size: 0x1)
    char padding_2[0x3];                                                              // 0x0325 (size: 0x3)
    class AActor* NewVar_0;                                                           // 0x0328 (size: 0x8)
    double InteractionDistance;                                                       // 0x0330 (size: 0x8)
    class UPrimitiveComponent* NewVar_1;                                              // 0x0338 (size: 0x8)
    class UMaterialInstanceDynamic* SliderBase_MID;                                   // 0x0340 (size: 0x8)
    bool AutoMove;                                                                    // 0x0348 (size: 0x1)
    char padding_3[0x7];                                                              // 0x0349 (size: 0x7)
    double AutoMoveSpeed;                                                             // 0x0350 (size: 0x8)
    bool Flip Numbers;                                                                // 0x0358 (size: 0x1)
    char padding_4[0x7];                                                              // 0x0359 (size: 0x7)
    FVector2D Range;                                                                  // 0x0360 (size: 0x10)
    bool Draw Text Markers;                                                           // 0x0370 (size: 0x1)

    void ActivateScrolling();
    void AllowScrolling(bool Hovered);
    void SetColor(bool Hovered);
    void ChangeNotActive();
    void ChangeActive();
    void OutputValue();
    void UseSlider();
    void UserConstructionScript();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_3(FKey Key);
    void InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_0(FKey Key);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Slider(int32 EntryPoint);
}; // Size: 0x371

#endif
