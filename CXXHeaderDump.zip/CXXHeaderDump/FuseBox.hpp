#ifndef UE4SS_SDK_FuseBox_HPP
#define UE4SS_SDK_FuseBox_HPP

class AFuseBox_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_18;                                           // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_17;                                           // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_16;                                           // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_15;                                           // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_14;                                           // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_13;                                           // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_12;                                           // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_11;                                           // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02E0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E8 (size: 0x8)
    float Timeline_0_NewTrack_0_1A6503324FB3549282BD62B0C737F08B;                     // 0x02F0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_1A6503324FB3549282BD62B0C737F08B; // 0x02F4 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x02F8 (size: 0x8)
    bool PoweredOn;                                                                   // 0x0300 (size: 0x1)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x0308 (size: 0x8)
    class AComputer_Interaction_C* Computer;                                          // 0x0310 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_7050CE9A4B364217E7E16DAECA81BD9C(FName NotifyName);
    void OnNotifyBegin_7050CE9A4B364217E7E16DAECA81BD9C(FName NotifyName);
    void OnInterrupted_7050CE9A4B364217E7E16DAECA81BD9C(FName NotifyName);
    void OnBlendOut_7050CE9A4B364217E7E16DAECA81BD9C(FName NotifyName);
    void OnCompleted_7050CE9A4B364217E7E16DAECA81BD9C(FName NotifyName);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_FuseBox(int32 EntryPoint);
}; // Size: 0x318

#endif
