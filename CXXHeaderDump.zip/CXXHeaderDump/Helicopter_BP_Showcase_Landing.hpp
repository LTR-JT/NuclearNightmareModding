#ifndef UE4SS_SDK_Helicopter_BP_Showcase_Landing_HPP
#define UE4SS_SDK_Helicopter_BP_Showcase_Landing_HPP

class AHelicopter_BP_Showcase_Landing_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* CH-47_Fuselage2;                                      // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* CH-47_Fuselage1;                                      // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* CH-47_Fuselage;                                       // 0x02B0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B8 (size: 0x8)

    void UpdateVisibility();
    void ExecuteUbergraph_Helicopter_BP_Showcase_Landing(int32 EntryPoint);
}; // Size: 0x2C0

#endif
