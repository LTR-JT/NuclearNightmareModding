#ifndef UE4SS_SDK_Drown_Death_HPP
#define UE4SS_SDK_Drown_Death_HPP

class UDrown_Death_C : public UUserWidget
{
    class UImage* Image_37;                                                           // 0x02E0 (size: 0x8)

}; // Size: 0x2E8

#endif
