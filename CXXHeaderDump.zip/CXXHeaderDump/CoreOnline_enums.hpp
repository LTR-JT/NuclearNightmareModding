enum class ECoreOnlineDummy {
    Dummy = 0,
    ECoreOnlineDummy_MAX = 1,
};

