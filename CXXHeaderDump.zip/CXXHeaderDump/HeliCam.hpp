#ifndef UE4SS_SDK_HeliCam_HPP
#define UE4SS_SDK_HeliCam_HPP

class UHeliCam_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UAircraftGuage_C* AircraftGuage;                                            // 0x02E8 (size: 0x8)
    class UImage* Image_23;                                                           // 0x02F0 (size: 0x8)
    class ABP_Helicopter_C* Helicopter;                                               // 0x02F8 (size: 0x8)

    void Construct();
    void ExecuteUbergraph_HeliCam(int32 EntryPoint);
}; // Size: 0x300

#endif
