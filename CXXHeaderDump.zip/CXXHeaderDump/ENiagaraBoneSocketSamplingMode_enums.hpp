namespace ENiagaraBoneSocketSamplingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator5 = 1,
        ENiagaraBoneSocketSamplingMode_MAX = 2,
    };
}

