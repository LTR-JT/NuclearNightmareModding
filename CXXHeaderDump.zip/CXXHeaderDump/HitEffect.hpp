#ifndef UE4SS_SDK_HitEffect_HPP
#define UE4SS_SDK_HitEffect_HPP

class UHitEffect_C : public UAnimNotify
{

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x38

#endif
