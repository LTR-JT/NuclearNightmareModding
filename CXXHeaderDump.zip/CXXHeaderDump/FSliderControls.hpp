#ifndef UE4SS_SDK_FSliderControls_HPP
#define UE4SS_SDK_FSliderControls_HPP

struct FFSliderControls
{
    int32 Priority_15_FA1CD42A42289F6B9EEC2DBA6F9EEC1F;                               // 0x0000 (size: 0x4)
    FString Label_2_58F367ED41E6F6F389B8F2895C4D806A;                                 // 0x0008 (size: 0x10)
    float Default_5_B88F3B3E48B114680562BBB89555AD2D;                                 // 0x0018 (size: 0x4)
    float Min_9_2709555A47E4DB5015F9A18BD80F03FE;                                     // 0x001C (size: 0x4)
    float Max_11_9EF5F355484139B8FDA52EB95295A8BD;                                    // 0x0020 (size: 0x4)

}; // Size: 0x24

#endif
