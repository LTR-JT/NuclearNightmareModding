#ifndef UE4SS_SDK_BP_Sofa_HPP
#define UE4SS_SDK_BP_Sofa_HPP

class ABP_Sofa_C : public AActor
{
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_sofa_side_SM_sofa_side;                            // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_sofa_seatpad_SM_sofa_seatpad;                      // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_sofa_pillow_SM_sofa_pillow;                        // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_sofa_SM_sofa;                                      // 0x02C0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C8 (size: 0x8)

}; // Size: 0x2D0

#endif
