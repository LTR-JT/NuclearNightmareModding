namespace ENiagaraTorusDistributionMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraTorusDistributionMode_MAX = 2,
    };
}

