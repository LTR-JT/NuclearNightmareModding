#ifndef UE4SS_SDK_CreateServer_HPP
#define UE4SS_SDK_CreateServer_HPP

class UCreateServer_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Back;                                                              // 0x02E8 (size: 0x8)
    class UButton* Button_136;                                                        // 0x02F0 (size: 0x8)
    class UButton* Button_140;                                                        // 0x02F8 (size: 0x8)
    class UButton* Button_216;                                                        // 0x0300 (size: 0x8)
    class UCanvasPanel* CanvasPanel_21;                                               // 0x0308 (size: 0x8)
    class UCheckBox* CheckBox;                                                        // 0x0310 (size: 0x8)
    class UCheckBox* CheckBox_1;                                                      // 0x0318 (size: 0x8)
    class UCheckBox* CheckBox_2;                                                      // 0x0320 (size: 0x8)
    class UCheckBox* CheckBox_3;                                                      // 0x0328 (size: 0x8)
    class UCheckBox* CheckBox_4;                                                      // 0x0330 (size: 0x8)
    class UCheckBox* CheckBox_5;                                                      // 0x0338 (size: 0x8)
    class UCheckBox* CheckBox_6;                                                      // 0x0340 (size: 0x8)
    class UCheckBox* CheckBox_7;                                                      // 0x0348 (size: 0x8)
    class UCheckBox* CheckBox_8;                                                      // 0x0350 (size: 0x8)
    class UCheckBox* CheckBox_9;                                                      // 0x0358 (size: 0x8)
    class UCheckBox* CheckBox_10;                                                     // 0x0360 (size: 0x8)
    class UCheckBox* CheckBox_11;                                                     // 0x0368 (size: 0x8)
    class UButton* Create;                                                            // 0x0370 (size: 0x8)
    class UButton* Create_3;                                                          // 0x0378 (size: 0x8)
    class UEditableText* EditableText_0;                                              // 0x0380 (size: 0x8)
    class UImage* Image;                                                              // 0x0388 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0390 (size: 0x8)
    class UImage* Image_62;                                                           // 0x0398 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox;                                    // 0x03A0 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_1;                                  // 0x03A8 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_2;                                  // 0x03B0 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_3;                                  // 0x03B8 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_4;                                  // 0x03C0 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_5;                                  // 0x03C8 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox_6;                                  // 0x03D0 (size: 0x8)
    class UOverlay* Overlay_0;                                                        // 0x03D8 (size: 0x8)
    class UTextBlock* TextBlock_4;                                                    // 0x03E0 (size: 0x8)
    class UTextBlock* TextBlock_13;                                                   // 0x03E8 (size: 0x8)
    class UTextBlock* TextBlock_15;                                                   // 0x03F0 (size: 0x8)
    class UTextBlock* TextBlock_16;                                                   // 0x03F8 (size: 0x8)
    class UTextBlock* TextBlock_17;                                                   // 0x0400 (size: 0x8)
    class UTextBlock* TextBlock_18;                                                   // 0x0408 (size: 0x8)
    class UTextBlock* TextBlock_19;                                                   // 0x0410 (size: 0x8)
    class UTextBlock* TextBlock_20;                                                   // 0x0418 (size: 0x8)
    class UTextBlock* TextBlock_21;                                                   // 0x0420 (size: 0x8)
    class UTextBlock* TextBlock_22;                                                   // 0x0428 (size: 0x8)
    class UTextBlock* TextBlock_23;                                                   // 0x0430 (size: 0x8)
    class UMainMenu_C* MainMenuHud;                                                   // 0x0438 (size: 0x8)
    class UBP_GameInstance_C* GameInstance;                                           // 0x0440 (size: 0x8)
    bool FriendsOnly;                                                                 // 0x0448 (size: 0x1)
    bool FriendlyFire;                                                                // 0x0449 (size: 0x1)
    bool Lan;                                                                         // 0x044A (size: 0x1)
    bool Team Spawn;                                                                  // 0x044B (size: 0x1)
    TEnumAsByte<EDiffculty::Type> Diffculty;                                          // 0x044C (size: 0x1)
    TEnumAsByte<EDayNightCycle::Type> Day Night Cycle;                                // 0x044D (size: 0x1)
    TEnumAsByte<EItemSpawnProbability::Type> Frequency;                               // 0x044E (size: 0x1)
    TEnumAsByte<ENukeTimer::Type> NukeTimer;                                          // 0x044F (size: 0x1)
    bool EnemyDaytime?;                                                               // 0x0450 (size: 0x1)
    TEnumAsByte<EDiffculty::Type> Minium Classified;                                  // 0x0451 (size: 0x1)
    bool PlayableEnemy;                                                               // 0x0452 (size: 0x1)
    char padding_0[0x5];                                                              // 0x0453 (size: 0x5)
    FString Selected Option;                                                          // 0x0458 (size: 0x10)
    int32 Lobby Minutes;                                                              // 0x0468 (size: 0x4)
    int32 Lobby Seconds;                                                              // 0x046C (size: 0x4)
    bool AirbornInfections;                                                           // 0x0470 (size: 0x1)
    bool NeverSpawnPlayableEnemy;                                                     // 0x0471 (size: 0x1)
    bool DisableReinforcemnt;                                                         // 0x0472 (size: 0x1)
    bool DogInfectionFromMass;                                                        // 0x0473 (size: 0x1)
    bool Radio;                                                                       // 0x0474 (size: 0x1)
    bool DisableWorm;                                                                 // 0x0475 (size: 0x1)
    bool DisableTripMines;                                                            // 0x0476 (size: 0x1)
    bool DisableInfectionNotifies;                                                    // 0x0477 (size: 0x1)
    bool DisableLeeches;                                                              // 0x0478 (size: 0x1)

    ECheckBoxState GetCheckedState_12();
    ECheckBoxState GetCheckedState_11();
    ECheckBoxState GetCheckedState_10();
    ECheckBoxState GetCheckedState_9();
    ECheckBoxState GetCheckedState_8();
    ECheckBoxState GetCheckedState_7();
    ECheckBoxState GetCheckedState_6();
    ECheckBoxState GetCheckedState_5();
    ECheckBoxState GetCheckedState_4();
    ECheckBoxState GetCheckedState_3();
    ECheckBoxState GetCheckedState_2();
    ECheckBoxState GetCheckedState_1();
    ECheckBoxState GetCheckedState_0();
    ECheckBoxState GetCheckedState();
    void BndEvt__CreateServer_Back_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__CreateServer_Create_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature();
    void FailedToCreate();
    void ExitMessage();
    void BndEvt__CreateServer_CheckBox_K2Node_ComponentBoundEvent_4_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_Create_3_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__CreateServer_Button_140_K2Node_ComponentBoundEvent_11_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__CreateServer_Button_216_K2Node_ComponentBoundEvent_12_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__CreateServer_CheckBox_3_K2Node_ComponentBoundEvent_14_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_MultipleSelectBox_6_K2Node_ComponentBoundEvent_5_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_MultipleSelectBox_K2Node_ComponentBoundEvent_16_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_MultipleSelectBox_1_K2Node_ComponentBoundEvent_17_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_MultipleSelectBox_2_K2Node_ComponentBoundEvent_18_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_MultipleSelectBox_3_K2Node_ComponentBoundEvent_19_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_MultipleSelectBox_4_K2Node_ComponentBoundEvent_20_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_CheckBox_1_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_MultipleSelectBox_5_K2Node_ComponentBoundEvent_1_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void BndEvt__CreateServer_CheckBox_2_K2Node_ComponentBoundEvent_6_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_4_K2Node_ComponentBoundEvent_7_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_5_K2Node_ComponentBoundEvent_8_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_6_K2Node_ComponentBoundEvent_9_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_7_K2Node_ComponentBoundEvent_13_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_8_K2Node_ComponentBoundEvent_15_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_9_K2Node_ComponentBoundEvent_21_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_10_K2Node_ComponentBoundEvent_22_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void BndEvt__CreateServer_CheckBox_11_K2Node_ComponentBoundEvent_23_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked);
    void ExecuteUbergraph_CreateServer(int32 EntryPoint);
}; // Size: 0x479

#endif
