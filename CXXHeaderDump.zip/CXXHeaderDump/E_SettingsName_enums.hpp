namespace E_SettingsName {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator3 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator4 = 4,
        NewEnumerator5 = 5,
        NewEnumerator6 = 6,
        NewEnumerator7 = 7,
        E_MAX = 8,
    };
}

