#ifndef UE4SS_SDK_BP_ButtonStyle_Master_HPP
#define UE4SS_SDK_BP_ButtonStyle_Master_HPP

class UBP_ButtonStyle_Master_C : public UCommonButtonStyle
{
}; // Size: 0x7B0

#endif
