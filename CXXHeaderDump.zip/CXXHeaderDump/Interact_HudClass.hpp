#ifndef UE4SS_SDK_Interact_HudClass_HPP
#define UE4SS_SDK_Interact_HudClass_HPP

class AInteract_HudClass_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    bool IsMoveable;                                                                  // 0x02A8 (size: 0x1)
    class AActor* TargetedActor;                                                      // 0x02B0 (size: 0x8)

    void ReceiveBeginPlay();
    void SetMovementProgress(double Progress);
    void SetTargetedActor(class AActor* Targeted);
    void ExecuteUbergraph_Interact_HudClass(int32 EntryPoint);
}; // Size: 0x2B8

#endif
