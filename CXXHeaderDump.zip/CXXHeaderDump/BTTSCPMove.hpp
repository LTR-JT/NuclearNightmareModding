#ifndef UE4SS_SDK_BTTSCPMove_HPP
#define UE4SS_SDK_BTTSCPMove_HPP

class UBTTSCPMove_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_540CC8FC477CF44B760F59B5C5BE5CFA(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_540CC8FC477CF44B760F59B5C5BE5CFA(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_A5364C134FD83CD2283AB3BB35163431(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_A5364C134FD83CD2283AB3BB35163431(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_F204ADF846D1638018FFADA4AC42026C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_F204ADF846D1638018FFADA4AC42026C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_D18937E8429A26F2FBB00DBB735852B4(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_D18937E8429A26F2FBB00DBB735852B4(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_74031B0D4038F5BA6A9637B22B85F895(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_74031B0D4038F5BA6A9637B22B85F895(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_D4BE18CC4176F25C2D7B92B353BDAFFC(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_D4BE18CC4176F25C2D7B92B353BDAFFC(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_C7507BB74E1AF89BBA0CC3B33FBFA2D7(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_C7507BB74E1AF89BBA0CC3B33FBFA2D7(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_1EFEA3CC41A896724395F3BD4BC551E6(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_1EFEA3CC41A896724395F3BD4BC551E6(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_7B4B7D584938A2940D1A2292F1767450(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_7B4B7D584938A2940D1A2292F1767450(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTSCPMove(int32 EntryPoint);
}; // Size: 0xB0

#endif
