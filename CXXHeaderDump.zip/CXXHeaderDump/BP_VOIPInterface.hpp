#ifndef UE4SS_SDK_BP_VOIPInterface_HPP
#define UE4SS_SDK_BP_VOIPInterface_HPP

class IBP_VOIPInterface_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void MSG_AVP_GetWidgetVoice(class UWidgetComponent*& WidgetVoiceRef);
    void MSG_AVP_GetPlayerUsername(bool& Success?, FText& UserName);
}; // Size: 0x28

#endif
