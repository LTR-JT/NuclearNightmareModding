#ifndef UE4SS_SDK_BP_VOIPInterface_HPP
#define UE4SS_SDK_BP_VOIPInterface_HPP

class IBP_VOIPInterface_C : public IInterface
{

    void MSG_AVP_GetWidgetVoice(class UWidgetComponent*& WidgetVoiceRef);
    void MSG_AVP_GetPlayerUsername(bool& Success?, FText& UserName);
}; // Size: 0x28

#endif
