#ifndef UE4SS_SDK_BTT_MoveToMimicDetected_HPP
#define UE4SS_SDK_BTT_MoveToMimicDetected_HPP

class UBTT_MoveToMimicDetected_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_99ED345C4CD212D9D33EBFB786B1407F(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_99ED345C4CD212D9D33EBFB786B1407F(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MoveToMimicDetected(int32 EntryPoint);
}; // Size: 0xB0

#endif
