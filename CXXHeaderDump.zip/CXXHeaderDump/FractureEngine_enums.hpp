enum class EConvexHullSimplifyMethod {
    MeshQSlim = 0,
    AngleTolerance = 1,
    EConvexHullSimplifyMethod_MAX = 2,
};

