#ifndef UE4SS_SDK_BTT_FindRandomLocation_HPP
#define UE4SS_SDK_BTT_FindRandomLocation_HPP

class UBTT_FindRandomLocation_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector LocationKey;                                               // 0x00B0 (size: 0x28)
    double Min;                                                                       // 0x00D8 (size: 0x8)
    double Max;                                                                       // 0x00E0 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindRandomLocation(int32 EntryPoint);
}; // Size: 0xE8

#endif
