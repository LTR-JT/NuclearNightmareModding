#ifndef UE4SS_SDK_CVW_Rear_Wheel_vehCar_vehicle03_HPP
#define UE4SS_SDK_CVW_Rear_Wheel_vehCar_vehicle03_HPP

class UCVW_Rear_Wheel_vehCar_vehicle03_C : public UChaosVehicleWheel
{
    char padding_0[0x2E0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x2E0

#endif
