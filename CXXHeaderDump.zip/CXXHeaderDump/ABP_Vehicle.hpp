#ifndef UE4SS_SDK_ABP_Vehicle_HPP
#define UE4SS_SDK_ABP_Vehicle_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FAnimNodeFunctionRef __StructProperty_16;                                         // 0x0008 (size: 0x20)
    FName __NameProperty_17;                                                          // 0x0028 (size: 0x8)
    FName __NameProperty_18;                                                          // 0x0030 (size: 0x8)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ControlRig;             // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend;       // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_WheelController;        // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x01C0 (size: 0x30)

}; // Size: 0x1F0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UABP_Vehicle_C : public UVehicleAnimationInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0AF0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0AF8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0B00 (size: 0x8)
    FAnimNode_ControlRig AnimGraphNode_ControlRig;                                    // 0x0B08 (size: 0x4D0)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x0FD8 (size: 0xF0)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x10C8 (size: 0x48)
    FAnimNode_WheelController AnimGraphNode_WheelController;                          // 0x1110 (size: 0xE0)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x11F0 (size: 0x20)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x1210 (size: 0x20)

    void AnimGraph(FPoseLink& AnimGraph);
    void ExecuteUbergraph_ABP_Vehicle(int32 EntryPoint);
}; // Size: 0x1230

#endif
