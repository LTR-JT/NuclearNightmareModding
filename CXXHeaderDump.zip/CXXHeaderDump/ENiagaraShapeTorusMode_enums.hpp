namespace ENiagaraShapeTorusMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraShapeTorusMode_MAX = 2,
    };
}

