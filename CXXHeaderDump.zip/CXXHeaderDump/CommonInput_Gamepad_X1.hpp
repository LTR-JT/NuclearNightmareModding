#ifndef UE4SS_SDK_CommonInput_Gamepad_X1_HPP
#define UE4SS_SDK_CommonInput_Gamepad_X1_HPP

class UCommonInput_Gamepad_X1_C : public UCommonInputBaseControllerData
{
    char padding_0[0xE8];                                                             // 0x0000 (size: 0x0)
}; // Size: 0xE8

#endif
