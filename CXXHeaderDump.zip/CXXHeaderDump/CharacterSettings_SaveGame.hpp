#ifndef UE4SS_SDK_CharacterSettings_SaveGame_HPP
#define UE4SS_SDK_CharacterSettings_SaveGame_HPP

class UCharacterSettings_SaveGame_C : public USaveGame
{
    double SensitivtyX;                                                               // 0x0028 (size: 0x8)
    double SensitivtyY;                                                               // 0x0030 (size: 0x8)
    bool InvertMouseX;                                                                // 0x0038 (size: 0x1)
    bool InvertMouseY;                                                                // 0x0039 (size: 0x1)
    bool CameraSmoothing;                                                             // 0x003A (size: 0x1)
    double HelicopterRollSensitivity;                                                 // 0x0040 (size: 0x8)
    double HelicopterPitchSensitivity;                                                // 0x0048 (size: 0x8)
    bool InvertHelicopterRoll;                                                        // 0x0050 (size: 0x1)
    bool InvertHelicopterPitch;                                                       // 0x0051 (size: 0x1)
    int32 PlayerFOV;                                                                  // 0x0054 (size: 0x4)
    double MasterVolume;                                                              // 0x0058 (size: 0x8)
    double MusicVolume;                                                               // 0x0060 (size: 0x8)
    bool HidePlayerTags;                                                              // 0x0068 (size: 0x1)
    bool DOF;                                                                         // 0x0069 (size: 0x1)
    double Gamma;                                                                     // 0x0070 (size: 0x8)
    double WindVolume;                                                                // 0x0078 (size: 0x8)
    bool HideNotifications;                                                           // 0x0080 (size: 0x1)
    double Bloom;                                                                     // 0x0088 (size: 0x8)
    bool HidePing;                                                                    // 0x0090 (size: 0x1)
    bool UseCelius;                                                                   // 0x0091 (size: 0x1)
    bool FirstPersonDeaths;                                                           // 0x0092 (size: 0x1)
    UDLSSMode DLSSMode;                                                               // 0x0093 (size: 0x1)
    FString Language;                                                                 // 0x0098 (size: 0x10)
    bool DSSRR;                                                                       // 0x00A8 (size: 0x1)
    bool DSSSR;                                                                       // 0x00A9 (size: 0x1)
    bool FSR;                                                                         // 0x00AA (size: 0x1)
    int32 FSRMode;                                                                    // 0x00AC (size: 0x4)
    bool ToggleVoiceChat;                                                             // 0x00B0 (size: 0x1)
    double VCVolume;                                                                  // 0x00B8 (size: 0x8)

}; // Size: 0xC0

#endif
