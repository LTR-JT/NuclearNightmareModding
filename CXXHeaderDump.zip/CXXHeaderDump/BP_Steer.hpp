#ifndef UE4SS_SDK_BP_Steer_HPP
#define UE4SS_SDK_BP_Steer_HPP

class IBP_Steer_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Steer(double Speed, double Brake Left, double Brake Right, double Wheels);
}; // Size: 0x28

#endif
