#ifndef UE4SS_SDK_BTT_FindClosestPlayerMimic_HPP
#define UE4SS_SDK_BTT_FindClosestPlayerMimic_HPP

class UBTT_FindClosestPlayerMimic_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    bool FoundMimic?;                                                                 // 0x00D8 (size: 0x1)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindClosestPlayerMimic(int32 EntryPoint);
}; // Size: 0xD9

#endif
