#ifndef UE4SS_SDK_BP_ClassifiedMaterial_HPP
#define UE4SS_SDK_BP_ClassifiedMaterial_HPP

class ABP_ClassifiedMaterial_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    float Timeline_NewTrack_0_6D8624874BE1119FA90FE2956F0C6CB2;                       // 0x02B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_6D8624874BE1119FA90FE2956F0C6CB2; // 0x02B4 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02B8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02C0 (size: 0x8)
    bool PickedUp;                                                                    // 0x02C8 (size: 0x1)
    double Closest;                                                                   // 0x02D0 (size: 0x8)
    class ABP_Radio_C* Radio;                                                         // 0x02D8 (size: 0x8)
    FString UniqueIdentifer;                                                          // 0x02E0 (size: 0x10)
    class AObjectiveManager_C* ObjectiveManager;                                      // 0x02F0 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_7CA6B9944304F379BB5A708934B1E2B4(FName NotifyName);
    void OnNotifyBegin_7CA6B9944304F379BB5A708934B1E2B4(FName NotifyName);
    void OnInterrupted_7CA6B9944304F379BB5A708934B1E2B4(FName NotifyName);
    void OnBlendOut_7CA6B9944304F379BB5A708934B1E2B4(FName NotifyName);
    void OnCompleted_7CA6B9944304F379BB5A708934B1E2B4(FName NotifyName);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void RandomizeLocation();
    void RandomizeLocationClient();
    void ReceiveBeginPlay();
    void DestroyAll();
    void DestroyServer();
    void ExecuteUbergraph_BP_ClassifiedMaterial(int32 EntryPoint);
}; // Size: 0x2F8

#endif
