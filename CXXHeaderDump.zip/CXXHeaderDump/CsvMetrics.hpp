#ifndef UE4SS_SDK_CsvMetrics_HPP
#define UE4SS_SDK_CsvMetrics_HPP

class UCsvActorCountMetric : public UWorldMetricInterface
{
    char padding_0[0x88];                                                             // 0x0000 (size: 0x0)
}; // Size: 0x88

class UCsvMetricsSubsystem : public UWorldSubsystem
{
    TArray<class TSubclassOf<UWorldMetricInterface>> MetricClasses;                   // 0x0030 (size: 0x10)

}; // Size: 0x60

#endif
