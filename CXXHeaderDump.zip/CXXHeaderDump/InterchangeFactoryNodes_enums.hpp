enum class EInterchangeSkeletalMeshContentType {
    All = 0,
    Geometry = 1,
    SkinningWeights = 2,
    MAX = 3,
};

