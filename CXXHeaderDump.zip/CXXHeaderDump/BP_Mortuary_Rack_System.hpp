#ifndef UE4SS_SDK_BP_Mortuary_Rack_System_HPP
#define UE4SS_SDK_BP_Mortuary_Rack_System_HPP

class ABP_Mortuary_Rack_System_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Rack_8;                                               // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Rack_7;                                               // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Rack_6;                                               // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Rack_5;                                               // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Rack_4;                                               // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Rack_3;                                               // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Rack_2;                                               // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Rack_1;                                               // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Mortuary_Rack_System;                                 // 0x02D8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E0 (size: 0x8)
    double Rack_1_Move;                                                               // 0x02E8 (size: 0x8)
    double Rack_2_Move;                                                               // 0x02F0 (size: 0x8)
    double Rack_3_Move;                                                               // 0x02F8 (size: 0x8)
    double Rack_4_Move;                                                               // 0x0300 (size: 0x8)
    double Rack_5_Move;                                                               // 0x0308 (size: 0x8)
    double Rack_6_Move;                                                               // 0x0310 (size: 0x8)
    double Rack_7_Move;                                                               // 0x0318 (size: 0x8)
    double Rack_8_Move;                                                               // 0x0320 (size: 0x8)
    bool Rack_1_Visible;                                                              // 0x0328 (size: 0x1)
    bool Rack_2_Visible;                                                              // 0x0329 (size: 0x1)
    bool Rack_3_Visible;                                                              // 0x032A (size: 0x1)
    bool Rack_4_Visible;                                                              // 0x032B (size: 0x1)
    bool Rack_5_Visible;                                                              // 0x032C (size: 0x1)
    bool Rack_6_Visible;                                                              // 0x032D (size: 0x1)
    bool Rack_7_Visible;                                                              // 0x032E (size: 0x1)
    bool Rack_8_Visible;                                                              // 0x032F (size: 0x1)

    void Position Y(double Y, bool Invert Y, class USceneComponent* TargetMesh);
    void UserConstructionScript();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_Mortuary_Rack_System(int32 EntryPoint);
}; // Size: 0x330

#endif
