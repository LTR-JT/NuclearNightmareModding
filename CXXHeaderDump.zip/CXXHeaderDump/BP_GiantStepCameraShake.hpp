#ifndef UE4SS_SDK_BP_GiantStepCameraShake_HPP
#define UE4SS_SDK_BP_GiantStepCameraShake_HPP

class UBP_GiantStepCameraShake_C : public ULegacyCameraShake
{
}; // Size: 0x1F0

#endif
