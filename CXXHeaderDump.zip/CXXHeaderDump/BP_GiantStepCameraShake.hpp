#ifndef UE4SS_SDK_BP_GiantStepCameraShake_HPP
#define UE4SS_SDK_BP_GiantStepCameraShake_HPP

class UBP_GiantStepCameraShake_C : public ULegacyCameraShake
{
    char padding_0[0x1F0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x1F0

#endif
