#ifndef UE4SS_SDK_ComputerObjective_HPP
#define UE4SS_SDK_ComputerObjective_HPP

class UComputerObjective_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UModular_ObjectiveComplete_C* Modular_ObjectiveComplete;                    // 0x02E8 (size: 0x8)
    class UObject* Avatar;                                                            // 0x02F0 (size: 0x8)
    FString UserName;                                                                 // 0x02F8 (size: 0x10)
    FString Location;                                                                 // 0x0308 (size: 0x10)
    FText Text;                                                                       // 0x0318 (size: 0x10)
    FText Text_0;                                                                     // 0x0328 (size: 0x10)

    void Construct();
    void ExecuteUbergraph_ComputerObjective(int32 EntryPoint);
}; // Size: 0x338

#endif
