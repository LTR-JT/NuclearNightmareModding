#ifndef UE4SS_SDK_BellJetRangerAnimBP_HPP
#define UE4SS_SDK_BellJetRangerAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_22;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_23;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_24;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace_1; // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_MeshRefPose;            // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0220 (size: 0x30)

}; // Size: 0x250

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UBellJetRangerAnimBP_C : public UVehicleAnimationInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0AF0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0AF8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0B00 (size: 0x8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x0B08 (size: 0x20)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0B28 (size: 0x48)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0B70 (size: 0x80)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x0BF0 (size: 0x10)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x0C00 (size: 0x128)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0D28 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0D48 (size: 0x128)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0E70 (size: 0x20)
    FRotator MainRotorRotation;                                                       // 0x0E90 (size: 0x18)
    FRotator MainRotorRotation_0;                                                     // 0x0EA8 (size: 0x18)
    double RotorSpeedOffset;                                                          // 0x0EC0 (size: 0x8)
    double TargetVlaue;                                                               // 0x0EC8 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void UpdateSpeedOffset(double Increment1);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_BellJetRangerAnimBP(int32 EntryPoint);
}; // Size: 0xED0

#endif
