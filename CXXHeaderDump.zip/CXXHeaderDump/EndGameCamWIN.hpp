#ifndef UE4SS_SDK_EndGameCamWIN_HPP
#define UE4SS_SDK_EndGameCamWIN_HPP

class AEndGameCamWIN_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCineCameraComponent* CineCamera;                                           // 0x0298 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    float Timeline_NewTrack_0_9DD29FE84B0533C0403FD485EB20A9FF;                       // 0x02B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_9DD29FE84B0533C0403FD485EB20A9FF; // 0x02B4 (size: 0x1)
    char padding_0[0x3];                                                              // 0x02B5 (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x02B8 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> Players;                                // 0x02C0 (size: 0x10)
    int32 Index;                                                                      // 0x02D0 (size: 0x4)
    char padding_1[0x4];                                                              // 0x02D4 (size: 0x4)
    class ABP_West_Heli_UH60A_Showcase_C* Heli;                                       // 0x02D8 (size: 0x8)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnFailure_417E699749D885AB37B8D994517B51E6();
    void OnSuccess_417E699749D885AB37B8D994517B51E6();
    void OnFailure_EEF22A8F44B30489559701860A416E14();
    void OnSuccess_EEF22A8F44B30489559701860A416E14();
    void ReceiveBeginPlay();
    void Response(bool Retry);
    void ServerTravelReset();
    void HostLeave();
    void HostLeaveAll();
    void ExecuteUbergraph_EndGameCamWIN(int32 EntryPoint);
}; // Size: 0x2E0

#endif
