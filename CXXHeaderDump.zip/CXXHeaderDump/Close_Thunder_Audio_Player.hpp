#ifndef UE4SS_SDK_Close_Thunder_Audio_Player_HPP
#define UE4SS_SDK_Close_Thunder_Audio_Player_HPP

class UClose_Thunder_Audio_Player_C : public USceneComponent
{
    char padding_0[0x230];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x230

#endif
