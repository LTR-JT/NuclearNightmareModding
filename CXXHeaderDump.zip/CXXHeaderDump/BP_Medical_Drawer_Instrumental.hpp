#ifndef UE4SS_SDK_BP_Medical_Drawer_Instrumental_HPP
#define UE4SS_SDK_BP_Medical_Drawer_Instrumental_HPP

class ABP_Medical_Drawer_Instrumental_C : public AActor
{
    class UStaticMeshComponent* Cloth_6;                                              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Cloth_5;                                              // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Cloth_4;                                              // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Cloth_3;                                              // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Cloth_2;                                              // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Cloth_1;                                              // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Wheel_4;                                              // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_4;                                      // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Wheel_3;                                              // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_3;                                      // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_1;                                      // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_2;                                      // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* Wheel_2;                                              // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* Wheel_1;                                              // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* Drawer_6;                                             // 0x0300 (size: 0x8)
    class UStaticMeshComponent* Drawer_5;                                             // 0x0308 (size: 0x8)
    class UStaticMeshComponent* Drawer_4;                                             // 0x0310 (size: 0x8)
    class UStaticMeshComponent* Drawer_3;                                             // 0x0318 (size: 0x8)
    class UStaticMeshComponent* Drawer_2;                                             // 0x0320 (size: 0x8)
    class UStaticMeshComponent* Drawer_1;                                             // 0x0328 (size: 0x8)
    class UStaticMeshComponent* Medical_Drawer_Instrumental_body;                     // 0x0330 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0338 (size: 0x8)

}; // Size: 0x340

#endif
