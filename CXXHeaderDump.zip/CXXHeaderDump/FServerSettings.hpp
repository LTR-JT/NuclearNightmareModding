#ifndef UE4SS_SDK_FServerSettings_HPP
#define UE4SS_SDK_FServerSettings_HPP

struct FFServerSettings
{
    FString Name_2_3B4AD8014E36E9358BBBB79114962994;                                  // 0x0000 (size: 0x10)
    bool FriendlyFire_7_EA1ED51642424E81F10BD784746DED23;                             // 0x0010 (size: 0x1)
    bool TeamSpawn_8_20B48FE74E4B427A108CC798E7A0C45F;                                // 0x0011 (size: 0x1)
    uint8 Diffculty_11_7C1626A141AB66ACE69479A0AB90EB9A;                              // 0x0012 (size: 0x1)
    int32 CurrentPlayers_14_747BDB3E4AD252F03BABDBADE5D77D72;                         // 0x0014 (size: 0x4)
    bool Lan_17_07F09F604E78F360D64BE0ACC1B475D4;                                     // 0x0018 (size: 0x1)
    bool ShouldAdvertise_20_7B056CAA4F7FB4FB8A998C96A80CE9B1;                         // 0x0019 (size: 0x1)
    bool AllowFriendsJoinOnly_21_65F77B30492B5FC3AE857F8279C31C96;                    // 0x001A (size: 0x1)
    bool LobbyState_23_6876FF5D46A5179BAD391B800D72033C;                              // 0x001B (size: 0x1)

}; // Size: 0x1C

#endif
