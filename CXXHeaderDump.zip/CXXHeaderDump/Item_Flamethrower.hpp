#ifndef UE4SS_SDK_Item_Flamethrower_HPP
#define UE4SS_SDK_Item_Flamethrower_HPP

class AItem_Flamethrower_C : public AItemActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E8 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x02F0 (size: 0x8)
    double Fuel;                                                                      // 0x02F8 (size: 0x8)

    void BPOnEquip(class ANuclearNightmareCharacter* Character);
    void BPOnUnEquip(class ANuclearNightmareCharacter* Character);
    void BndEvt__Item_Flamethrower_Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ReceiveBeginPlay();
    void BndEvt__item_38specialammo_Sphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_Item_Flamethrower(int32 EntryPoint);
}; // Size: 0x300

#endif
