#ifndef UE4SS_SDK_BFL_GameUserSetting_HPP
#define UE4SS_SDK_BFL_GameUserSetting_HPP

class UBFL_GameUserSetting_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Get formatted Supported Fullscreen Resolutions(class UObject* __WorldContext, int32& Current Resolution Index, TMap<class FIntPoint, class FText>& Mapped Supported Resolutions);
    void Set Resolution(FIntPoint Resolution, class UObject* __WorldContext);
    void Set Window Mode(TEnumAsByte<EWindowMode::Type> InFullscreenMode, class UObject* __WorldContext);
    void Convert Output devives to text(TArray<FAudioOutputDeviceInfo>& Array, class UObject* __WorldContext, TArray<FText>& Output devices);
    void Set Default Settings(class UBP_Save_Settings_C* Save Game Settings, class UObject* __WorldContext);
    void Load Saved Settings(class UObject* __WorldContext, class UBP_Save_Settings_C*& Output_Get);
    void Get Localized Cultures as text(class UObject* __WorldContext, TArray<FText>& Localized cultures);
    void Get Predefined Frame Rate Limit Index(class UObject* __WorldContext, int32& NewParam);
    void Set Frame Rate Limit(int32 Selected Frame Rate Index, class UObject* __WorldContext);
    void Get VSync Enabled(class UObject* __WorldContext, bool& Enabled);
    void Enable VSync(bool bEnable, class UObject* __WorldContext);
    void Get Current Reflection Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current Effects Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current Post Process Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current Texture Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current View Distance Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current Anti-Aliasing Quality(class UObject* __WorldContext, int32& Quality Level);
    void Get Current shadow Quality(class UObject* __WorldContext, int32& Quality Level);
    void Set Reflection Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set Effects Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set Post Process Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set Texture Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set ViewDistance(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set Anti-Aliasing Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    void Set Shadow Quality(int32 Selected Quality Index, class UObject* __WorldContext);
    int32 Get Global Illumination Quality(class UObject* __WorldContext);
    void Set Global Illumination Quality(int32 Value, class UObject* __WorldContext);
    void Set Resolution Scale(float Resolution Scale, class UObject* __WorldContext);
    void Get Resolution Scale(class UObject* __WorldContext, float& CurrentScaleNormalized, float& CurrentScaleValue, float& MinScaleValue, float& MaxScaleValue);
    void Set Scalability Level(int32 Scalability Level, class UObject* __WorldContext);
    int32 Get Current Scalability Level(class UObject* __WorldContext);
    void Auto Set Quality Settings(class UObject* __WorldContext);
    void Get Input Actions(class UObject* __WorldContext);
    void Get Formatted Color blind Modes(class UObject* __WorldContext, TArray<FText>& Colorblind Modes);
    void Set Colorblind Mode based on selected Index(int32 Selected Index, float Severity, class UObject* __WorldContext);
    void Set Colorblind Mode(EColorVisionDeficiency Type, class UObject* __WorldContext);
    void Set Window Mode based on selected index(int32 Selected Index, class UObject* __WorldContext);
    void Get Formatted Window Mode(class UObject* __WorldContext, TArray<FText>& Window Modes);
    TEnumAsByte<EWindowMode::Type> Get Fullscreen Mode(class UObject* __WorldContext);
    void Find Current Screen Resolution Index in Supported Screen Resolutions Array(const TArray<FText>& Formatted Supported Screen Resolutions, class UObject* __WorldContext, int32& Current Resolution Index);
    FIntPoint Get Current Screen resolution(class UObject* __WorldContext);
    void Screen Resolution Struct to Text(const FIntPoint& XY Struct, class UObject* __WorldContext, FText& Resolution in formatted text);
    void Set Resolution Based On Selected Resolution(int32 Selected Setting, class UObject* __WorldContext);
    void Apply Settings(class UObject* __WorldContext);
    void Load Settings(class UObject* __WorldContext);
    void Save Settings(class UObject* __WorldContext);
}; // Size: 0x28

#endif
