#ifndef UE4SS_SDK_BTT_FindRandomLocation_Husky_HPP
#define UE4SS_SDK_BTT_FindRandomLocation_Husky_HPP

class UBTT_FindRandomLocation_Husky_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector LocationKey;                                               // 0x00B0 (size: 0x28)
    double Min;                                                                       // 0x00D8 (size: 0x8)
    double Max;                                                                       // 0x00E0 (size: 0x8)
    bool AlreadyFound;                                                                // 0x00E8 (size: 0x1)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindRandomLocation_Husky(int32 EntryPoint);
}; // Size: 0xE9

#endif
