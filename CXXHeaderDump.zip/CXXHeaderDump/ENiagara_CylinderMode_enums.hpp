namespace ENiagara_CylinderMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        ENiagara_MAX = 2,
    };
}

