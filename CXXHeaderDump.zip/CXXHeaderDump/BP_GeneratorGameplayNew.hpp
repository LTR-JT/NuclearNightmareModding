#ifndef UE4SS_SDK_BP_GeneratorGameplayNew_HPP
#define UE4SS_SDK_BP_GeneratorGameplayNew_HPP

class ABP_GeneratorGameplayNew_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x0298 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x02A0 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_FlashLight_1;                                      // 0x02B0 (size: 0x8)
    class UAudioComponent* Generatorrun;                                              // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02C0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02D0 (size: 0x8)
    bool PoweredOn?;                                                                  // 0x02D8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02D9 (size: 0x7)
    TArray<class ASpotLight*> Spotlights;                                             // 0x02E0 (size: 0x10)
    TArray<class APointLight*> Pointlights;                                           // 0x02F0 (size: 0x10)
    TArray<class AActor*> Actors;                                                     // 0x0300 (size: 0x10)
    TArray<class ABP_Door_Base_C*> Doors;                                             // 0x0310 (size: 0x10)
    TArray<double> SpotlightIntensity;                                                // 0x0320 (size: 0x10)
    TArray<class ARectLight*> RecLights;                                              // 0x0330 (size: 0x10)
    FString Location Name;                                                            // 0x0340 (size: 0x10)
    TArray<FVector> SpawnLocations;                                                   // 0x0350 (size: 0x10)
    bool Interacting;                                                                 // 0x0360 (size: 0x1)
    char padding_1[0x7];                                                              // 0x0361 (size: 0x7)
    FTimerHandle PowerOutageTimer;                                                    // 0x0368 (size: 0x8)
    TArray<class AActor*> Equipment;                                                  // 0x0370 (size: 0x10)
    FTimerHandle GenTimer;                                                            // 0x0380 (size: 0x8)
    class UW_Task_C* TaskHud;                                                         // 0x0388 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void PowerON/OFF(bool bool);
    void UserConstructionScript();
    void OnNotifyEnd_7E8EF4A04B6B94FCAB78D2AF54188C92(FName NotifyName);
    void OnNotifyBegin_7E8EF4A04B6B94FCAB78D2AF54188C92(FName NotifyName);
    void OnInterrupted_7E8EF4A04B6B94FCAB78D2AF54188C92(FName NotifyName);
    void OnBlendOut_7E8EF4A04B6B94FCAB78D2AF54188C92(FName NotifyName);
    void OnCompleted_7E8EF4A04B6B94FCAB78D2AF54188C92(FName NotifyName);
    void OnFailure_3CCBCEF345CE59DD9BF969A150A7C425();
    void OnSuccess_3CCBCEF345CE59DD9BF969A150A7C425();
    void OnFailure_11D14F804E6288F5D9B590901D14AB45(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_11D14F804E6288F5D9B590901D14AB45(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void UpdateGen(bool Condition);
    void UpdateGenAll(bool Condition);
    void SpawnGenOnClients();
    void UpdateLocation(FVector Location);
    void GeneratorPowerCut();
    void StartPowerOut();
    void StartPowerOutServer();
    void MoveToGeneratorAll(class APawn* Pawn);
    void GenAction();
    void FinishGenTask();
    void GenFinishALL();
    void RPCGenFinishServer();
    void FinishEarly();
    void FinishEarlyServer();
    void DamageGenCancel();
    void ExecuteUbergraph_BP_GeneratorGameplayNew(int32 EntryPoint);
}; // Size: 0x390

#endif
