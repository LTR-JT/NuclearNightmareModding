#ifndef UE4SS_SDK_LevelWaypointActor_HPP
#define UE4SS_SDK_LevelWaypointActor_HPP

class ALevelWaypointActor_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02A8 (size: 0x8)
    FText Name;                                                                       // 0x02B0 (size: 0x10)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_LevelWaypointActor(int32 EntryPoint);
}; // Size: 0x2C0

#endif
