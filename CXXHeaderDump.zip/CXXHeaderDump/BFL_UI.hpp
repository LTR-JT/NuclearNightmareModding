#ifndef UE4SS_SDK_BFL_UI_HPP
#define UE4SS_SDK_BFL_UI_HPP

class UBFL_UI_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Camera Fade(bool Fade In, float Duration, FLinearColor Color, bool ShouldFadeAudio, bool HoldWhenFinished, class UObject* __WorldContext);
    FEventReply Listen to Close UI(const FKeyEvent& Key Event, class AController* Owning Controller, class UObject* __WorldContext);
    void On Analog Value Changed Scroll(const FAnalogInputEvent& Analog Input Event, class UScrollBox* Target Scrol Box, class UObject* __WorldContext, FEventReply& Event Reply);
    void Set Sizebox(float Height, float Width, class USizeBox* Size Box, class UObject* __WorldContext);
    void Update Progressbar Percent(double Current, double Max, class UProgressBar* Progressbar Object, class UObject* __WorldContext);
    void Update progress bar amount text(double Current, float Max, class UTextBlock* Text Object, class UObject* __WorldContext);
    void Get_UI_Style(class UObject* __WorldContext, FStruct_UI_Style& UI Style);
}; // Size: 0x28

#endif
