#ifndef UE4SS_SDK_BPA_West_Bomber_B2_HPP
#define UE4SS_SDK_BPA_West_Bomber_B2_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_153;                                                         // 0x0004 (size: 0x8)
    char padding_0[0x4];                                                              // 0x000C (size: 0x4)
    class UAnimSequenceBase* __AnimSequenceBase_154;                                  // 0x0010 (size: 0x8)
    class UAnimSequenceBase* __AnimSequenceBase_155;                                  // 0x0018 (size: 0x8)
    class UAnimSequenceBase* __AnimSequenceBase_156;                                  // 0x0020 (size: 0x8)
    class UAnimSequenceBase* __AnimSequenceBase_157;                                  // 0x0028 (size: 0x8)
    class UAnimSequenceBase* __AnimSequenceBase_158;                                  // 0x0030 (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_159;                                        // 0x0038 (size: 0x20)
    float __FloatProperty_160;                                                        // 0x0058 (size: 0x4)
    TEnumAsByte<ESequenceEvalReinit::Type> __ByteProperty_161;                        // 0x005C (size: 0x1)
    bool __BoolProperty_162;                                                          // 0x005D (size: 0x1)
    char padding_1[0x2];                                                              // 0x005E (size: 0x2)
    int32 __IntProperty_163;                                                          // 0x0060 (size: 0x4)
    char padding_2[0x4];                                                              // 0x0064 (size: 0x4)
    class UAnimSequenceBase* __AnimSequenceBase_164;                                  // 0x0068 (size: 0x8)
    bool __BoolProperty_165;                                                          // 0x0070 (size: 0x1)
    EAnimSyncMethod __EnumProperty_166;                                               // 0x0071 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_167;                             // 0x0072 (size: 0x1)
    char padding_3[0x1];                                                              // 0x0073 (size: 0x1)
    FName __NameProperty_168;                                                         // 0x0074 (size: 0x8)
    char padding_4[0x4];                                                              // 0x007C (size: 0x4)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0080 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0100 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0118 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace_1; // 0x0148 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_5;        // 0x0178 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_4;        // 0x01A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_3;        // 0x01D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_2;        // 0x0208 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_1;        // 0x0238 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive;          // 0x0268 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_17;          // 0x0298 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_16;          // 0x02F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_15;          // 0x0328 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_14;          // 0x0358 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_13;          // 0x0388 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_12;          // 0x03B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_11;          // 0x03E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_10;          // 0x0418 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_9;           // 0x0448 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_8;           // 0x0478 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_7;           // 0x04A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_6;           // 0x04D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_5;    // 0x0508 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_5;           // 0x0538 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_4;           // 0x0568 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_4;    // 0x0598 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x05C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_3;           // 0x05F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_2;           // 0x0628 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_3;    // 0x0658 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0688 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x06B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_2;    // 0x06E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator_1;    // 0x0718 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequenceEvaluator;      // 0x0748 (size: 0x30)

}; // Size: 0x778

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)
    float __FloatProperty_1;                                                          // 0x000C (size: 0x4)
    float __FloatProperty_2;                                                          // 0x0010 (size: 0x4)
    float __FloatProperty_3;                                                          // 0x0014 (size: 0x4)
    float __FloatProperty_4;                                                          // 0x0018 (size: 0x4)

}; // Size: 0x1C

class UBPA_West_Bomber_B2_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x1C)
    char padding_0[0x4];                                                              // 0x0394 (size: 0x4)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0398 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x03A0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x03A8 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x03C8 (size: 0x20)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_5;                            // 0x03E8 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_4;                            // 0x04B0 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_3;                            // 0x0578 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_2;                            // 0x0640 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_1;                            // 0x0708 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;                              // 0x07D0 (size: 0xC8)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_17;                                 // 0x0898 (size: 0x128)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x09C0 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_16;                                 // 0x09E0 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_15;                                 // 0x0B08 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_14;                                 // 0x0C30 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_13;                                 // 0x0D58 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_12;                                 // 0x0E80 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_11;                                 // 0x0FA8 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;                                 // 0x10D0 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;                                  // 0x11F8 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;                                  // 0x1320 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;                                  // 0x1448 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;                                  // 0x1570 (size: 0x128)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_5;                    // 0x1698 (size: 0x40)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;                                  // 0x16D8 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;                                  // 0x1800 (size: 0x128)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_4;                    // 0x1928 (size: 0x40)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x1968 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;                                  // 0x1988 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;                                  // 0x1AB0 (size: 0x128)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_3;                    // 0x1BD8 (size: 0x40)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x1C18 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x1D40 (size: 0x128)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;                    // 0x1E68 (size: 0x40)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_1;                    // 0x1EA8 (size: 0x40)
    FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;                      // 0x1EE8 (size: 0x40)
    double RudderLTop;                                                                // 0x1F28 (size: 0x8)
    double RudderLBottom;                                                             // 0x1F30 (size: 0x8)
    double RudderRTop;                                                                // 0x1F38 (size: 0x8)
    double RudderRBottom;                                                             // 0x1F40 (size: 0x8)
    double InboardElevons;                                                            // 0x1F48 (size: 0x8)
    double MidElevons;                                                                // 0x1F50 (size: 0x8)
    double OutboardElevons;                                                           // 0x1F58 (size: 0x8)
    double BombHatchL;                                                                // 0x1F60 (size: 0x8)
    double BombHatchR;                                                                // 0x1F68 (size: 0x8)
    double FrontWheelRetract;                                                         // 0x1F70 (size: 0x8)
    double RearWheelLRetract;                                                         // 0x1F78 (size: 0x8)
    double RearWheelRRetract;                                                         // 0x1F80 (size: 0x8)
    double FrontWheelSuspension;                                                      // 0x1F88 (size: 0x8)
    double RearWheelLSuspension;                                                      // 0x1F90 (size: 0x8)
    double RearWheelRSuspension;                                                      // 0x1F98 (size: 0x8)
    double EngineCoverL1;                                                             // 0x1FA0 (size: 0x8)
    double EngineCoverL2;                                                             // 0x1FA8 (size: 0x8)
    double EngineCoverR1;                                                             // 0x1FB0 (size: 0x8)
    double EngineCoverR2;                                                             // 0x1FB8 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_4FEBEB2048071AFB513043A9DAF7090A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_B2ABCC894DB19ECD22BB98916F08C4B0();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_7F987B6444A4D750FC966F9F0BAB48A7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_8FDD8CB24987063AC6E07CA65E1F5925();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_611ADFE14819A93407369E81E95BC56A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_727485AC4A8EC417E74C43B542664174();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_4A17288041374C3C736BBDBBB91D93B6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_A6A662AB4B244343BA6CC3B935E1A459();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_46884CBE47B2E187F6A64C9DF64CA7BB();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_FE0A71064D21254951719B9B734456FE();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_751DA6A940B234596826B78A9B36BF50();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_FFBBF2E54B5DDA46C7A1DDB25CBCE062();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_SequenceEvaluator_4D5D15A44AF4C35438C9DBBBBE553907();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_315595B247D4D3FE3C0C3FAAFE2E37AF();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_908C9F7E4155EC477CB25AB54D1802A8();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_D4B3C1844D348A944588BE87C7DAC75F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_2FC1730240D6F34E74A161B046855FEB();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_64BC0DE24D4172A4E3D3799FC6DC8C5F();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_D8F4F8764784D51D68FF6C8B3C6C2D14();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_0186D4E949212A7EA401C0BC3388C67A();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_B3315C0E4095C8B7B5B563B746848C9B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_8167007244B91AEDC48AC1B710C1ED70();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_9D836F4D4E79E504239B64B4B10A57B7();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_BPA_West_Bomber_B2_AnimGraphNode_ModifyBone_0C0C967A4B022FF6AF4F9A823C56F9F1();
    void ExecuteUbergraph_BPA_West_Bomber_B2(int32 EntryPoint);
}; // Size: 0x1FC0

#endif
