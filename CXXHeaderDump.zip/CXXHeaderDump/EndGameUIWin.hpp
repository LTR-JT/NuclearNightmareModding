#ifndef UE4SS_SDK_EndGameUIWin_HPP
#define UE4SS_SDK_EndGameUIWin_HPP

class UEndGameUIWin_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UClassifiedCollected_C* ClassifiedCollected;                                // 0x02E8 (size: 0x8)
    class UEndGameState1_C* EndGameState1;                                            // 0x02F0 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F8 (size: 0x8)
    class UVerticalBox* VerticalBox;                                                  // 0x0300 (size: 0x8)
    class UVerticalBox* VerticalBox_0;                                                // 0x0308 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> Array;                                  // 0x0310 (size: 0x10)
    FEndGameUIWin_CResponse Response;                                                 // 0x0320 (size: 0x10)
    void Response(bool Retry);

    void OnFailure_F37928954183547EFF35AD979CDB3029();
    void OnSuccess_F37928954183547EFF35AD979CDB3029();
    void OnFailure_7500C1AA45A590B39C9E2091419E0173(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_7500C1AA45A590B39C9E2091419E0173(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_48766F7D44E6CEDB3DA6C0AFFFE6FE13();
    void OnSuccess_48766F7D44E6CEDB3DA6C0AFFFE6FE13();
    void OnFailure_1A827C144446DD9697C9E0B3996E5657(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_1A827C144446DD9697C9E0B3996E5657(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_C5388E3F4A1EFD2434087C85AAECF5E5();
    void OnSuccess_C5388E3F4A1EFD2434087C85AAECF5E5();
    void OnFailure_9324C93242C7674F8BA3D588AECFD426(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_9324C93242C7674F8BA3D588AECFD426(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_DE68E23449EFC74E52F067B576D0EEFD();
    void OnSuccess_DE68E23449EFC74E52F067B576D0EEFD();
    void OnFailure_50FAE34246F3B1CB522E66A2C9FF1097(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_50FAE34246F3B1CB522E66A2C9FF1097(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_052A249541E7E7B0735D4A90BD3DD107();
    void OnSuccess_052A249541E7E7B0735D4A90BD3DD107();
    void OnFailure_A342B5514E56F090C0916A96B784F692(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_A342B5514E56F090C0916A96B784F692(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_5C1E3FB74840BA379DA6BE83745359CF();
    void OnSuccess_5C1E3FB74840BA379DA6BE83745359CF();
    void OnFailure_AC6BACD2499615F41229F5A233C12D55(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_AC6BACD2499615F41229F5A233C12D55(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void Construct();
    void Retry();
    void BackTOMenu();
    void ExecuteUbergraph_EndGameUIWin(int32 EntryPoint);
    void Response__DelegateSignature(bool Retry);
}; // Size: 0x330

#endif
