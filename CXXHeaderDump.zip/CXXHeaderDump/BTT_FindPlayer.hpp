#ifndef UE4SS_SDK_BTT_FindPlayer_HPP
#define UE4SS_SDK_BTT_FindPlayer_HPP

class UBTT_FindPlayer_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x00D8 (size: 0x10)
    double MaxDistance;                                                               // 0x00E8 (size: 0x8)
    class AStalker_AI_C* Stalker;                                                     // 0x00F0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* ChoosenTarget;                                  // 0x00F8 (size: 0x8)
    class APawn* Controlled Pawn;                                                     // 0x0100 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindPlayer(int32 EntryPoint);
}; // Size: 0x108

#endif
