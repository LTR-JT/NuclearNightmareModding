#ifndef UE4SS_SDK_AirportContent_HPP
#define UE4SS_SDK_AirportContent_HPP

class UAirportContent_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_0;                                                          // 0x02E8 (size: 0x8)
    FAirportContent_CClicked Clicked;                                                 // 0x02F0 (size: 0x10)
    void Clicked();

    void BndEvt__BaseCampContent_Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void OnClicked();
    void BndEvt__AirportContent_Button_0_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();
    void ExecuteUbergraph_AirportContent(int32 EntryPoint);
    void Clicked__DelegateSignature();
}; // Size: 0x300

#endif
