#ifndef UE4SS_SDK_BTT_MoveToMimicUndetected_HPP
#define UE4SS_SDK_BTT_MoveToMimicUndetected_HPP

class UBTT_MoveToMimicUndetected_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void FindClosestActorOfInterest(FVector PawnLocation, FVector& Location);
    void OnFail_66897CCE4D2A19809FD7C593FC9B6453(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_66897CCE4D2A19809FD7C593FC9B6453(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_740070684488D554D04486B1B289A2BD(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_740070684488D554D04486B1B289A2BD(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MoveToMimicUndetected(int32 EntryPoint);
}; // Size: 0xB0

#endif
