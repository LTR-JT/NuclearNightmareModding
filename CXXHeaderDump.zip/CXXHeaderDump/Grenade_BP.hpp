#ifndef UE4SS_SDK_Grenade_BP_HPP
#define UE4SS_SDK_Grenade_BP_HPP

class AGrenade_BP_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x0298 (size: 0x8)
    class URadialForceComponent* RadialForce;                                         // 0x02A0 (size: 0x8)
    class USkeletalMeshComponent* Grenade;                                            // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    double ExplosionRadius;                                                           // 0x02B8 (size: 0x8)
    double ExplosionStrength;                                                         // 0x02C0 (size: 0x8)
    double ExplosionTime;                                                             // 0x02C8 (size: 0x8)
    bool CanExplode?;                                                                 // 0x02D0 (size: 0x1)
    bool FPPAnimations?;                                                              // 0x02D1 (size: 0x1)
    class UMK2FPP_AnimBP_C* FPPAnimationBP;                                           // 0x02D8 (size: 0x8)
    class UMK2TPP_AnimBP_C* TPPAnimationBP;                                           // 0x02E0 (size: 0x8)
    TArray<class AGrenadeCharacter_BP_C*> CharactersInExplosionRadius;                // 0x02E8 (size: 0x10)
    bool Exploaded;                                                                   // 0x02F8 (size: 0x1)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void Armed();
    void Explode();
    void SetTPPAnimClass();
    void SetFPPAnimClass();
    void EquipMontage();
    void UnequipMontage();
    void PunchMontage();
    void PinPullMontage();
    void AimMontage();
    void ThrowMontage();
    void HidePin();
    void HideSeal();
    void NewExpload();
    void NewExploadServer();
    void BndEvt__Grenade_BP_Grenade_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(class UPrimitiveComponent* HitComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
    void ExecuteUbergraph_Grenade_BP(int32 EntryPoint);
}; // Size: 0x2F9

#endif
