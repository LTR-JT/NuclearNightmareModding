#ifndef UE4SS_SDK_ImgMediaEngine_HPP
#define UE4SS_SDK_ImgMediaEngine_HPP

class UDEPRECATED_ImgMediaPlaybackComponent : public UActorComponent
{
    float LODBias;                                                                    // 0x00A0 (size: 0x4)

}; // Size: 0xC8

#endif
