namespace ENiagaraSkelMeshTransforms {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        NewEnumerator4 = 4,
        ENiagaraSkelMeshTransforms_MAX = 5,
    };
}

