#ifndef UE4SS_SDK_BPI_SmashGenerator_HPP
#define UE4SS_SDK_BPI_SmashGenerator_HPP

class IBPI_SmashGenerator_C : public IInterface
{

    void DestroyGen();
}; // Size: 0x28

#endif
