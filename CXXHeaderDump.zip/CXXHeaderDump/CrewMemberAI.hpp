#ifndef UE4SS_SDK_CrewMemberAI_HPP
#define UE4SS_SDK_CrewMemberAI_HPP

class ACrewMemberAI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0678 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0680 (size: 0x8)
    float Timeline_NewTrack_0_BDD25323421BA97DEE8E5B9323F42876;                       // 0x0688 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_BDD25323421BA97DEE8E5B9323F42876; // 0x068C (size: 0x1)
    char padding_0[0x3];                                                              // 0x068D (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x0690 (size: 0x8)
    double Z;                                                                         // 0x0698 (size: 0x8)
    double Closest;                                                                   // 0x06A0 (size: 0x8)
    FVector ClosestLocation;                                                          // 0x06A8 (size: 0x18)
    class ACrewMemberAI_C* cLOSESTpLAYER;                                             // 0x06C0 (size: 0x8)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnFail_E08CAD7D4344190A907E9AB36133782D(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_E08CAD7D4344190A907E9AB36133782D(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnNotifyEnd_FFE7310F4F34E2E8B73906BFA3479BBE(FName NotifyName);
    void OnNotifyBegin_FFE7310F4F34E2E8B73906BFA3479BBE(FName NotifyName);
    void OnInterrupted_FFE7310F4F34E2E8B73906BFA3479BBE(FName NotifyName);
    void OnBlendOut_FFE7310F4F34E2E8B73906BFA3479BBE(FName NotifyName);
    void OnCompleted_FFE7310F4F34E2E8B73906BFA3479BBE(FName NotifyName);
    void ReceiveBeginPlay();
    void Move();
    void PlayMontage();
    void StopMontage();
    void ExecuteUbergraph_CrewMemberAI(int32 EntryPoint);
}; // Size: 0x6C8

#endif
