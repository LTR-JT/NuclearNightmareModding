#ifndef UE4SS_SDK_Interact_HUD_New_HPP
#define UE4SS_SDK_Interact_HUD_New_HPP

class UInteract_HUD_New_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UProgressBar* HoldProgressBar;                                              // 0x02E8 (size: 0x8)
    class UImage* Image_16;                                                           // 0x02F0 (size: 0x8)
    bool IsMoveableObject;                                                            // 0x02F8 (size: 0x1)
    double Progress;                                                                  // 0x0300 (size: 0x8)

    float Get_HoldProgressBar_Percent();
    FSlateBrush GetBrush();
    void Construct();
    void RefreshMove();
    void ExecuteUbergraph_Interact_HUD_New(int32 EntryPoint);
}; // Size: 0x308

#endif
