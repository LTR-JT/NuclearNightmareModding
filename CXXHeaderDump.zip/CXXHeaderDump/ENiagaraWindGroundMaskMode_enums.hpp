namespace ENiagaraWindGroundMaskMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraWindGroundMaskMode_MAX = 2,
    };
}

