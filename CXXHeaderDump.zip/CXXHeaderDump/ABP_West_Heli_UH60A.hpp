#ifndef UE4SS_SDK_ABP_West_Heli_UH60A_HPP
#define UE4SS_SDK_ABP_West_Heli_UH60A_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_99;                                                          // 0x0004 (size: 0x8)
    float __FloatProperty_100;                                                        // 0x000C (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_101;                               // 0x0010 (size: 0x2C)
    float __FloatProperty_102;                                                        // 0x003C (size: 0x4)
    bool __BoolProperty_103;                                                          // 0x0040 (size: 0x1)
    EAnimSyncMethod __EnumProperty_104;                                               // 0x0041 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_105;                             // 0x0042 (size: 0x1)
    FName __NameProperty_106;                                                         // 0x0044 (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_107;                                        // 0x0050 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0070 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00F0 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0108 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_3;        // 0x0138 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_9;           // 0x0168 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0198 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalRefPose;           // 0x01C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x01F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x0228 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_2;        // 0x0258 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0288 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_1;        // 0x02B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive;          // 0x02E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0318 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_8;           // 0x0348 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_7;           // 0x0378 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x03A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_6;           // 0x03D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_5;           // 0x0408 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_4;           // 0x0438 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_3;           // 0x0468 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_2;           // 0x0498 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x04C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x04F8 (size: 0x30)

}; // Size: 0x528

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UABP_West_Heli_UH60A_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_3;                            // 0x03A8 (size: 0xC8)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;                                  // 0x0470 (size: 0x128)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0598 (size: 0x20)
    FAnimNode_RefPose AnimGraphNode_LocalRefPose;                                     // 0x05B8 (size: 0x10)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x05C8 (size: 0x48)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x0610 (size: 0x48)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_2;                            // 0x0658 (size: 0xC8)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x0720 (size: 0x48)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_1;                            // 0x0768 (size: 0xC8)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;                              // 0x0830 (size: 0xC8)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x08F8 (size: 0x48)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;                                  // 0x0940 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;                                  // 0x0A68 (size: 0x128)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0B90 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;                                  // 0x0BB0 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;                                  // 0x0CD8 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;                                  // 0x0E00 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;                                  // 0x0F28 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;                                  // 0x1050 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x1178 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x12A0 (size: 0x128)
    double FrontWheels;                                                               // 0x13C8 (size: 0x8)
    double RearWheels;                                                                // 0x13D0 (size: 0x8)
    double RearElevator;                                                              // 0x13D8 (size: 0x8)
    double MainRotorSpeed;                                                            // 0x13E0 (size: 0x8)
    double TailRotorSpeed;                                                            // 0x13E8 (size: 0x8)
    FRotator MainRotorRotation;                                                       // 0x13F0 (size: 0x18)
    FRotator TailRotorRotation;                                                       // 0x1408 (size: 0x18)
    double RotorSpeedOffset;                                                          // 0x1420 (size: 0x8)
    double RightWindowShield1;                                                        // 0x1428 (size: 0x8)
    double RightWindowShield2;                                                        // 0x1430 (size: 0x8)
    double LeftWindowShield1;                                                         // 0x1438 (size: 0x8)
    double LeftWindowShield2;                                                         // 0x1440 (size: 0x8)
    double RightRearDoorOffset;                                                       // 0x1448 (size: 0x8)
    double LeftRearDoorOffset;                                                        // 0x1450 (size: 0x8)
    double LeftFrontDoorAngle;                                                        // 0x1458 (size: 0x8)
    double RightFrontDoorAngle;                                                       // 0x1460 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void SetTailRotorSpeed(double Speed);
    void SetMainRotorSpeed(double Speed);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void UpdateSpeedOffset(double Increment);
    void UpdateRotorSpeed();
    void UpdateFrontWheels(double State);
    void UpdateRearWheels(double State);
    void UpdateRearElevator(double State);
    void UpdateRightShieldWindow(double FirstPart, double SecondPart);
    void UpdateLeftShieldWindow(double FirstPart, double SecondPart);
    void UpdateFrontDoors(double Left, double Right);
    void UpdateRearDoors(double Left, double Right);
    void ExecuteUbergraph_ABP_West_Heli_UH60A(int32 EntryPoint);
}; // Size: 0x1468

#endif
