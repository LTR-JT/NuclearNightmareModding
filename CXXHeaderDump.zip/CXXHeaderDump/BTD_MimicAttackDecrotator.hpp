#ifndef UE4SS_SDK_BTD_MimicAttackDecrotator_HPP
#define UE4SS_SDK_BTD_MimicAttackDecrotator_HPP

class UBTD_MimicAttackDecrotator_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
