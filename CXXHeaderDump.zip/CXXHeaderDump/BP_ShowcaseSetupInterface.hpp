#ifndef UE4SS_SDK_BP_ShowcaseSetupInterface_HPP
#define UE4SS_SDK_BP_ShowcaseSetupInterface_HPP

class IBP_ShowcaseSetupInterface_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void GetSeparators(TArray<FFSeparator>& Separators);
    void GetButtonListControls(TArray<FFButtonsControls>& ButtonListControls);
    void GetCheckboxControls(TArray<FFCheckboxControls>& CheckboxControls);
    void GetTwinSliderControls(TArray<FFTwinSliderControls>& TwinSliderControls);
    void GetSliderControls(TArray<FFSliderControls>& SliderControls);
    void GetShowcaseControls(TScriptInterface<class IBP_ShowcaseControlsInterface_C>& ControlsInterface);
    void GetShowcaseName(FString& Name);
    void GetShowcaseSlot(int32& Slot);
    void GetShowcaseCameraCount(int32& Count);
    void GetShowcaseCamera(int32 Index, class ACameraActor*& Camera);
}; // Size: 0x28

#endif
