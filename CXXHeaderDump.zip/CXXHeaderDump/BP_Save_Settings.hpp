#ifndef UE4SS_SDK_BP_Save_Settings_HPP
#define UE4SS_SDK_BP_Save_Settings_HPP

class UBP_Save_Settings_C : public USaveGame
{
    FStruct_Settings_Video Default Video Settings;                                    // 0x0028 (size: 0x58)
    FStruct_Settings_Video User Video Settings;                                       // 0x0080 (size: 0x58)
    bool Has stored user video settings;                                              // 0x00D8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x00D9 (size: 0x7)
    FStruct_Gameplay_Settings Default Gameplay Settings;                              // 0x00E0 (size: 0x10)
    FStruct_Gameplay_Settings User Gameplay Settings;                                 // 0x00F0 (size: 0x10)
    bool Has stored user gameplay settings;                                           // 0x0100 (size: 0x1)
    char padding_1[0x7];                                                              // 0x0101 (size: 0x7)
    FStruct_Audio_Settings Default Audio Settings;                                    // 0x0108 (size: 0x88)
    FStruct_Audio_Settings User Audio Settings;                                       // 0x0190 (size: 0x88)
    bool Has stored user audoo settings;                                              // 0x0218 (size: 0x1)
    char padding_2[0x7];                                                              // 0x0219 (size: 0x7)
    FStruct_Settings_Inputs Default Input Keyboard Settings;                          // 0x0220 (size: 0x8D0)
    FStruct_Settings_Inputs User Input Keyboard Settings;                             // 0x0AF0 (size: 0x8D0)
    bool Has stored user input keyboard settings;                                     // 0x13C0 (size: 0x1)
    char padding_3[0x7];                                                              // 0x13C1 (size: 0x7)
    FStruct_Settings_Inputs Default  Gamepad Settings;                                // 0x13C8 (size: 0x8D0)
    FStruct_Settings_Controls Default Control Settings;                               // 0x1C98 (size: 0x18)
    FStruct_Settings_Controls User Control Settings;                                  // 0x1CB0 (size: 0x18)
    bool Has stored user control settings;                                            // 0x1CC8 (size: 0x1)
    char padding_4[0x7];                                                              // 0x1CC9 (size: 0x7)
    FStruct_Settings_DLSS Default DLSS Settings;                                      // 0x1CD0 (size: 0x20)
    FStruct_Settings_DLSS User DLSS Settings;                                         // 0x1CF0 (size: 0x20)
    bool Has stored user DLSS settings;                                               // 0x1D10 (size: 0x1)

}; // Size: 0x1D11

#endif
