#ifndef UE4SS_SDK_BP_Snowcat_HPP
#define UE4SS_SDK_BP_Snowcat_HPP

class ABP_Snowcat_C : public AWheeledVehiclePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UCapsuleComponent* Pass2Exit;                                               // 0x0330 (size: 0x8)
    class UCapsuleComponent* Pass1Exit;                                               // 0x0338 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x0340 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x0348 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0350 (size: 0x8)
    class UWidgetComponent* Widget1;                                                  // 0x0358 (size: 0x8)
    class UOnsetVoipAudioComponent* OnsetVoipAudio;                                   // 0x0360 (size: 0x8)
    class UOnsetNameplateComponent* OnsetNameplate;                                   // 0x0368 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0370 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x0378 (size: 0x8)
    class UCameraComponent* FrontCam;                                                 // 0x0380 (size: 0x8)
    class USpringArmComponent* SpringArm1;                                            // 0x0388 (size: 0x8)
    class UParticleSystemComponent* P_dirt_wheel_kickup2;                             // 0x0390 (size: 0x8)
    class UParticleSystemComponent* P_dirt_wheel_kickup1;                             // 0x0398 (size: 0x8)
    class UParticleSystemComponent* P_dirt_wheel_kickup;                              // 0x03A0 (size: 0x8)
    class UAudioComponent* engine_full_power_running_inside_loop;                     // 0x03A8 (size: 0x8)
    class USpotLightComponent* SpotLight1;                                            // 0x03B0 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x03B8 (size: 0x8)
    class UAudioComponent* vehicle_tracks_sound_loop1;                                // 0x03C0 (size: 0x8)
    class UAudioComponent* vehicle_tracks_sound_loop;                                 // 0x03C8 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x03D0 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x03D8 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x03E0 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x03E8 (size: 0x8)
    FVector Event_Hit_location;                                                       // 0x03F0 (size: 0x18)
    FName hit_bone_name;                                                              // 0x0408 (size: 0x8)
    class UPrimitiveComponent* Hit_component;                                         // 0x0410 (size: 0x8)
    bool EngineOn;                                                                    // 0x0418 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Driver;                                         // 0x0420 (size: 0x8)
    class UJournal_C* Map;                                                            // 0x0428 (size: 0x8)
    double Fuel;                                                                      // 0x0430 (size: 0x8)
    class UMaterialInstanceDynamic* LightsMat;                                        // 0x0438 (size: 0x8)
    class UMaterialInstanceDynamic* BacklightsMat;                                    // 0x0440 (size: 0x8)
    bool BrakeLight;                                                                  // 0x0448 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Pass1;                                          // 0x0450 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass2;                                          // 0x0458 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass3;                                          // 0x0460 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass4;                                          // 0x0468 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass5;                                          // 0x0470 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass6;                                          // 0x0478 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Pass7;                                          // 0x0480 (size: 0x8)
    class UMaterialInstanceDynamic* InsideLight;                                      // 0x0488 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void OnRep_BrakeLight();
    void UserConstructionScript();
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraToggle_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Igniton_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Notebook_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Map_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void SetNameplatePlayerName(FString PlayerName);
    void SetNameplateSpeaking(bool bIsSpeaking);
    void SetOwningPlayerState(class APlayerState* PlayerState);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveHit(class UPrimitiveComponent* MyComp, class AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ReceivePossessed(class AController* NewController);
    void AutoStartIgnition();
    void ToggleLights(bool State);
    void ToggleLightsServer(bool State);
    void TurnOnEngine(bool EngineOn);
    void TurnEngineRPC(bool EngineOn);
    void DriverExit();
    void DriverExitRPC();
    void ResetPassengerEntrance();
    void Pass2Reset();
    void Pass3Reset();
    void Pass4Reset();
    void Pass5Reset();
    void Pass6Reset();
    void Pass7Reset();
    void ReceiveBeginPlay();
    void UpdateFuel();
    void SetFuel(double Fuel);
    void ExecuteUbergraph_BP_Snowcat(int32 EntryPoint);
}; // Size: 0x490

#endif
