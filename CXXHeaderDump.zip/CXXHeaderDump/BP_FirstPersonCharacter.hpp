#ifndef UE4SS_SDK_BP_FirstPersonCharacter_HPP
#define UE4SS_SDK_BP_FirstPersonCharacter_HPP

class ABP_FirstPersonCharacter_C : public ANuclearNightmareCharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0920 (size: 0x8)
    class UStaticMeshComponent* Barricade_Sm;                                         // 0x0928 (size: 0x8)
    class USceneComponent* mp5ScopeLocation;                                          // 0x0930 (size: 0x8)
    class UParticleSystemComponent* MuzzleFlashMp5;                                   // 0x0938 (size: 0x8)
    class UStaticMeshComponent* SM_Mag_mp_Transform;                                  // 0x0940 (size: 0x8)
    class USkeletalMeshComponent* mp5;                                                // 0x0948 (size: 0x8)
    class UOnsetVoipAudioComponent* OnsetVoipAudio;                                   // 0x0950 (size: 0x8)
    class UStaticMeshComponent* SyringPreview;                                        // 0x0958 (size: 0x8)
    class UPointLightComponent* NightVisionLight;                                     // 0x0960 (size: 0x8)
    class UParticleSystemComponent* Jetpack2;                                         // 0x0968 (size: 0x8)
    class UParticleSystemComponent* Jetpack1;                                         // 0x0970 (size: 0x8)
    class UStaticMeshComponent* Jet_Pack2;                                            // 0x0978 (size: 0x8)
    class USkeletalMeshComponent* Assesory;                                           // 0x0980 (size: 0x8)
    class USkeletalMeshComponent* Undershirt;                                         // 0x0988 (size: 0x8)
    class USkeletalMeshComponent* Head;                                               // 0x0990 (size: 0x8)
    class USphereComponent* MusicSearcher;                                            // 0x0998 (size: 0x8)
    class USkeletalMeshComponent* SK_NC05_Claw1;                                      // 0x09A0 (size: 0x8)
    class USkeletalMeshComponent* SK_NC05_Claw;                                       // 0x09A8 (size: 0x8)
    class USceneComponent* CamFPLocation1;                                            // 0x09B0 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x09B8 (size: 0x8)
    class UStaticMeshComponent* CameraItem;                                           // 0x09C0 (size: 0x8)
    class UStaticMeshComponent* ColaCan;                                              // 0x09C8 (size: 0x8)
    class USkeletalMeshComponent* Grenade;                                            // 0x09D0 (size: 0x8)
    class UParticleSystemComponent* P_Sparks_G;                                       // 0x09D8 (size: 0x8)
    class USkeletalMeshComponent* SK_Flare;                                           // 0x09E0 (size: 0x8)
    class UNiagaraComponent* NS_RevolverFire;                                         // 0x09E8 (size: 0x8)
    class USkeletalMeshComponent* Revolver;                                           // 0x09F0 (size: 0x8)
    class UParticleSystemComponent* MuzzleFlash;                                      // 0x09F8 (size: 0x8)
    class USkeletalMeshComponent* Shotgun_model;                                      // 0x0A00 (size: 0x8)
    class UChildActorComponent* ChildActor;                                           // 0x0A08 (size: 0x8)
    class UBP_HexTree_AC_C* BP_HexTree_AC;                                            // 0x0A10 (size: 0x8)
    class UStaticMeshComponent* Flamethrower1;                                        // 0x0A18 (size: 0x8)
    class UStaticMeshComponent* BeefJerky;                                            // 0x0A20 (size: 0x8)
    class UWidgetComponent* WidgetVoice;                                              // 0x0A28 (size: 0x8)
    class UStaticMeshComponent* MotionBeeper;                                         // 0x0A30 (size: 0x8)
    class UStaticMeshComponent* Flare;                                                // 0x0A38 (size: 0x8)
    class UStaticMeshComponent* SM_Surgical_Syringe_01c;                              // 0x0A40 (size: 0x8)
    class UStaticMeshComponent* RadioItem;                                            // 0x0A48 (size: 0x8)
    class USceneComponent* CamFPLocation;                                             // 0x0A50 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0A58 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0A60 (size: 0x8)
    class UParticleSystemComponent* Fire;                                             // 0x0A68 (size: 0x8)
    class UNiagaraComponent* NS_Pg_MultipleTails2;                                    // 0x0A70 (size: 0x8)
    class UCameraComponent* DeathCamera;                                              // 0x0A78 (size: 0x8)
    class USpringArmComponent* SpringArmDeathCam;                                     // 0x0A80 (size: 0x8)
    class UNiagaraComponent* NS_Pg_MultipleTails1;                                    // 0x0A88 (size: 0x8)
    class UNiagaraComponent* NS_Pg_MultipleTails;                                     // 0x0A90 (size: 0x8)
    class UParticleSystemComponent* FlameFX;                                          // 0x0A98 (size: 0x8)
    class UStaticMeshComponent* Flamethrower;                                         // 0x0AA0 (size: 0x8)
    class UPawnNoiseEmitterComponent* PawnNoiseEmitter;                               // 0x0AA8 (size: 0x8)
    class UStaticMeshComponent* PainkillerModel;                                      // 0x0AB0 (size: 0x8)
    class UStaticMeshComponent* ItemMesh;                                             // 0x0AB8 (size: 0x8)
    class USkeletalMeshComponent* Shoes;                                              // 0x0AC0 (size: 0x8)
    class USkeletalMeshComponent* Pants;                                              // 0x0AC8 (size: 0x8)
    class USkeletalMeshComponent* Jacket;                                             // 0x0AD0 (size: 0x8)
    float Timeline_11_NewTrack_0_69F426674AA361AF3C8864A40E820C2A;                    // 0x0AD8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_11__Direction_69F426674AA361AF3C8864A40E820C2A; // 0x0ADC (size: 0x1)
    class UTimelineComponent* Timeline_11;                                            // 0x0AE0 (size: 0x8)
    float NightVisionTimeline_NewTrack_0_9794E683423048702AFB84A38A681492;            // 0x0AE8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> NightVisionTimeline__Direction_9794E683423048702AFB84A38A681492; // 0x0AEC (size: 0x1)
    class UTimelineComponent* NightVisionTimeline;                                    // 0x0AF0 (size: 0x8)
    float Timeline_10_NewTrack_0_BB898F254D4157A36DB6FFA4990F9919;                    // 0x0AF8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_10__Direction_BB898F254D4157A36DB6FFA4990F9919; // 0x0AFC (size: 0x1)
    class UTimelineComponent* Timeline_10;                                            // 0x0B00 (size: 0x8)
    float Timeline_9_NewTrack_0_D520709D4B8D503C7B74EF962B0AA5D6;                     // 0x0B08 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_9__Direction_D520709D4B8D503C7B74EF962B0AA5D6; // 0x0B0C (size: 0x1)
    class UTimelineComponent* Timeline_9;                                             // 0x0B10 (size: 0x8)
    float Timeline_7_NewTrack_0_DFF3ED814C975C22B2F551833F56804C;                     // 0x0B18 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_7__Direction_DFF3ED814C975C22B2F551833F56804C; // 0x0B1C (size: 0x1)
    class UTimelineComponent* Timeline_7;                                             // 0x0B20 (size: 0x8)
    float Timeline_8_NewTrack_0_001EB0674F211C91F15486B1BED64720;                     // 0x0B28 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_8__Direction_001EB0674F211C91F15486B1BED64720; // 0x0B2C (size: 0x1)
    class UTimelineComponent* Timeline_8;                                             // 0x0B30 (size: 0x8)
    float Timeline_6_NewTrack_0_CAC2D4704552BE6ECCEA08803AD3E9CE;                     // 0x0B38 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_6__Direction_CAC2D4704552BE6ECCEA08803AD3E9CE; // 0x0B3C (size: 0x1)
    class UTimelineComponent* Timeline_6;                                             // 0x0B40 (size: 0x8)
    float Timeline_5_NewTrack_0_7688FC6F4D206163A1CFB8A91F0F94BB;                     // 0x0B48 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_5__Direction_7688FC6F4D206163A1CFB8A91F0F94BB; // 0x0B4C (size: 0x1)
    class UTimelineComponent* Timeline_5;                                             // 0x0B50 (size: 0x8)
    float Timeline_4_NewTrack_0_5A31C89447DC5457F93843B7E4A0EC64;                     // 0x0B58 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_4__Direction_5A31C89447DC5457F93843B7E4A0EC64; // 0x0B5C (size: 0x1)
    class UTimelineComponent* Timeline_4;                                             // 0x0B60 (size: 0x8)
    float Timeline_3_NewTrack_0_90C40C4C4B964490AC7090817556522F;                     // 0x0B68 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_3__Direction_90C40C4C4B964490AC7090817556522F; // 0x0B6C (size: 0x1)
    class UTimelineComponent* Timeline_3;                                             // 0x0B70 (size: 0x8)
    float Timeline_2_NewTrack_0_909FB7CB45E0538A25E5F7BA7FECF4D3;                     // 0x0B78 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_909FB7CB45E0538A25E5F7BA7FECF4D3; // 0x0B7C (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x0B80 (size: 0x8)
    float Timeline_1_NewTrack_0_59E5C0D145C46B8A37C9B6ADAAC16B3C;                     // 0x0B88 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_59E5C0D145C46B8A37C9B6ADAAC16B3C; // 0x0B8C (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x0B90 (size: 0x8)
    float Timeline_0_NewTrack_0_6391003B4ED2509EAB4459A2DE9DA645;                     // 0x0B98 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_6391003B4ED2509EAB4459A2DE9DA645; // 0x0B9C (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0BA0 (size: 0x8)
    float Timeline_NewTrack_0_7C8BD8B94F6C58504B43ADA98B319DBD;                       // 0x0BA8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_7C8BD8B94F6C58504B43ADA98B319DBD; // 0x0BAC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x0BB0 (size: 0x8)
    float FlashlightSourceChange_NewTrack_0_6D8585C74D4FC2C55A928982FE8A4BB9;         // 0x0BB8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FlashlightSourceChange__Direction_6D8585C74D4FC2C55A928982FE8A4BB9; // 0x0BBC (size: 0x1)
    class UTimelineComponent* FlashlightSourceChange;                                 // 0x0BC0 (size: 0x8)
    class UMaterialInstanceDynamic* PlayerColor;                                      // 0x0BC8 (size: 0x8)
    FLinearColor Color;                                                               // 0x0BD0 (size: 0x10)
    double GasMaskViewBob;                                                            // 0x0BE0 (size: 0x8)
    double Target;                                                                    // 0x0BE8 (size: 0x8)
    double Timer;                                                                     // 0x0BF0 (size: 0x8)
    double HeadBobFrequency;                                                          // 0x0BF8 (size: 0x8)
    class UPickUpIcon_C* PickUpIcon;                                                  // 0x0C00 (size: 0x8)
    class UW_InteractionDisplay_C* InteractionDisplay;                                // 0x0C08 (size: 0x8)
    bool IsInVehicle;                                                                 // 0x0C10 (size: 0x1)
    TEnumAsByte<ESeatNumber::Type> CurrentSeatNumber;                                 // 0x0C11 (size: 0x1)
    class ABP_Vehicle_C* Vehicle;                                                     // 0x0C18 (size: 0x8)
    class UInventoryUI_C* DirectInventoryRef;                                         // 0x0C20 (size: 0x8)
    double Temperature;                                                               // 0x0C28 (size: 0x8)
    bool IsInInside;                                                                  // 0x0C30 (size: 0x1)
    bool InsideEnoughToStopFreezing;                                                  // 0x0C31 (size: 0x1)
    class ABP_SnowmobileOld_C* As BP Snowmobile;                                      // 0x0C38 (size: 0x8)
    float CurrentIntensity;                                                           // 0x0C40 (size: 0x4)
    double TargetIntensity;                                                           // 0x0C48 (size: 0x8)
    class ABP_Snowmobile_C* NewSnowmobile;                                            // 0x0C50 (size: 0x8)
    bool LocalPressed/Released;                                                       // 0x0C58 (size: 0x1)
    class UMaterialInstanceDynamic* JacketColor;                                      // 0x0C60 (size: 0x8)
    class UMaterialInstanceDynamic* FurColor;                                         // 0x0C68 (size: 0x8)
    FBP_FirstPersonCharacter_CRagdollOutOfCar RagdollOutOfCar;                        // 0x0C70 (size: 0x10)
    void RagdollOutOfCar();
    class UMaterialInstanceDynamic* ShoeColor;                                        // 0x0C80 (size: 0x8)
    class UMaterialInstanceDynamic* PantsColor;                                       // 0x0C88 (size: 0x8)
    class UMaterialInstanceDynamic* FlashlightColor;                                  // 0x0C90 (size: 0x8)
    FVector WallHitNormal;                                                            // 0x0C98 (size: 0x18)
    FVector WallHitLocation;                                                          // 0x0CB0 (size: 0x18)
    FVector ClimbHitLocation;                                                         // 0x0CC8 (size: 0x18)
    bool IsClimbing?;                                                                 // 0x0CE0 (size: 0x1)
    bool FinishedClimb;                                                               // 0x0CE1 (size: 0x1)
    double FocusLocation;                                                             // 0x0CE8 (size: 0x8)
    class UAudioComponent* InDoorAmbience;                                            // 0x0CF0 (size: 0x8)
    bool HoldItem?;                                                                   // 0x0CF8 (size: 0x1)
    class AItem_GasCanster_C* GasCainster;                                            // 0x0D00 (size: 0x8)
    bool StopUsingItem;                                                               // 0x0D08 (size: 0x1)
    class ABP_Snowmobile_C* As BP Snowmobile_0;                                       // 0x0D10 (size: 0x8)
    class ABP_Snowmobile_C* LastSnowmobilePTR;                                        // 0x0D18 (size: 0x8)
    class UAudioComponent* RefuelSound;                                               // 0x0D20 (size: 0x8)
    bool DamageEffectOnGoing;                                                         // 0x0D28 (size: 0x1)
    FTimerHandle JumpFallTimer;                                                       // 0x0D30 (size: 0x8)
    double JumpFallTime;                                                              // 0x0D38 (size: 0x8)
    FVector4 Saturation;                                                              // 0x0D40 (size: 0x20)
    bool Drowning?;                                                                   // 0x0D60 (size: 0x1)
    class AItem_Painkillers_C* Painkillers;                                           // 0x0D68 (size: 0x8)
    bool ShowPK;                                                                      // 0x0D70 (size: 0x1)
    double ExceptionDelay;                                                            // 0x0D78 (size: 0x8)
    bool ChangeDeathCamRotation;                                                      // 0x0D80 (size: 0x1)
    FRotator NewDeathCamRotation;                                                     // 0x0D88 (size: 0x18)
    bool CompletedMontageEnemy;                                                       // 0x0DA0 (size: 0x1)
    bool HasCalledDeathEvent?;                                                        // 0x0DA1 (size: 0x1)
    bool bFlameThrower;                                                               // 0x0DA2 (size: 0x1)
    class AItem_Flamethrower_C* FlameThrowerItem;                                     // 0x0DA8 (size: 0x8)
    class UAudioComponent* FTFireSound;                                               // 0x0DB0 (size: 0x8)
    FVector CamFowardVec;                                                             // 0x0DB8 (size: 0x18)
    FVector CamWorldVec;                                                              // 0x0DD0 (size: 0x18)
    bool UsingFlamethrower;                                                           // 0x0DE8 (size: 0x1)
    bool HasAuthorityBool;                                                            // 0x0DE9 (size: 0x1)
    class ABP_FirstPersonCharacter_C* PlayerWithAuthroity;                            // 0x0DF0 (size: 0x8)
    class AStalker_AI_C* Stalker;                                                     // 0x0DF8 (size: 0x8)
    FRotator OldControlRot;                                                           // 0x0E00 (size: 0x18)
    class AStalker_AI_C* Stalker_0;                                                   // 0x0E18 (size: 0x8)
    float Health_0;                                                                   // 0x0E20 (size: 0x4)
    TArray<class APointLight*> Pointlights;                                           // 0x0E28 (size: 0x10)
    TArray<class ASpotLight*> Spotlights;                                             // 0x0E38 (size: 0x10)
    bool UnderLight?;                                                                 // 0x0E48 (size: 0x1)
    TArray<class ARectLight*> RecLight;                                               // 0x0E50 (size: 0x10)
    FTimerHandle NightVisionTimer;                                                    // 0x0E60 (size: 0x8)
    class ADirectionalLight* Dirlight;                                                // 0x0E68 (size: 0x8)
    class AItem_Flashlight_C* EquipedFlashlight;                                      // 0x0E70 (size: 0x8)
    class UMaterialInstanceDynamic* FlashlightBeamMaterial;                           // 0x0E78 (size: 0x8)
    class ABP_FirstPersonCharacter_C* SpectatedPlayer;                                // 0x0E80 (size: 0x8)
    class ASCP_AI_C* SCP;                                                             // 0x0E88 (size: 0x8)
    bool Infected;                                                                    // 0x0E90 (size: 0x1)
    class ABP_FirstPersonCharacter_C* KillFPC;                                        // 0x0E98 (size: 0x8)
    double InfectedAttackLength;                                                      // 0x0EA0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* BurningPlayer;                                  // 0x0EA8 (size: 0x8)
    bool Burning;                                                                     // 0x0EB0 (size: 0x1)
    double BurnDeltaTime;                                                             // 0x0EB8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* PlayerRefForBurning;                            // 0x0EC0 (size: 0x8)
    class UHeadbobShake_C* Headbob;                                                   // 0x0EC8 (size: 0x8)
    class AUltra_Dynamic_Weather_C* Weather;                                          // 0x0ED0 (size: 0x8)
    class AMadPatent_AI_C* Mad;                                                       // 0x0ED8 (size: 0x8)
    double Speed;                                                                     // 0x0EE0 (size: 0x8)
    int32 SharedMaterials;                                                            // 0x0EE8 (size: 0x4)
    TEnumAsByte<EEndGame::Type> EndGameState;                                         // 0x0EEC (size: 0x1)
    bool CanInteractAgain?;                                                           // 0x0EED (size: 0x1)
    class UObject* Avatar;                                                            // 0x0EF0 (size: 0x8)
    FString UserName;                                                                 // 0x0EF8 (size: 0x10)
    TArray<class APlayerTagActor_C*> PlayerTags;                                      // 0x0F08 (size: 0x10)
    class AGameStartService_C* GameStartService;                                      // 0x0F18 (size: 0x8)
    int32 LobbyMinutes;                                                               // 0x0F20 (size: 0x4)
    int32 LobbySeconds;                                                               // 0x0F24 (size: 0x4)
    class ULobbyCountDown_C* LobbyUI;                                                 // 0x0F28 (size: 0x8)
    FTimerHandle LobbyTimer;                                                          // 0x0F30 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0F38 (size: 0x10)
    class ABP_FirstPersonCharacter_C* LastPlayerWNameTag;                             // 0x0F48 (size: 0x8)
    bool ShowRadioItem;                                                               // 0x0F50 (size: 0x1)
    bool IsTalking?;                                                                  // 0x0F51 (size: 0x1)
    bool Radio;                                                                       // 0x0F52 (size: 0x1)
    FBP_FirstPersonCharacter_CToggleRadio ToggleRadio;                                // 0x0F58 (size: 0x10)
    void ToggleRadio(bool bUseRadio);
    bool StartedInfection?;                                                           // 0x0F68 (size: 0x1)
    FTimerHandle Infection Timer;                                                     // 0x0F70 (size: 0x8)
    bool Syringe;                                                                     // 0x0F78 (size: 0x1)
    class AItem_Syringe_C* SyringeItem;                                               // 0x0F80 (size: 0x8)
    bool ShowFlare;                                                                   // 0x0F88 (size: 0x1)
    class AItem_Flare_C* Item Flare;                                                  // 0x0F90 (size: 0x8)
    bool MotionDetect;                                                                // 0x0F98 (size: 0x1)
    class UVOIPTalker* VOIPtalkerComponent;                                           // 0x0FA0 (size: 0x8)
    class AEyeMonster_AI_C* EyeMonster;                                               // 0x0FA8 (size: 0x8)
    class ABP_ThirdPersonCharacter_C* Player Monster;                                 // 0x0FB0 (size: 0x8)
    bool bShouldSpawnControlledMonster;                                               // 0x0FB8 (size: 0x1)
    bool AllDead?;                                                                    // 0x0FB9 (size: 0x1)
    class ABP_Helicopter_C* As BP Helicopter;                                         // 0x0FC0 (size: 0x8)
    class ABP_Helicopter_C* HelicopterPTR;                                            // 0x0FC8 (size: 0x8)
    bool HelicopterDriver;                                                            // 0x0FD0 (size: 0x1)
    bool HelicopterPassenger;                                                         // 0x0FD1 (size: 0x1)
    bool BeefJerkyItem;                                                               // 0x0FD2 (size: 0x1)
    TArray<TEnumAsByte<ESkillTree::Type>> EquippedSkills;                             // 0x0FD8 (size: 0x10)
    class UJournal_C* Map;                                                            // 0x0FE8 (size: 0x8)
    class APawn* GasGuzzlerVehicle;                                                   // 0x0FF0 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> PlayersNearby;                          // 0x0FF8 (size: 0x10)
    int32 VaccineUse?;                                                                // 0x1008 (size: 0x4)
    class UClothingSaveGame_C* ClothingSave;                                          // 0x1010 (size: 0x8)
    TArray<class ABP_GeneratorGameplayNew_C*> Generators;                             // 0x1018 (size: 0x10)
    bool FoundGenJockey?;                                                             // 0x1028 (size: 0x1)
    bool UsingDesprationDashBoost?;                                                   // 0x1029 (size: 0x1)
    TArray<class ABP_ClassifiedMaterial_C*> ClassifiedMaterials;                      // 0x1030 (size: 0x10)
    FTimerHandle ParachutingHandle;                                                   // 0x1040 (size: 0x8)
    class AParachute_bp_C* ParachuteActor;                                            // 0x1048 (size: 0x8)
    class AFastLearner_AI_C* Fast Learner;                                            // 0x1050 (size: 0x8)
    bool Sniper;                                                                      // 0x1058 (size: 0x1)
    bool Aiming;                                                                      // 0x1059 (size: 0x1)
    bool Shooting;                                                                    // 0x105A (size: 0x1)
    class AItem_Sniper_C* SniperItem;                                                 // 0x1060 (size: 0x8)
    bool Shotgun;                                                                     // 0x1068 (size: 0x1)
    TArray<FTransform> RandomShotgunTransform;                                        // 0x1070 (size: 0x10)
    class AItem_Shotgun_C* ShotgunPTR;                                                // 0x1080 (size: 0x8)
    bool bRevolver;                                                                   // 0x1088 (size: 0x1)
    class AItem_Revolver_C* RevolverPTR;                                              // 0x1090 (size: 0x8)
    bool FlareGun;                                                                    // 0x1098 (size: 0x1)
    class AItem_FlareGun_C* Flare Gun Item;                                           // 0x10A0 (size: 0x8)
    bool bGrenade;                                                                    // 0x10A8 (size: 0x1)
    bool AimingGrenade;                                                               // 0x10A9 (size: 0x1)
    class AItem_Grenade_C* GrenadeItemPtr;                                            // 0x10B0 (size: 0x8)
    bool UsingComputer?;                                                              // 0x10B8 (size: 0x1)
    TArray<class ABP_9mm_Pprojectile_C*> ProjectileShot;                              // 0x10C0 (size: 0x10)
    bool CanHit;                                                                      // 0x10D0 (size: 0x1)
    class ADog_Infected_AI_C* Dog Infected;                                           // 0x10D8 (size: 0x8)
    bool FriendlyFire;                                                                // 0x10E0 (size: 0x1)
    FBP_FirstPersonCharacter_CTryingToInteract TryingToInteract;                      // 0x10E8 (size: 0x10)
    void TryingToInteract();
    class UAudioComponent* SearchMusic;                                               // 0x10F8 (size: 0x8)
    bool CanFadeMusic;                                                                // 0x1100 (size: 0x1)
    class UAudioComponent* AmbMusic;                                                  // 0x1108 (size: 0x8)
    class UAudioComponent* Attacking;                                                 // 0x1110 (size: 0x8)
    bool CanFadeAttack?;                                                              // 0x1118 (size: 0x1)
    class AHeadAI_C* Head AI;                                                         // 0x1120 (size: 0x8)
    class ABabyWorm_AI_C* Leech;                                                      // 0x1128 (size: 0x8)
    class AHusky_AI_C* Husky;                                                         // 0x1130 (size: 0x8)
    class UCharacterSettings_SaveGame_C* CharacterSettings;                           // 0x1138 (size: 0x8)
    double HelicopterSensitivityX;                                                    // 0x1140 (size: 0x8)
    double HelicopterSensitivityY;                                                    // 0x1148 (size: 0x8)
    class UEmoteSave_C* Emote Save;                                                   // 0x1150 (size: 0x8)
    class UAnimMontage* EquippedEmote;                                                // 0x1158 (size: 0x8)
    bool DestroyPoint;                                                                // 0x1160 (size: 0x1)
    bool ElusiveFighter;                                                              // 0x1161 (size: 0x1)
    FTimerHandle FireResitantTimer;                                                   // 0x1168 (size: 0x8)
    bool CanTakeFireDamage;                                                           // 0x1170 (size: 0x1)
    bool FlareIsLit;                                                                  // 0x1171 (size: 0x1)
    bool CanUseMap?;                                                                  // 0x1172 (size: 0x1)
    FPostProcessSettings Post Process Settings;                                       // 0x1180 (size: 0x6F0)
    bool UsingJetpack;                                                                // 0x1870 (size: 0x1)
    bool OpenDoor;                                                                    // 0x1871 (size: 0x1)
    class AInteract_HudClass_C* InteractHud;                                          // 0x1878 (size: 0x8)
    FVector InteractHudLocation;                                                      // 0x1880 (size: 0x18)
    class APickUp_Hud_Class_C* PickUpHud;                                             // 0x1898 (size: 0x8)
    FVector PickUpHudLocation;                                                        // 0x18A0 (size: 0x18)
    bool PickUpItemAnimation;                                                         // 0x18B8 (size: 0x1)
    int32 TimesInfected;                                                              // 0x18BC (size: 0x4)
    bool emoting?;                                                                    // 0x18C0 (size: 0x1)
    bool CanTakeTemperature;                                                          // 0x18C1 (size: 0x1)
    bool TakingVaccineAnimation;                                                      // 0x18C2 (size: 0x1)
    bool TakingVaccineAnimation2;                                                     // 0x18C3 (size: 0x1)
    class ABP_FirstPersonCharacter_C* MacroPlayer;                                    // 0x18C8 (size: 0x8)
    FRotator ControlRotationRep;                                                      // 0x18D0 (size: 0x18)
    FString UniqueNetIDSpecfic;                                                       // 0x18E8 (size: 0x10)
    bool WasHatEquipped?;                                                             // 0x18F8 (size: 0x1)
    bool UsingControlInputHard;                                                       // 0x18F9 (size: 0x1)
    FRotator LastControlRotation;                                                     // 0x1900 (size: 0x18)
    FRotator SnowmobileControlRotationPassenger;                                      // 0x1918 (size: 0x18)
    FBP_FirstPersonCharacter_CCheckForActionInput CheckForActionInput;                // 0x1930 (size: 0x10)
    void CheckForActionInput();
    bool CanTakeFallDamage;                                                           // 0x1940 (size: 0x1)
    bool DoPingAction;                                                                // 0x1941 (size: 0x1)
    FBP_FirstPersonCharacter_CEnemyAttackDelegate EnemyAttackDelegate;                // 0x1948 (size: 0x10)
    void EnemyAttackDelegate();
    FBP_FirstPersonCharacter_CUpdatePlayerList UpdatePlayerList;                      // 0x1958 (size: 0x10)
    void UpdatePlayerList(FString UserName);
    class USodaMachineUI_C* SodaMachineUI;                                            // 0x1968 (size: 0x8)
    FBP_FirstPersonCharacter_CCancelAction CancelAction;                              // 0x1970 (size: 0x10)
    void CancelAction();
    FBP_FirstPersonCharacter_CKeyboardCancelAction KeyboardCancelAction;              // 0x1980 (size: 0x10)
    void KeyboardCancelAction();
    class UDeathHud_C* DeathScreenHud;                                                // 0x1990 (size: 0x8)
    FKey InteractKey;                                                                 // 0x1998 (size: 0x18)
    int32 38Caliber;                                                                  // 0x19B0 (size: 0x4)
    bool ReloadingRevolver;                                                           // 0x19B4 (size: 0x1)
    double AmmoBeforeHand;                                                            // 0x19B8 (size: 0x8)
    int32 Buckshot;                                                                   // 0x19C0 (size: 0x4)
    bool ShotgunReloading;                                                            // 0x19C4 (size: 0x1)
    int32 7mmCaliber;                                                                 // 0x19C8 (size: 0x4)
    bool SniperReload;                                                                // 0x19CC (size: 0x1)
    int32 SniperReloadAmount;                                                         // 0x19D0 (size: 0x4)
    FTimerHandle SniperReloadTimer;                                                   // 0x19D8 (size: 0x8)
    FTimerHandle RevolverReloadTimer;                                                 // 0x19E0 (size: 0x8)
    bool pickaxe;                                                                     // 0x19E8 (size: 0x1)
    bool PickaxeSwing;                                                                // 0x19E9 (size: 0x1)
    FBP_FirstPersonCharacter_CRadioUpdate RadioUpdate;                                // 0x19F0 (size: 0x10)
    void RadioUpdate(bool State);
    FBP_FirstPersonCharacter_CUpdatePassengerState UpdatePassengerState;              // 0x1A00 (size: 0x10)
    void UpdatePassengerState();
    bool RadioStillOn?;                                                               // 0x1A10 (size: 0x1)
    FString FoundName;                                                                // 0x1A18 (size: 0x10)
    bool MP40;                                                                        // 0x1A28 (size: 0x1)
    FTimerHandle MP5FireRateHandle;                                                   // 0x1A30 (size: 0x8)
    class AItem_mp5_C* ItemMP5;                                                       // 0x1A38 (size: 0x8)
    int32 9mmCaliber;                                                                 // 0x1A40 (size: 0x4)
    bool mp5reload;                                                                   // 0x1A44 (size: 0x1)
    FTimerHandle mp5reloadhandle;                                                     // 0x1A48 (size: 0x8)
    class UAudioComponent* mp5reloadsoundeffect;                                      // 0x1A50 (size: 0x8)
    bool SnowcatDriver;                                                               // 0x1A58 (size: 0x1)
    bool SnowcatPassenger;                                                            // 0x1A59 (size: 0x1)
    class ABP_Snowcat_C* As BP Snowcat;                                               // 0x1A60 (size: 0x8)
    bool HasLicensedVehicle;                                                          // 0x1A68 (size: 0x1)
    class AActor* HeldItem;                                                           // 0x1A70 (size: 0x8)
    TArray<class AActor*> CurrentFlamethrowerTargets;                                 // 0x1A78 (size: 0x10)
    class AActor* CurrentMoving;                                                      // 0x1A88 (size: 0x8)
    bool CanPlaceMoving;                                                              // 0x1A90 (size: 0x1)
    TArray<FSHex> EquippedPerks;                                                      // 0x1A98 (size: 0x10)
    bool bTraitor;                                                                    // 0x1AA8 (size: 0x1)
    bool FoundAliveForMusic;                                                          // 0x1AA9 (size: 0x1)
    double PoolHitImpact;                                                             // 0x1AB0 (size: 0x8)
    FTimerHandle PoolTimerHandle;                                                     // 0x1AB8 (size: 0x8)
    bool AnimPoolQueHold;                                                             // 0x1AC0 (size: 0x1)
    bool EquipBarricade;                                                              // 0x1AC1 (size: 0x1)
    class AItem_Barricade_C* Barricade Item;                                          // 0x1AC8 (size: 0x8)
    int32 FIXMEPointsAdded;                                                           // 0x1AD0 (size: 0x4)

    bool CanBeSensed(class ANuclearNightmareCharacter* ResponsibleCharacter);
    bool InfectionDetector();
    void MSG_AVP_GetPlayerUsername(bool& Success?, FText& UserName);
    void MSG_AVP_GetWidgetVoice(class UWidgetComponent*& WidgetVoiceRef);
    void GetRagdollInfo(bool& IsRagdoll?, FVector& RagdollVelocity);
    void PassiveInteraction(FText& ActorName);
    void HasPerk(TEnumAsByte<EHex::Type> Perk Type, bool& HasPerk);
    void GetPlayerState(class ABP_NNFirstPersonPlayerState_C*& PlayerState, bool& Valid);
    void AddPoints(int32 Points);
    void DoesPlayerPingExist?(bool& Yes);
    void parachute(bool Enable);
    void Test Update Clothing(const FSClothingItem& SClothingItem);
    void ProtectiveAuraNearby?(bool& Yes);
    void FindClosetPawn(class ACharacter*& Return);
    void OnRep_IsTalking?();
    void FlameThrowerTickPlayer(bool& Succeed, class ABP_FirstPersonCharacter_C*& Player);
    void FlameThrowerTick(TArray<class AActor*>& ToReturn, TArray<class AActor*>& HitActors);
    void HeightTraceClimb();
    void FowardTraceClimb();
    void UpdateRagdoll();
    bool GetIsRagdoll?();
    void EnterExitSnowmobile(bool LocalPressed/Released);
    void ReplicatedLineTrace(FText& ActorName);
    void Enable/DisableCollision(bool Enable);
    void OnRep_Color();
    void UserConstructionScript();
    void Timeline_9__FinishedFunc();
    void Timeline_9__UpdateFunc();
    void Timeline_10__FinishedFunc();
    void Timeline_10__UpdateFunc();
    void Timeline_8__FinishedFunc();
    void Timeline_8__UpdateFunc();
    void NightVisionTimeline__FinishedFunc();
    void NightVisionTimeline__UpdateFunc();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline_3__FinishedFunc();
    void Timeline_3__UpdateFunc();
    void Timeline_6__FinishedFunc();
    void Timeline_6__UpdateFunc();
    void Timeline_5__FinishedFunc();
    void Timeline_5__UpdateFunc();
    void Timeline_4__FinishedFunc();
    void Timeline_4__UpdateFunc();
    void Timeline_11__FinishedFunc();
    void Timeline_11__UpdateFunc();
    void Timeline_7__FinishedFunc();
    void Timeline_7__UpdateFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void FlashlightSourceChange__FinishedFunc();
    void FlashlightSourceChange__UpdateFunc();
    void InpActEvt_IA_Emote_K2Node_EnhancedInputActionEvent_47(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Point_K2Node_EnhancedInputActionEvent_46(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_45(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Whistle_K2Node_EnhancedInputActionEvent_44(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_IA_InvSlot1_K2Node_EnhancedInputActionEvent_43(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_InvSlot2_K2Node_EnhancedInputActionEvent_42(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_InvSlot3_K2Node_EnhancedInputActionEvent_41(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_InvSlot4_K2Node_EnhancedInputActionEvent_40(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_InvSlot5_K2Node_EnhancedInputActionEvent_39(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollBackward_K2Node_EnhancedInputActionEvent_38(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollForward_K2Node_EnhancedInputActionEvent_37(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_06C8AB4E46B0DEE1D224C1B22463B187(FName NotifyName);
    void OnNotifyBegin_06C8AB4E46B0DEE1D224C1B22463B187(FName NotifyName);
    void OnInterrupted_06C8AB4E46B0DEE1D224C1B22463B187(FName NotifyName);
    void OnBlendOut_06C8AB4E46B0DEE1D224C1B22463B187(FName NotifyName);
    void OnCompleted_06C8AB4E46B0DEE1D224C1B22463B187(FName NotifyName);
    void InpActEvt_IA_Sprint_K2Node_EnhancedInputActionEvent_36(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_Enter_K2Node_InputKeyEvent_0(FKey Key);
    void OnFailure_CDFD7843418252CADB7BEDBA5C6A130C();
    void OnSuccess_CDFD7843418252CADB7BEDBA5C6A130C();
    void OnFailure_7051AD134016BB2A0B13D086C4FA95C5(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_7051AD134016BB2A0B13D086C4FA95C5(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_35(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_34(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_33(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_32(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_CDD8FB1E41EA1BE78FB19BB7F434BC7C(FName NotifyName);
    void OnNotifyBegin_CDD8FB1E41EA1BE78FB19BB7F434BC7C(FName NotifyName);
    void OnInterrupted_CDD8FB1E41EA1BE78FB19BB7F434BC7C(FName NotifyName);
    void OnBlendOut_CDD8FB1E41EA1BE78FB19BB7F434BC7C(FName NotifyName);
    void OnCompleted_CDD8FB1E41EA1BE78FB19BB7F434BC7C(FName NotifyName);
    void InpActEvt_IA_Notebook_K2Node_EnhancedInputActionEvent_31(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Map_K2Node_EnhancedInputActionEvent_30(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_5391467245CDDB818CBDA1ACFF37A2C0(FName NotifyName);
    void OnNotifyBegin_5391467245CDDB818CBDA1ACFF37A2C0(FName NotifyName);
    void OnInterrupted_5391467245CDDB818CBDA1ACFF37A2C0(FName NotifyName);
    void OnBlendOut_5391467245CDDB818CBDA1ACFF37A2C0(FName NotifyName);
    void OnCompleted_5391467245CDDB818CBDA1ACFF37A2C0(FName NotifyName);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_29(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_28(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_987B54F34EDA6A7786C759958E7F33AF(FName NotifyName);
    void OnNotifyBegin_987B54F34EDA6A7786C759958E7F33AF(FName NotifyName);
    void OnInterrupted_987B54F34EDA6A7786C759958E7F33AF(FName NotifyName);
    void OnBlendOut_987B54F34EDA6A7786C759958E7F33AF(FName NotifyName);
    void OnCompleted_987B54F34EDA6A7786C759958E7F33AF(FName NotifyName);
    void InpActEvt_IA_HideHud_K2Node_EnhancedInputActionEvent_27(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_F097218E4F51EBB68C7BBB87F542E839(FName NotifyName);
    void OnNotifyBegin_F097218E4F51EBB68C7BBB87F542E839(FName NotifyName);
    void OnInterrupted_F097218E4F51EBB68C7BBB87F542E839(FName NotifyName);
    void OnBlendOut_F097218E4F51EBB68C7BBB87F542E839(FName NotifyName);
    void OnCompleted_F097218E4F51EBB68C7BBB87F542E839(FName NotifyName);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_26(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_35B4302A4B601B5E0343BF895F8AE617(FName NotifyName);
    void OnNotifyBegin_35B4302A4B601B5E0343BF895F8AE617(FName NotifyName);
    void OnInterrupted_35B4302A4B601B5E0343BF895F8AE617(FName NotifyName);
    void OnBlendOut_35B4302A4B601B5E0343BF895F8AE617(FName NotifyName);
    void OnCompleted_35B4302A4B601B5E0343BF895F8AE617(FName NotifyName);
    void OnNotifyEnd_8409B5B043078D53E3C7E894FEDD0E66(FName NotifyName);
    void OnNotifyBegin_8409B5B043078D53E3C7E894FEDD0E66(FName NotifyName);
    void OnInterrupted_8409B5B043078D53E3C7E894FEDD0E66(FName NotifyName);
    void OnBlendOut_8409B5B043078D53E3C7E894FEDD0E66(FName NotifyName);
    void OnCompleted_8409B5B043078D53E3C7E894FEDD0E66(FName NotifyName);
    void OnFailure_8042EDEC402689675D1555B474D33CEB();
    void OnSuccess_8042EDEC402689675D1555B474D33CEB();
    void OnFailure_4F9FB0A04619DAAAD2F756B72BA40D99(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_4F9FB0A04619DAAAD2F756B72BA40D99(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnNotifyEnd_6578A4604F9241A363B776B989DE5D56(FName NotifyName);
    void OnNotifyBegin_6578A4604F9241A363B776B989DE5D56(FName NotifyName);
    void OnInterrupted_6578A4604F9241A363B776B989DE5D56(FName NotifyName);
    void OnBlendOut_6578A4604F9241A363B776B989DE5D56(FName NotifyName);
    void OnCompleted_6578A4604F9241A363B776B989DE5D56(FName NotifyName);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_25(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_82E2CF8E43F3B101890094B63B87B7DC(FName NotifyName);
    void OnNotifyBegin_82E2CF8E43F3B101890094B63B87B7DC(FName NotifyName);
    void OnInterrupted_82E2CF8E43F3B101890094B63B87B7DC(FName NotifyName);
    void OnBlendOut_82E2CF8E43F3B101890094B63B87B7DC(FName NotifyName);
    void OnCompleted_82E2CF8E43F3B101890094B63B87B7DC(FName NotifyName);
    void OnNotifyEnd_BAD4E113405CF724055956B367B42798(FName NotifyName);
    void OnNotifyBegin_BAD4E113405CF724055956B367B42798(FName NotifyName);
    void OnInterrupted_BAD4E113405CF724055956B367B42798(FName NotifyName);
    void OnBlendOut_BAD4E113405CF724055956B367B42798(FName NotifyName);
    void OnCompleted_BAD4E113405CF724055956B367B42798(FName NotifyName);
    void OnNotifyEnd_91326EAD465FB12506A2D58D7A8638D6(FName NotifyName);
    void OnNotifyBegin_91326EAD465FB12506A2D58D7A8638D6(FName NotifyName);
    void OnInterrupted_91326EAD465FB12506A2D58D7A8638D6(FName NotifyName);
    void OnBlendOut_91326EAD465FB12506A2D58D7A8638D6(FName NotifyName);
    void OnCompleted_91326EAD465FB12506A2D58D7A8638D6(FName NotifyName);
    void OnNotifyEnd_61E17D244BEBDFEE5F4AF093A56F3D7A(FName NotifyName);
    void OnNotifyBegin_61E17D244BEBDFEE5F4AF093A56F3D7A(FName NotifyName);
    void OnInterrupted_61E17D244BEBDFEE5F4AF093A56F3D7A(FName NotifyName);
    void OnBlendOut_61E17D244BEBDFEE5F4AF093A56F3D7A(FName NotifyName);
    void OnCompleted_61E17D244BEBDFEE5F4AF093A56F3D7A(FName NotifyName);
    void OnNotifyEnd_E79716D948D350A625626198B40AD6CA(FName NotifyName);
    void OnNotifyBegin_E79716D948D350A625626198B40AD6CA(FName NotifyName);
    void OnInterrupted_E79716D948D350A625626198B40AD6CA(FName NotifyName);
    void OnBlendOut_E79716D948D350A625626198B40AD6CA(FName NotifyName);
    void OnCompleted_E79716D948D350A625626198B40AD6CA(FName NotifyName);
    void OnNotifyEnd_77A2CC224F3B0577CE7CF0BFE5A962AD(FName NotifyName);
    void OnNotifyBegin_77A2CC224F3B0577CE7CF0BFE5A962AD(FName NotifyName);
    void OnInterrupted_77A2CC224F3B0577CE7CF0BFE5A962AD(FName NotifyName);
    void OnBlendOut_77A2CC224F3B0577CE7CF0BFE5A962AD(FName NotifyName);
    void OnCompleted_77A2CC224F3B0577CE7CF0BFE5A962AD(FName NotifyName);
    void OnNotifyEnd_E8A5B9414BA533A4019D4AA930C7C566(FName NotifyName);
    void OnNotifyBegin_E8A5B9414BA533A4019D4AA930C7C566(FName NotifyName);
    void OnInterrupted_E8A5B9414BA533A4019D4AA930C7C566(FName NotifyName);
    void OnBlendOut_E8A5B9414BA533A4019D4AA930C7C566(FName NotifyName);
    void OnCompleted_E8A5B9414BA533A4019D4AA930C7C566(FName NotifyName);
    void OnNotifyEnd_9004E7934AD82EC1BFBE3188667EADC6(FName NotifyName);
    void OnNotifyBegin_9004E7934AD82EC1BFBE3188667EADC6(FName NotifyName);
    void OnInterrupted_9004E7934AD82EC1BFBE3188667EADC6(FName NotifyName);
    void OnBlendOut_9004E7934AD82EC1BFBE3188667EADC6(FName NotifyName);
    void OnCompleted_9004E7934AD82EC1BFBE3188667EADC6(FName NotifyName);
    void OnNotifyEnd_F5D032DE4A0FF6F5CAB771AF6C174F7E(FName NotifyName);
    void OnNotifyBegin_F5D032DE4A0FF6F5CAB771AF6C174F7E(FName NotifyName);
    void OnInterrupted_F5D032DE4A0FF6F5CAB771AF6C174F7E(FName NotifyName);
    void OnBlendOut_F5D032DE4A0FF6F5CAB771AF6C174F7E(FName NotifyName);
    void OnCompleted_F5D032DE4A0FF6F5CAB771AF6C174F7E(FName NotifyName);
    void OnNotifyEnd_041465CF4AF99B0CE0CACE9510054987(FName NotifyName);
    void OnNotifyBegin_041465CF4AF99B0CE0CACE9510054987(FName NotifyName);
    void OnInterrupted_041465CF4AF99B0CE0CACE9510054987(FName NotifyName);
    void OnBlendOut_041465CF4AF99B0CE0CACE9510054987(FName NotifyName);
    void OnCompleted_041465CF4AF99B0CE0CACE9510054987(FName NotifyName);
    void InpActEvt_IA_ScrollBackward_K2Node_EnhancedInputActionEvent_24(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_DropItem_K2Node_EnhancedInputActionEvent_23(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_22(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Glowstick_K2Node_EnhancedInputActionEvent_21(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollForward_K2Node_EnhancedInputActionEvent_20(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Glowstick_K2Node_EnhancedInputActionEvent_19(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_18(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_17(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_16(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_15(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_14(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_13(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_12(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Glowstick_K2Node_EnhancedInputActionEvent_11(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollBackward_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollForward_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Reload_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_DropItem_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollBackward_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_ScrollForward_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_3456229349998F8181185A8EE2B80FD1(FName NotifyName);
    void OnNotifyBegin_3456229349998F8181185A8EE2B80FD1(FName NotifyName);
    void OnInterrupted_3456229349998F8181185A8EE2B80FD1(FName NotifyName);
    void OnBlendOut_3456229349998F8181185A8EE2B80FD1(FName NotifyName);
    void OnCompleted_3456229349998F8181185A8EE2B80FD1(FName NotifyName);
    void OnFailure_B2D741CF471C30D819408EA3E0D1AC18(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_B2D741CF471C30D819408EA3E0D1AC18(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_AA4F44D2495D252DADE0DC913D3B5826();
    void OnSuccess_AA4F44D2495D252DADE0DC913D3B5826();
    void InpActEvt_IA_Sprint_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_1B4C8E6444AF6237D777CCACB32D2C75(FName NotifyName);
    void OnNotifyBegin_1B4C8E6444AF6237D777CCACB32D2C75(FName NotifyName);
    void OnInterrupted_1B4C8E6444AF6237D777CCACB32D2C75(FName NotifyName);
    void OnBlendOut_1B4C8E6444AF6237D777CCACB32D2C75(FName NotifyName);
    void OnCompleted_1B4C8E6444AF6237D777CCACB32D2C75(FName NotifyName);
    void OnNotifyEnd_26E7760A4D12CE1035DCAB972C822FAD(FName NotifyName);
    void OnNotifyBegin_26E7760A4D12CE1035DCAB972C822FAD(FName NotifyName);
    void OnInterrupted_26E7760A4D12CE1035DCAB972C822FAD(FName NotifyName);
    void OnBlendOut_26E7760A4D12CE1035DCAB972C822FAD(FName NotifyName);
    void OnCompleted_26E7760A4D12CE1035DCAB972C822FAD(FName NotifyName);
    void OnNotifyEnd_C582E0A24F9595D44FB6CB99468EBAE9(FName NotifyName);
    void OnNotifyBegin_C582E0A24F9595D44FB6CB99468EBAE9(FName NotifyName);
    void OnInterrupted_C582E0A24F9595D44FB6CB99468EBAE9(FName NotifyName);
    void OnBlendOut_C582E0A24F9595D44FB6CB99468EBAE9(FName NotifyName);
    void OnCompleted_C582E0A24F9595D44FB6CB99468EBAE9(FName NotifyName);
    void OnNotifyEnd_A71B027A4D8BB1024418A9AE4C32BC3F(FName NotifyName);
    void OnNotifyBegin_A71B027A4D8BB1024418A9AE4C32BC3F(FName NotifyName);
    void OnInterrupted_A71B027A4D8BB1024418A9AE4C32BC3F(FName NotifyName);
    void OnBlendOut_A71B027A4D8BB1024418A9AE4C32BC3F(FName NotifyName);
    void OnCompleted_A71B027A4D8BB1024418A9AE4C32BC3F(FName NotifyName);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_PeakRight_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_PeakRight_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void DestroyPingServer(FString InString, FVector SpawnTransform Location);
    void PingServer(FString InString, FVector SpawnTransform Location);
    void UpdateCurrentEmoteState();
    void StopCurrentEmote();
    void WhistleALL();
    void WhistleServer();
    void EnablePerk(FSHex PerkInfo);
    void StartSodaMachine(class ASodaMachineBP_C* VendingMachineRef);
    void SelectingPerc(FSHex Return);
    void PlayMontageServer(class UAnimMontage* MontageToPlay, FName StartingSection, bool DisableThirdPerson);
    void PlayMontageALL(class UAnimMontage* MontageToPlay, FName StartingSection, bool DisableThirdPerson);
    void AddPerk(FSHex Info);
    void AddPerkServer(FSHex Info);
    void DoggyTreatsServer();
    void DoggyTreatsAll();
    void ClassifiedCollector();
    void Parachuting();
    void ParachuteServer(bool Enable);
    void ParachuteMulti(bool Enable);
    void ShowColaCan(bool TRUE);
    void ShowCola(bool TRUE);
    void HealthRegeneration();
    void AddHealth();
    void AddHealthServer();
    void CampConuciler();
    void ShowJetPack();
    void ShowJetpackServer();
    void UseJetpackAll(FVector Impluse);
    void UseJetpack(FVector Impluse);
    void UpdateLobbyTime();
    void RPCUpdateLobbyTime();
    void DestroyedGenPerkMachineUICheck();
    void IgnoredPerk();
    void SetPointsMult(int32 Points);
    void UpdateHuskyBehaviorRPC(class AHusky_AI_C* Husky, TEnumAsByte<HuskyBehavior::Type> Behavior);
    void PlaySoundAtLocationRPC(class USoundBase* Sound, FVector Location, class USoundAttenuation* AttenuationSettings, float VolumeMultiplier, FRotator Rotation);
    void PlaySoundAtLocationClient(class USoundBase* Sound, FVector Location, class USoundAttenuation* AttenuationSettings, float VolumeMultiplier, FRotator Rotation);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void EnterExitSnowmobileServer(bool Pressed);
    void StopRagDollServer();
    void StopRagdollMulti();
    void DrownOnServer();
    void DrownMulti();
    void Drown();
    void AutoDepthOfField();
    void StopAmbience(class USoundBase* Sound);
    void ContinueAmbience();
    void BurnStalker(class AStalker_AI_C* Stalker, double DamageAmount);
    void BurnStalkerMulti(class AStalker_AI_C* Stalker, double DamageAmount);
    void BloodFXserver();
    void BloodFX();
    void SnowmobileAttack(class AStalker_AI_C* Stalker);
    void WormDeath();
    void WormDeathMulti();
    void ForceOffSnowmobile();
    void ForceOffSnowmobileMulti();
    void FlashlightPowerOut();
    void FlashlightMultiOut();
    void BurnFX(bool bNewActive, class ABP_FirstPersonCharacter_C* Character, float DamageAmount);
    void BurnFXALL(bool bNewActive, class ABP_FirstPersonCharacter_C* Character, float DamageAmount);
    void PassengerExit(class ABP_Snowmobile_C* Snowmobile);
    void PassengerExitAll(class ABP_Snowmobile_C* Snowmobile);
    void CheckForRadio();
    void HelicopterPassengerExit(class ABP_Helicopter_C* Heli);
    void HeliExitPassenger(class ABP_Helicopter_C* Heli);
    void StartFireResitantTimer();
    void FireResitantLoop();
    void NightVision();
    void PlayPickUpAnimationEvent();
    void ReplicatePickUpAnimation();
    void RPCPickUpAnimation();
    void RPCUpdateTemperature(double Temperature);
    void RPCUpdateTemperatureALL(double Temperature);
    void DropItemOnDamageEvent();
    void UpdateNetID(FString ID);
    void RPCUpdateNetID(FString ID);
    void UpdateControlRotation(bool bEnabled);
    void UpdateControlRotationServer(bool bEnabled);
    void ReplicateSnowmobileMovement(FRotator Rotation);
    void ReplicateSnowmobileRPCMovement(FRotator Rotator);
    void TakeFallDamage();
    void SafeLockInput();
    void ReleaseAll();
    void BeginPlayMethod();
    void TryInteractNotify();
    void Add/RemoveRadioChannel(class APlayerState* PlayerState, bool bAdd);
    void Update Player List(FString UserName);
    void SnowcatExitAll(class ABP_Snowcat_C* Snowcat);
    void SnowcatExitServer(class ABP_Snowcat_C* Snowcat);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void MoveServer(FVector Dest, FRotator Rotation);
    void SetMoving(class AActor* Actor, bool Calling);
    void SetMovingHiddenAll(class AActor* Actor, bool Hidden);
    void KillAll();
    void BurnMadAll(class AMadPatent_AI_C* Mad, double Damage);
    void BurnMad(class AMadPatent_AI_C* Mad, double Damage);
    void BurnPlayer(class ABP_FirstPersonCharacter_C* Player, bool bNewActive);
    void BurnPlayerServer(class ABP_FirstPersonCharacter_C* Player);
    void BurnSCPMulti(class ASCP_AI_C* SCP, double DamageAmount);
    void BurnSCP(class ASCP_AI_C* SCP, double DamageAmount);
    void ShowInventory();
    void JoinedGameALL(FString UserName, FString Location);
    void JoinedGameServer(FString UserName, FString Location);
    void HelicopterObjComp(class UObject* Avatar, FString UserName, int32 MaterialAt, int32 OutOf, FString Location);
    void HelicopterObjectiveComplete(class UObject* Avatar, FString UserName, int32 MaterialAt, int32 OutOf, FString Location);
    void ClassifiedMatMulti(class UObject* Avatar, FString UserName, int32 MaterialAt, int32 OutOf);
    void ClassifiedMaterialOverlay(class UObject* Avatar, FString UserName, int32 MaterialAt, int32 OutOf);
    void MultiInteract(class UObject* Target, class ABP_FirstPersonCharacter_C* Character);
    void ServerInteract(class UObject* Target, class ABP_FirstPersonCharacter_C* Character);
    void RandomChanceForInfection(class ABP_FirstPersonCharacter_C* Character);
    void UpdateInfectionStatServer(bool bool, class ABP_FirstPersonCharacter_C* Char);
    void UpdateInfectionStatus(bool bool, class ABP_FirstPersonCharacter_C* Char);
    void BI_AI_SERVER(class ABP_FirstPersonCharacter_C* Character);
    void BI_AI(class ABP_FirstPersonCharacter_C* Character);
    void BecomeInfected();
    void StartInfectionProcess();
    void AttackPInfectedAll(class ABP_FirstPersonCharacter_C* Character);
    void AttackPInfectedServer(class ABP_FirstPersonCharacter_C* Character);
    void FinishInfection(bool Finishing);
    void StartInfection(bool Finishing);
    void InteractiveText();
    void PickUpIconRemove();
    void PickUpIconShow(FVector PickUpLocation);
    void UpdateSpawnQueAll();
    void UpdateSpawnQue();
    void UpdateDamageAll(float Damage Multipler);
    void UpdateDamage(float Damage Multipler);
    void DamageEffect();
    void DeathEvent();
    void GotOutOfCarTOOFAST();
    void AddToQueueRPC();
    void UpdateVoiceChannelsAfterDeath();
    void ResetDeathLock();
    void SpawnSpectorMulti(class AController* Controller, bool bSpawnPM);
    void SpawnSpecator(class AController* Controller, bool SpawnPlayerMonster);
    void Spectate();
    void FallDamageMulti();
    void FallDamageServer();
    void MoreDeathFX();
    void FallDamage(TEnumAsByte<EFallDamageType::Type> DamageType);
    void EnemyAttack(class AStalker_AI_C* Stalker);
    void PlayDamageEvent(class AStalker_AI_C* Stalker, bool Chance);
    void SpawnBloodPuddle();
    void StopMontageMulti(class ACharacter* Target, class UAnimMontage* AnimMontage);
    void StopMontage(class ACharacter* Target, class UAnimMontage* AnimMontage);
    void PlayMontageAttackServer(class USkeletalMeshComponent* Mesh, class UAnimMontage* MontageToPlay);
    void PlayMontageAttack(class USkeletalMeshComponent* Mesh, class UAnimMontage* MontageToPlay);
    void Disable/EnableClientInput(bool Enable);
    void Showbarricadeall(bool Equip);
    void ToggleBarricade(bool Equip, class AItem_Barricade_C* BarricadeItem);
    void DisableXRay(class USkeletalMeshComponent* Mesh);
    void DamageFlamethrowerTargetsServer(TArray<class AActor*>& Array);
    void ReufelSnowcat(double Fuel, class ABP_Snowcat_C* Snowcat);
    void RPCRefuelSnowcat(double Fuel, class ABP_Snowcat_C* Snowcat);
    void ShowMP5(bool TRUE, class AItem_mp5_C* mp5);
    void Equip/Unequip MP5(bool Show, class AItem_mp5_C* mp5);
    void EatBeefJerky();
    void DropFlareOnScroll(int32 CurrentSlot);
    void RPCUseSyringe();
    void UseSyring();
    void RPCTakePainkillers();
    void DoPainkillerTakeServer();
    void DropFlareFromEvent();
    void DropFlareServer();
    void DropFlareAll();
    void ShowGrenadeServer(bool Show, class AItem_Grenade_C* Grenade);
    void ShowGrenade(bool Show, class AItem_Grenade_C* Grenade);
    void ShowFlareGunServer(bool Show, class AItem_FlareGun_C* Flare Gun);
    void ShowFlareGun(bool Show, class AItem_FlareGun_C* Flare Gun Item);
    void ShowRevolverServer(bool Show, class AItem_Revolver_C* Revolver);
    void ShowRevolver(bool Show, class AItem_Revolver_C* Revolver);
    void FinalShotgunVis(bool Show, class AItem_Shotgun_C* Shotgun);
    void ShowPutAwayShotgun(bool Show, class AItem_Shotgun_C* Shotgun);
    void SniperItemEventALL(bool Show, class AItem_Sniper_C* Sniper Item);
    void ShowPutAwaySniper(bool Show, class AItem_Sniper_C* Sniper Item);
    void SpawnFireServer(FVector Location);
    void SpawnFire(FVector Location);
    void BeefJerkyRPC(bool bool);
    void ToggleBeefJerky(bool bool);
    void HelicopterFuelServer(double Fuel, class ABP_Helicopter_C* Helicopter);
    void HelicopterFuelUpdate(double Fuel, class ABP_Helicopter_C* Helicopter);
    void EyeMonsterDamageAll(class AEyeMonster_AI_C* EyeMonster);
    void EyeMonsterDamage(class AEyeMonster_AI_C* EyeMonster);
    void ShowMotionDetect();
    void HideMotionDetect();
    void ToggleMotionDetect(bool bool);
    void SpawnFlareOnAll();
    void SpawnFlareServer();
    void EquipFlare(class AItem_Flare_C* Item Flare);
    void HideFlareMulti();
    void ShowFlareMulti();
    void ToggleFlare(bool bool);
    void UpdateVaccineTemp();
    void EquipSyringe(class AItem_Syringe_C* SyringeItem);
    void ToggleSyringe(bool bool);
    void ShowSyringMulti();
    void HideSyringeMulti();
    void HideRadioMulti();
    void HideRadio();
    void ShowRadioMulti();
    void ShowRadio();
    void UpdateFTFuel(class AItem_Flamethrower_C* Flamethrower, double Fuel);
    void UpdateFTFuelMulti(class AItem_Flamethrower_C* Flamethrower, double Fuel);
    void StartStopFTMulti(bool Start);
    void Start/StopFlamethrower(bool Start);
    void Show/PutAwayFTClient(bool Show, class AItem_Flamethrower_C* FlameThrowerItem);
    void Show/PutAwayFT(bool Show, class AItem_Flamethrower_C* FlameThrowerItem);
    void HidePainkillersMulti();
    void HidePainkillers();
    void ShowPainkillersMulti();
    void ShowPainkillers();
    void UpdateHealthMutlicast(double Health);
    void UpdateHealth(double Health);
    void EquipedPainkillers(class AItem_Painkillers_C* Painkillers);
    void StopRefuelFXMulti();
    void StopRefuelFx();
    void RefuelingFXMulti();
    void RefuelingFX();
    void GasCainsterFuelUpdateMulti(class AItem_GasCanster_C* Target, double Fuel);
    void GasCainsterFuelUpdate(class AItem_GasCanster_C* Target, double Fuel);
    void SnowmobileFuelUpdateMulti(double Fuel, class ABP_Snowmobile_C* Target);
    void SnowmobileFuelUpdate(double Fuel, class ABP_Snowmobile_C* Target);
    void EquipedGasCainster(class AItem_GasCanster_C* GasCainster);
    void PutAwayItemMulti();
    void PutAwayItem();
    void HoldItemMultiCast();
    void HoldItem();
    void UpdateTempServer(double Temperature);
    void UpdateTemp(double Temperature);
    void ChangeTempColorMulti();
    void ChangeTempColorServer();
    void LoadEquippedMontage();
    void UpdateSavedClothesClient();
    void UpdateSavedClothesServer();
    void UpdateSavedClothesLocally();
    void UpdatePlayerColorServer(FLinearColor Value);
    void UpdatePlayerColorAll(FLinearColor Value);
    void UpdateSavedClothes();
    void UpdateClothingServer(const FSClothingItem& SClothingItem);
    void UpdateClothingItemALL(const FSClothingItem& SClothingItem);
    void FireHeldItemServer();
    void RPCMP5ParticalReloadRequest(double AmmoBeforeHand, int32 9MM, double FinishedCalculation);
    void MP5PartialReloadRequest(double AmmoBeforeHand, int32 9MM, double FinishedCalculation);
    void MP5ReloadPARTIAL();
    void RPCReloadMP5(double AmmoBeforeHand, int32 9MM);
    void ReloadMp5(double AmmoBeforeHand, int32 9MM);
    void add9mm();
    void Add9mmsHOTSALL(int32 9MM);
    void Add9mmShots();
    void RPCShootMP5(bool Stop);
    void StopMP5();
    void ShootMP5();
    void mp5Fire();
    void PickaxeKillAll();
    void PickaxePlayerKill();
    void RPCFinishRevolverReload(double AmmoBeforeHand, double Calc, int32 38);
    void RevolverFinishedReload(double AmmoBeforeHand, double Calc, int32 38);
    void RevolverReloadTimedEvent();
    void FindStopReloads();
    void SniperReloadEventServer(double AmmoBeforeHand, double FinishedCalculation, int32 7mmCaliberAmount);
    void SniperReloadEventAll(double AmmoBeforeHand, double FinishedCalculation, int32 7mmCaliberAmount);
    void RPCCancelOutReloads();
    void UpdateAmmoSniper();
    void CancelOutReloads();
    void RPCSniperReload(double AmmoBeforeHand, int32 7mm);
    void SniperReloadEvent(double AmmoBeforeHand, int32 7mm);
    void Add7mm();
    void AddSniperShotsAll(int32 SniperShots);
    void AddSniperShots();
    void ServerReloadShotgun(double AmmoBeforeHand, int32 Buckshot);
    void RPCReloadShotgun(double AmmoBeforeHand, int32 Buckshot);
    void AddBuckshotServer();
    void AddBuckshotAll(int32 Buckshot);
    void AddBuckshot();
    void RPCRevolverReload(int32 38Caliber, double AmmoBeforeHand);
    void ReloadRevolverMulticast(int32 38Caliber, double AmmoBeforeHand);
    void Add38Caliber();
    void AddReolverShotsAll(int32 38Caliber);
    void AddReolverShots();
    void EndSniperAim();
    void AimGrenadeServer();
    void AimGrenade();
    void ThrowGrenadeServer(FTransform SpawnTransform, FVector Impulse);
    void throwgrenade(FTransform SpawnTransform, FVector Impulse);
    void SpawnFSServer(FTransform Transform);
    void SpawnFlareSignal(FTransform Transform);
    void ReolverServer(FTransform Projectile);
    void RelvolverShot(FTransform Projectile);
    void ShotgunALL(const TArray<FTransform>& Projectiles);
    void ShootShotgunServer(FTransform ProjectileTransform);
    void SniperHitEventALL(FName bone);
    void SniperHitEvent(FName bone);
    void BndEvt__BP_FirstPersonCharacter_Mesh_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ShootSniperALL(FTransform ProjectileTransform);
    void ShootSniper(FTransform ProjectileTransform);
    void StartAmbienceEarly();
    void BndEvt__BP_FirstPersonCharacter_MusicSearcher_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__BP_FirstPersonCharacter_MusicSearcher_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ReinitaiteSettings();
    void ExecuteUbergraph_BP_FirstPersonCharacter(int32 EntryPoint);
    void UpdatePassengerState__DelegateSignature();
    void RadioUpdate__DelegateSignature(bool State);
    void KeyboardCancelAction__DelegateSignature();
    void CancelAction__DelegateSignature();
    void UpdatePlayerList__DelegateSignature(FString UserName);
    void EnemyAttackDelegate__DelegateSignature();
    void CheckForActionInput__DelegateSignature();
    void TryingToInteract__DelegateSignature();
    void ToggleRadio__DelegateSignature(bool bUseRadio);
    void RagdollOutOfCar__DelegateSignature();
}; // Size: 0x1AD4

#endif
