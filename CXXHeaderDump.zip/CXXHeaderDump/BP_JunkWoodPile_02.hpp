#ifndef UE4SS_SDK_BP_JunkWoodPile_02_HPP
#define UE4SS_SDK_BP_JunkWoodPile_02_HPP

class ABP_JunkWoodPile_02_C : public AActor
{
    class UStaticMeshComponent* SM_WheelBarrow;                                       // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_MetalPipes_2_StaticMeshComponent0;                 // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_WoodenBox2_StaticMeshComponent0;                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_MetalPipes_4_StaticMeshComponent0;                 // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_PlasticCover2_StaticMeshComponent0;                // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_Ladder2_StaticMeshComponent0;                      // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_JunkWoodPile2_StaticMeshComponent0;                // 0x02C0 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x02C8 (size: 0x8)

}; // Size: 0x2D0

#endif
