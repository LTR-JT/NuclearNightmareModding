#ifndef UE4SS_SDK_BP_SaveTree_HPP
#define UE4SS_SDK_BP_SaveTree_HPP

class UBP_SaveTree_C : public USaveGame
{
    FSSaveTree SaveTree;                                                              // 0x0028 (size: 0x28)

}; // Size: 0x50

#endif
