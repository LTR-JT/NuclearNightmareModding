#ifndef UE4SS_SDK_BP_SaveTree_HPP
#define UE4SS_SDK_BP_SaveTree_HPP

class UBP_SaveTree_C : public USaveGame
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0028 (size: 0x8)
    FSSaveTree SaveTree;                                                              // 0x0030 (size: 0x28)

    void ExecuteUbergraph_BP_SaveTree(int32 EntryPoint);
}; // Size: 0x58

#endif
