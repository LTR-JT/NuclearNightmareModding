#ifndef UE4SS_SDK_HeadingGuAGE_HPP
#define UE4SS_SDK_HeadingGuAGE_HPP

class UHeadingGuAGE_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UImage* Image;                                                              // 0x02E8 (size: 0x8)
    class UImage* Image_1;                                                            // 0x02F0 (size: 0x8)
    class UImage* Image_16;                                                           // 0x02F8 (size: 0x8)
    class UImage* Image_82;                                                           // 0x0300 (size: 0x8)
    class UTextBlock* TextBlock_52;                                                   // 0x0308 (size: 0x8)
    class ABP_Helicopter_C* Helicopter;                                               // 0x0310 (size: 0x8)
    class AWaypointActor_C* Waypoint;                                                 // 0x0318 (size: 0x8)

    FText GetText();
    void Construct();
    void Tick(FGeometry MyGeometry, float InDeltaTime);
    void ExecuteUbergraph_HeadingGuAGE(int32 EntryPoint);
}; // Size: 0x320

#endif
