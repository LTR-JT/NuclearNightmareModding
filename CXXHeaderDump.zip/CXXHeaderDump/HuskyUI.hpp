#ifndef UE4SS_SDK_HuskyUI_HPP
#define UE4SS_SDK_HuskyUI_HPP

class UHuskyUI_C : public UUserWidget
{
    class UImage* Image;                                                              // 0x02E0 (size: 0x8)
    class UImage* Image_1;                                                            // 0x02E8 (size: 0x8)
    class UImage* Image_2;                                                            // 0x02F0 (size: 0x8)

}; // Size: 0x2F8

#endif
