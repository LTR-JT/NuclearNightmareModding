namespace ENiagaraTriangleSamplingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator5 = 1,
        NewEnumerator7 = 2,
        NewEnumerator8 = 3,
        ENiagaraTriangleSamplingMode_MAX = 4,
    };
}

