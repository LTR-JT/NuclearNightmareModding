#ifndef UE4SS_SDK_DamageShake_HPP
#define UE4SS_SDK_DamageShake_HPP

class UDamageShake_C : public UDefaultCameraShakeBase
{
    char padding_0[0xE0];                                                             // 0x0000 (size: 0x0)
}; // Size: 0xE0

#endif
