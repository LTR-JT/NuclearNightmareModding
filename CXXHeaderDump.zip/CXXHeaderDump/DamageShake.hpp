#ifndef UE4SS_SDK_DamageShake_HPP
#define UE4SS_SDK_DamageShake_HPP

class UDamageShake_C : public UDefaultCameraShakeBase
{
}; // Size: 0xE0

#endif
