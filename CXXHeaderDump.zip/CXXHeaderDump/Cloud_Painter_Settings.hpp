#ifndef UE4SS_SDK_Cloud_Painter_Settings_HPP
#define UE4SS_SDK_Cloud_Painter_Settings_HPP

class UCloud_Painter_Settings_C : public UPrimaryDataAsset
{
    int32 View Mode;                                                                  // 0x0030 (size: 0x4)
    int32 Painting Mode;                                                              // 0x0034 (size: 0x4)
    double Brush Size;                                                                // 0x0038 (size: 0x8)
    class UTexture2D* Brush Texture;                                                  // 0x0040 (size: 0x8)
    double Brush Falloff;                                                             // 0x0048 (size: 0x8)
    double Brush Spacing;                                                             // 0x0050 (size: 0x8)
    double Brush Strength;                                                            // 0x0058 (size: 0x8)
    bool Show Grid;                                                                   // 0x0060 (size: 0x1)
    bool Lock Viewport;                                                               // 0x0061 (size: 0x1)
    char padding_0[0x6];                                                              // 0x0062 (size: 0x6)
    double Brush Angle;                                                               // 0x0068 (size: 0x8)

}; // Size: 0x70

#endif
