#ifndef UE4SS_SDK_LanguageMenu_HPP
#define UE4SS_SDK_LanguageMenu_HPP

class ULanguageMenu_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Create_3;                                                          // 0x02E8 (size: 0x8)
    class UMultipleSelectBox_C* MultipleSelectBox;                                    // 0x02F0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Driver;                                         // 0x02F8 (size: 0x8)

    void BndEvt__LanguageMenu_Create_3_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__LanguageMenu_MultipleSelectBox_K2Node_ComponentBoundEvent_1_OnSelectionChanged__DelegateSignature(FString SelectedOption, int32 SelectedIndex);
    void ExecuteUbergraph_LanguageMenu(int32 EntryPoint);
}; // Size: 0x300

#endif
