namespace ENiagaraBooleanLogicOps_v2 {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        NewEnumerator4 = 2,
        NewEnumerator5 = 3,
        NewEnumerator6 = 4,
        NewEnumerator7 = 5,
        ENiagaraBooleanLogicOps_MAX = 6,
    };
}

