#ifndef UE4SS_SDK_BP_Notifications_FL_HPP
#define UE4SS_SDK_BP_Notifications_FL_HPP

class UBP_Notifications_FL_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void SendNotification(const FSNotifications& NewNotification, class UObject* __WorldContext);
}; // Size: 0x28

#endif
