#ifndef UE4SS_SDK_BTT_FindRunAwayLoc_HPP
#define UE4SS_SDK_BTT_FindRunAwayLoc_HPP

class UBTT_FindRunAwayLoc_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    FVector Random Location;                                                          // 0x00D8 (size: 0x18)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindRunAwayLoc(int32 EntryPoint);
}; // Size: 0xF0

#endif
