namespace EAFSActiveType {
    enum Type {
        None = 0,
        USBOnly = 1,
        NetworkOnly = 2,
        Combined = 3,
        EAFSActiveType_MAX = 4,
    };
}

