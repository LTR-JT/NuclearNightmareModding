#ifndef UE4SS_SDK_HeadbobShake_HPP
#define UE4SS_SDK_HeadbobShake_HPP

class UHeadbobShake_C : public UCameraShakeBase
{
}; // Size: 0xE0

#endif
