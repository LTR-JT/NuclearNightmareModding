#ifndef UE4SS_SDK_AC_UI_Manager_Abstract_HPP
#define UE4SS_SDK_AC_UI_Manager_Abstract_HPP

class UAC_UI_Manager_Abstract_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    FAC_UI_Manager_Abstract_CInGameMenuVisibility InGameMenuVisibility;               // 0x00A8 (size: 0x10)
    void InGameMenuVisibility(bool Visible);

    void Create Ingame HUD();
    void Create Ingame Menu();
    void Reinitialize();
    void ExecuteUbergraph_AC_UI_Manager_Abstract(int32 EntryPoint);
    void InGameMenuVisibility__DelegateSignature(bool Visible);
}; // Size: 0xB8

#endif
