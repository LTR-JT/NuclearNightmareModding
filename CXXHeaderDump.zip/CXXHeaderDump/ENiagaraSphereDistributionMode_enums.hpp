namespace ENiagaraSphereDistributionMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator3 = 2,
        ENiagaraSphereDistributionMode_MAX = 3,
    };
}

