#ifndef UE4SS_SDK_BP_Morgue_Freezer_2_HPP
#define UE4SS_SDK_BP_Morgue_Freezer_2_HPP

class ABP_Morgue_Freezer_2_C : public AActor
{
    class UStaticMeshComponent* Mesh4;                                                // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Mesh1;                                                // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Mesh2;                                                // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Mesh3;                                                // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_DoorBack4;                    // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_DoorBack1;                    // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_DoorBack3;                    // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_DoorBack2;                    // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_BodyTray4;                           // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_BodyTray3;                           // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_BodyTray2;                           // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_BodyTray1;                           // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Rails4;                              // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Rails3;                              // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Rails2;                              // 0x0300 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Rails1;                              // 0x0308 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Chamber4;                            // 0x0310 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Chamber3;                            // 0x0318 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Chamber2;                            // 0x0320 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Chamber1;                            // 0x0328 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_Door4;                        // 0x0330 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_Door1;                        // 0x0338 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_Door2;                        // 0x0340 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_Door3;                        // 0x0348 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Fridge_Body;                         // 0x0350 (size: 0x8)
    class UStaticMeshComponent* Morgue_Fridge_SM_Refr;                                // 0x0358 (size: 0x8)
    double Door1Rotate;                                                               // 0x0360 (size: 0x8)
    double Door2Rotate;                                                               // 0x0368 (size: 0x8)
    double Door3Rotate;                                                               // 0x0370 (size: 0x8)
    double Door4Rotate;                                                               // 0x0378 (size: 0x8)
    bool ?FridgeOnTop;                                                                // 0x0380 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0381 (size: 0x7)
    double FridgeSlide;                                                               // 0x0388 (size: 0x8)
    double Tray1;                                                                     // 0x0390 (size: 0x8)
    double Tray2;                                                                     // 0x0398 (size: 0x8)
    double Tray3;                                                                     // 0x03A0 (size: 0x8)
    double Tray4;                                                                     // 0x03A8 (size: 0x8)
    class UStaticMesh* AddMesh1;                                                      // 0x03B0 (size: 0x8)
    class UStaticMesh* AddMesh2;                                                      // 0x03B8 (size: 0x8)
    class UStaticMesh* AddMesh3;                                                      // 0x03C0 (size: 0x8)
    class UStaticMesh* AddMesh4;                                                      // 0x03C8 (size: 0x8)

    void UserConstructionScript();
}; // Size: 0x3D0

#endif
