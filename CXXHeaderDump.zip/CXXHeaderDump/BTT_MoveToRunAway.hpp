#ifndef UE4SS_SDK_BTT_MoveToRunAway_HPP
#define UE4SS_SDK_BTT_MoveToRunAway_HPP

class UBTT_MoveToRunAway_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    bool FinishExec;                                                                  // 0x00D8 (size: 0x1)

    void OnFail_C1FC4CA04BE52C59016F1CA7F3A2AE1C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_C1FC4CA04BE52C59016F1CA7F3A2AE1C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_C0BFB4934D835DA545B6358AF1F7A070(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_C0BFB4934D835DA545B6358AF1F7A070(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_364306524F3DB2C42540B7AC01BA3005(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_364306524F3DB2C42540B7AC01BA3005(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MoveToRunAway(int32 EntryPoint);
}; // Size: 0xD9

#endif
