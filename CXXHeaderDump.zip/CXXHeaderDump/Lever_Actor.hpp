#ifndef UE4SS_SDK_Lever_Actor_HPP
#define UE4SS_SDK_Lever_Actor_HPP

class ALever_Actor_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0298 (size: 0x8)
    class USkeletalMeshComponent* LeverMesh;                                          // 0x02A0 (size: 0x8)
    class USkeletalMeshComponent* LeverBase;                                          // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    float Timeline_0_NewTrack_0_8003E665400A982ADCE3CF947813910F;                     // 0x02B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_8003E665400A982ADCE3CF947813910F; // 0x02BC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x02C0 (size: 0x8)
    float Timeline_NewTrack_0_C92207B94F776D733332FE9169F52573;                       // 0x02C8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_C92207B94F776D733332FE9169F52573; // 0x02CC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02D0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02D8 (size: 0x8)
    bool PoweredOn;                                                                   // 0x02E0 (size: 0x1)
    bool AllHavePoweredOn?;                                                           // 0x02E1 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_8CC1F0904CE76B6A42F9BA9695088621(FName NotifyName);
    void OnNotifyBegin_8CC1F0904CE76B6A42F9BA9695088621(FName NotifyName);
    void OnInterrupted_8CC1F0904CE76B6A42F9BA9695088621(FName NotifyName);
    void OnBlendOut_8CC1F0904CE76B6A42F9BA9695088621(FName NotifyName);
    void OnCompleted_8CC1F0904CE76B6A42F9BA9695088621(FName NotifyName);
    void OnFailure_853D0B5E47F20D2AF20DA88E5558781C();
    void OnSuccess_853D0B5E47F20D2AF20DA88E5558781C();
    void OnFailure_CA6BB9FC4214B37BA2B4D899AFB9F6B5(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_CA6BB9FC4214B37BA2B4D899AFB9F6B5(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void SecondaryInteraction();
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_Lever_Actor(int32 EntryPoint);
}; // Size: 0x2E2

#endif
