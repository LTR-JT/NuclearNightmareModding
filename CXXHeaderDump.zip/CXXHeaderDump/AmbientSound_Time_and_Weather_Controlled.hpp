#ifndef UE4SS_SDK_AmbientSound_Time_and_Weather_Controlled_HPP
#define UE4SS_SDK_AmbientSound_Time_and_Weather_Controlled_HPP

class AAmbientSound_Time_and_Weather_Controlled_C : public AAmbientSound
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0298 (size: 0x8)
    class AUltra_Dynamic_Sky_C* UDS;                                                  // 0x02A0 (size: 0x8)
    class AUltra_Dynamic_Weather_C* UDW;                                              // 0x02A8 (size: 0x8)
    double Daytime Volume Multiplier;                                                 // 0x02B0 (size: 0x8)
    bool Day;                                                                         // 0x02B8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02B9 (size: 0x7)
    double Nighttime Volume Multiplier;                                               // 0x02C0 (size: 0x8)
    double Snowy Volume Multiplier;                                                   // 0x02C8 (size: 0x8)
    double Rainy Volume Multiplier;                                                   // 0x02D0 (size: 0x8)
    double Dusty Volume Multiplier;                                                   // 0x02D8 (size: 0x8)
    double No Weather Volume Multiplier;                                              // 0x02E0 (size: 0x8)
    double Volume Multiplier Transition Time;                                         // 0x02E8 (size: 0x8)
    bool Snowing;                                                                     // 0x02F0 (size: 0x1)
    bool Raining;                                                                     // 0x02F1 (size: 0x1)
    bool Runtime;                                                                     // 0x02F2 (size: 0x1)
    char padding_1[0x5];                                                              // 0x02F3 (size: 0x5)
    double Target Volume Multiplier;                                                  // 0x02F8 (size: 0x8)
    bool First Test;                                                                  // 0x0300 (size: 0x1)
    bool Dusty;                                                                       // 0x0301 (size: 0x1)
    bool No UDS or UDW;                                                               // 0x0302 (size: 0x1)

    void Check if UDS and UDW Are Both Gone();
    void Start Up Sound();
    void Get UDS and UDW Reference();
    void Get Starting Dispatchers State();
    void Bind to Dispatchers();
    void Finished Dust();
    void Started Dust();
    void Update Volume Multiplier();
    void Finished Raining();
    void Finished Snowing();
    void Started Raining();
    void Started Snowing();
    void Sunset();
    void Sunrise();
    void UserConstructionScript();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void UDS Starting Up(class AUltra_Dynamic_Sky_C* UDS);
    void UDW Starting Up(class AUltra_Dynamic_Weather_C* UDW);
    void UDS Ending Play();
    void UDW Ending Play();
    void ExecuteUbergraph_AmbientSound_Time_and_Weather_Controlled(int32 EntryPoint);
}; // Size: 0x303

#endif
