namespace ENiagaraSocketSamplingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator5 = 1,
        ENiagaraSocketSamplingMode_MAX = 2,
    };
}

