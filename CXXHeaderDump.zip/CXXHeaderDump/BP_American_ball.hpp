#ifndef UE4SS_SDK_BP_American_ball_HPP
#define UE4SS_SDK_BP_American_ball_HPP

class ABP_American_ball_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_ball_15_American;                                  // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_ball_14_American;                                  // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_13_American;                                  // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_12_American;                                  // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_9_American;                                   // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_10_American;                                  // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_11_American;                                  // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_8_American;                                   // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_5_American;                                   // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_7_American;                                   // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_6_American;                                   // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_3_American;                                   // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* SM_ball_2_American;                                   // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* SM_ball_1_American;                                   // 0x0300 (size: 0x8)
    class UStaticMeshComponent* SM_triangle_American;                                 // 0x0308 (size: 0x8)
    class UStaticMeshComponent* SM_ball_0_American;                                   // 0x0310 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0318 (size: 0x8)

}; // Size: 0x320

#endif
