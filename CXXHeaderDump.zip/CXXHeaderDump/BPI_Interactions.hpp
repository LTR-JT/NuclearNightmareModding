#ifndef UE4SS_SDK_BPI_Interactions_HPP
#define UE4SS_SDK_BPI_Interactions_HPP

class IBPI_Interactions_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void PassiveInteraction(FText& ActorName);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
}; // Size: 0x28

#endif
