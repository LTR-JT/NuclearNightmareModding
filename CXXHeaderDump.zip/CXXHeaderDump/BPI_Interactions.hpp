#ifndef UE4SS_SDK_BPI_Interactions_HPP
#define UE4SS_SDK_BPI_Interactions_HPP

class IBPI_Interactions_C : public IInterface
{

    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PassiveInteraction(FText& ActorName);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
}; // Size: 0x28

#endif
