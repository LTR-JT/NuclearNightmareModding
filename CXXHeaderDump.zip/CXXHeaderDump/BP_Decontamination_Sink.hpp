#ifndef UE4SS_SDK_BP_Decontamination_Sink_HPP
#define UE4SS_SDK_BP_Decontamination_Sink_HPP

class ABP_Decontamination_Sink_C : public AActor
{
    class UStaticMeshComponent* StaticMesh5;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_T06_low;                                      // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_T04_low;                                      // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_T03_low;                                      // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_Door4;                                        // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_Door3;                                        // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_Door2;                                        // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_Door1;                                        // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* SM_Sink_Base;                                         // 0x02F8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0300 (size: 0x8)
    double OpenDoor_1st;                                                              // 0x0308 (size: 0x8)
    double OpenDoor_2nd;                                                              // 0x0310 (size: 0x8)
    double OpenDoor_3rd;                                                              // 0x0318 (size: 0x8)
    double OpenDoor_4th;                                                              // 0x0320 (size: 0x8)
    double Tap_1st;                                                                   // 0x0328 (size: 0x8)
    double Arm_1st_L;                                                                 // 0x0330 (size: 0x8)
    double Arm_1st_R;                                                                 // 0x0338 (size: 0x8)
    double Tap_2nd;                                                                   // 0x0340 (size: 0x8)
    double Arm_2nd_L;                                                                 // 0x0348 (size: 0x8)
    double Arm_2nd_R;                                                                 // 0x0350 (size: 0x8)
    double Tap_3rd;                                                                   // 0x0358 (size: 0x8)
    double Arm_3rd_L;                                                                 // 0x0360 (size: 0x8)
    double Arm_3rd_R;                                                                 // 0x0368 (size: 0x8)

    void RotateZ(double Z (Yaw), bool InvertZ, class USceneComponent* TargetMesh);
    void UserConstructionScript();
}; // Size: 0x370

#endif
