#ifndef UE4SS_SDK_BPP_drillingrigtents2_HPP
#define UE4SS_SDK_BPP_drillingrigtents2_HPP

class ABPP_drillingrigtents2_C : public APackedLevelActor
{
    class UHierarchicalInstancedStaticMeshComponent* HierarchicalInstancedStaticMesh1; // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0338 (size: 0x8)
    class UHierarchicalInstancedStaticMeshComponent* HierarchicalInstancedStaticMesh; // 0x0340 (size: 0x8)

}; // Size: 0x348

#endif
