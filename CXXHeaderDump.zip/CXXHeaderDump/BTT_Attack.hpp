#ifndef UE4SS_SDK_BTT_Attack_HPP
#define UE4SS_SDK_BTT_Attack_HPP

class UBTT_Attack_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Found Player;                                   // 0x00B0 (size: 0x8)
    FVector Random Location;                                                          // 0x00B8 (size: 0x18)

    void OnFail_328B967E4772219F34D1588B88FAE037(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_328B967E4772219F34D1588B88FAE037(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_Attack(int32 EntryPoint);
}; // Size: 0xD0

#endif
