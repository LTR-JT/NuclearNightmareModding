#ifndef UE4SS_SDK_AircraftGuage_HPP
#define UE4SS_SDK_AircraftGuage_HPP

class UAircraftGuage_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UImage* Image;                                                              // 0x02F0 (size: 0x8)
    class UImage* Image_1;                                                            // 0x02F8 (size: 0x8)
    class UImage* Image_2;                                                            // 0x0300 (size: 0x8)
    class UImage* Image_16;                                                           // 0x0308 (size: 0x8)
    class UImage* Image_82;                                                           // 0x0310 (size: 0x8)
    class UProgressBar* ProgressBar;                                                  // 0x0318 (size: 0x8)
    class UProgressBar* ProgressBar_25;                                               // 0x0320 (size: 0x8)
    class UTextBlock* TextBlock;                                                      // 0x0328 (size: 0x8)
    class UTextBlock* TextBlock_1;                                                    // 0x0330 (size: 0x8)
    class UTextBlock* TextBlock_2;                                                    // 0x0338 (size: 0x8)
    class UTextBlock* TextBlock_3;                                                    // 0x0340 (size: 0x8)
    class UTextBlock* TextBlock_52;                                                   // 0x0348 (size: 0x8)
    class ABP_Helicopter_C* Helicopter;                                               // 0x0350 (size: 0x8)
    FString B;                                                                        // 0x0358 (size: 0x10)

    float GetPercent_0();
    float GetPercent();
    FText GetText_3();
    FText GetText_2();
    FText GetText_1();
    FText GetText_0();
    FText GetText();
    void Construct();
    void Tick(FGeometry MyGeometry, float InDeltaTime);
    void MasterWarning(bool Cleared);
    void ExecuteUbergraph_AircraftGuage(int32 EntryPoint);
}; // Size: 0x368

#endif
