#ifndef UE4SS_SDK_BP_FunctionLibrary_HPP
#define UE4SS_SDK_BP_FunctionLibrary_HPP

class UBP_FunctionLibrary_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void CastBlueprintCharacter(class AActor* Actor, class UObject* __WorldContext, class ABP_Driver_C*& Character);
    void CastVehicleBase(class AActor* Actor, class UObject* __WorldContext, class ABP_Snowmobile_C*& Vehicle);
}; // Size: 0x28

#endif
