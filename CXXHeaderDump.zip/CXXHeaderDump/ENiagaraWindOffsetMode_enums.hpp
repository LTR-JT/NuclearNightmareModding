namespace ENiagaraWindOffsetMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraWindOffsetMode_MAX = 3,
    };
}

