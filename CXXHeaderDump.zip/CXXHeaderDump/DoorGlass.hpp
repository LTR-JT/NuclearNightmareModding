#ifndef UE4SS_SDK_DoorGlass_HPP
#define UE4SS_SDK_DoorGlass_HPP

class ADoorGlass_C : public ABP_Door_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0318 (size: 0x8)
    bool Broken?;                                                                     // 0x0320 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0321 (size: 0x7)
    FVector BrokenAtLOC;                                                              // 0x0328 (size: 0x18)

    void OnRep_Broken?();
    void BndEvt__DoorGlass_SM_Door_1_L_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void Glass Break(FVector Location);
    void GlassBreakServer(FVector Location);
    void ExecuteUbergraph_DoorGlass(int32 EntryPoint);
}; // Size: 0x340

#endif
