#ifndef UE4SS_SDK_DoorGlass_HPP
#define UE4SS_SDK_DoorGlass_HPP

class ADoorGlass_C : public ABP_Door_Base_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)
    bool Broken?;                                                                     // 0x0340 (size: 0x1)
    FVector BrokenAtLOC;                                                              // 0x0348 (size: 0x18)

    void OnRep_Broken?();
    void Glass Break(FVector Location);
    void GlassBreakServer(FVector Location);
    void RepEventExplodeServer(class AActor* DestroyingActor);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void ExecuteUbergraph_DoorGlass(int32 EntryPoint);
}; // Size: 0x360

#endif
