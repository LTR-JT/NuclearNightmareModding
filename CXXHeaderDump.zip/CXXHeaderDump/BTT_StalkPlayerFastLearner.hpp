#ifndef UE4SS_SDK_BTT_StalkPlayerFastLearner_HPP
#define UE4SS_SDK_BTT_StalkPlayerFastLearner_HPP

class UBTT_StalkPlayerFastLearner_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    class AStalker_AI_C* Stalker;                                                     // 0x00D8 (size: 0x8)
    FVector Random Location;                                                          // 0x00E0 (size: 0x18)
    bool FinishedTask?;                                                               // 0x00F8 (size: 0x1)
    class AFastLearner_AI_C* Stalker_0;                                               // 0x0100 (size: 0x8)

    void OnFail_8EAEE61D455E9070ABDB4C948EE0B61F(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_8EAEE61D455E9070ABDB4C948EE0B61F(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_StalkPlayerFastLearner(int32 EntryPoint);
}; // Size: 0x108

#endif
