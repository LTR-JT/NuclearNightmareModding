#ifndef UE4SS_SDK_BP_Drop_Counter_HPP
#define UE4SS_SDK_BP_Drop_Counter_HPP

class ABP_Drop_Counter_C : public AActor
{
    class UStaticMeshComponent* SM_Drop_Counter_wheel3;                               // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Drop_Counter_wheel2;                               // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Drop_Counter_wheel1;                               // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Drop_Counter_wheel;                                // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_4;                                      // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_3;                                      // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_2;                                      // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_1;                                      // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Drop_Counter_element_2;                            // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_Drop_Counter_element_1;                            // 0x02D8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E0 (size: 0x8)

}; // Size: 0x2E8

#endif
