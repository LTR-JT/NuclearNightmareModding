#ifndef UE4SS_SDK_LobbyCountDown_HPP
#define UE4SS_SDK_LobbyCountDown_HPP

class ULobbyCountDown_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation_1;                                           // 0x02E8 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02F0 (size: 0x8)
    class UOverlay* Overlay_0;                                                        // 0x02F8 (size: 0x8)
    class UProgressBar* ProgressBar_0;                                                // 0x0300 (size: 0x8)
    class UTextBlock* TextBlock_41;                                                   // 0x0308 (size: 0x8)
    class UTextBlock* TextBlock_58;                                                   // 0x0310 (size: 0x8)
    class UVerticalBox* VerticalBox_0;                                                // 0x0318 (size: 0x8)
    int32 Min;                                                                        // 0x0320 (size: 0x4)
    int32 Seconds;                                                                    // 0x0324 (size: 0x4)
    TArray<class ABP_FirstPersonCharacter_C*> Out Actors;                             // 0x0328 (size: 0x10)
    FTimerHandle Timer;                                                               // 0x0338 (size: 0x8)

    float GetPercent();
    FText GetText();
    void Construct();
    void CustomEvent();
    void Tick(FGeometry MyGeometry, float InDeltaTime);
    void CheckForPlayers();
    void UpdateList(FString UserName);
    void CallPlayerListUpdate();
    void ExecuteUbergraph_LobbyCountDown(int32 EntryPoint);
}; // Size: 0x340

#endif
