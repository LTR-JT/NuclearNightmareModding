#ifndef UE4SS_SDK_ABP_Quinn_HPP
#define UE4SS_SDK_ABP_Quinn_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{
    char padding_0[0x610];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x610

class UABP_Quinn_C : public UABP_Manny_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x26E8 (size: 0x8)

    void ExecuteUbergraph_ABP_Quinn(int32 EntryPoint);
}; // Size: 0x26F0

#endif
