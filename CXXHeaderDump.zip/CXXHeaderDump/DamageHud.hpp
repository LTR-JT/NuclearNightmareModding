#ifndef UE4SS_SDK_DamageHud_HPP
#define UE4SS_SDK_DamageHud_HPP

class UDamageHud_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* Damage;                                                   // 0x02E8 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F0 (size: 0x8)

    void Construct();
    void ExecuteUbergraph_DamageHud(int32 EntryPoint);
}; // Size: 0x2F8

#endif
