#ifndef UE4SS_SDK_BP_L_Shaped_Autopsy_Table_HPP
#define UE4SS_SDK_BP_L_Shaped_Autopsy_Table_HPP

class ABP_L_Shaped_Autopsy_Table_C : public AActor
{
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_5;                      // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_2;                      // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_4;                      // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_6;                      // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_hose;                       // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_1;                      // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_tap_3;                      // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_door_2;                     // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_drawer;                     // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_door_1;                     // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_L_Shaped_Autopsy_Table_body;                       // 0x02E0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E8 (size: 0x8)

}; // Size: 0x2F0

#endif
