#ifndef UE4SS_SDK_BP_OpenLand_RVT_Utils_HPP
#define UE4SS_SDK_BP_OpenLand_RVT_Utils_HPP

class UBP_OpenLand_RVT_Utils_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Invalidate RVTsPartial(bool Use MaterialRVT, bool Use HeightRVT, FVector Origin, double Radius, class UObject* __WorldContext);
    void InvalidateRVTs(bool Use MaterialRVT, bool Use HeightRVT, class UObject* __WorldContext);
}; // Size: 0x28

#endif
