#ifndef UE4SS_SDK_AnimBP_snowmobile_HPP
#define UE4SS_SDK_AnimBP_snowmobile_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_61;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_62;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_63;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_MeshRefPose;            // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_4;             // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_3;             // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_5;           // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_4;           // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_5;               // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_4;               // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_3;               // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_2;               // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_3;           // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_2;             // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_1;             // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone;               // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_2;           // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_1;               // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt;                 // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_WheelController;        // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0490 (size: 0x30)

}; // Size: 0x4C0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UAnimBP_snowmobile_C : public UVehicleAnimationInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0AF0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0AF8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0B00 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0B08 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x0B28 (size: 0x10)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0B38 (size: 0x20)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_4;                                      // 0x0B58 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_3;                                      // 0x0C48 (size: 0xF0)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;                                  // 0x0D38 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;                                  // 0x0E60 (size: 0x128)
    FAnimNode_LookAt AnimGraphNode_LookAt_5;                                          // 0x0F90 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt_4;                                          // 0x11E0 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt_3;                                          // 0x1430 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt_2;                                          // 0x1680 (size: 0x250)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;                                  // 0x18D0 (size: 0x128)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_2;                                      // 0x19F8 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_1;                                      // 0x1AE8 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone;                                        // 0x1BD8 (size: 0xF0)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;                                  // 0x1CC8 (size: 0x128)
    FAnimNode_LookAt AnimGraphNode_LookAt_1;                                          // 0x1DF0 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt;                                            // 0x2040 (size: 0x250)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x2290 (size: 0x128)
    FAnimNode_WheelController AnimGraphNode_WheelController;                          // 0x23B8 (size: 0xE0)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x2498 (size: 0x128)
    double BrakeRight;                                                                // 0x25C0 (size: 0x8)
    double BrakeLeft;                                                                 // 0x25C8 (size: 0x8)
    double WheelsRotator;                                                             // 0x25D0 (size: 0x8)
    FRotator Steering;                                                                // 0x25D8 (size: 0x18)
    FRotator SteeringWheelRotate;                                                     // 0x25F0 (size: 0x18)
    FRotator TowerRotate;                                                             // 0x2608 (size: 0x18)
    double Speed;                                                                     // 0x2620 (size: 0x8)
    double Fuel;                                                                      // 0x2628 (size: 0x8)
    double FuelGageRotation;                                                          // 0x2630 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void SteeringWheelMove();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_snowmobile_AnimGraphNode_ModifyBone_08414AD14E1D09F2510B949E38ECD9B6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_snowmobile_AnimGraphNode_ModifyBone_3D4C8C0144AF40795BCB7F92D5EA91F1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_snowmobile_AnimGraphNode_ModifyBone_A684BCF34D015F1189B999B16EF57B7B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_snowmobile_AnimGraphNode_ModifyBone_A6D564CA4D5313A9EE8BE4B7362A7E00();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_snowmobile_AnimGraphNode_ModifyBone_604AC8D441F85A64B93A16B5BD852B44();
    void Steer(double Speed, double Brake Left, double Brake Right, double Wheels);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_AnimBP_snowmobile(int32 EntryPoint);
}; // Size: 0x2638

#endif
