#ifndef UE4SS_SDK_MadreAnimBP_HPP
#define UE4SS_SDK_MadreAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    bool __BoolProperty_56;                                                           // 0x0001 (size: 0x1)
    float __FloatProperty_57;                                                         // 0x0004 (size: 0x4)
    float __FloatProperty_58;                                                         // 0x0008 (size: 0x4)
    bool __BoolProperty_59;                                                           // 0x000C (size: 0x1)
    EAnimSyncMethod __EnumProperty_60;                                                // 0x000D (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_61;                              // 0x000E (size: 0x1)
    FName __NameProperty_62;                                                          // 0x0010 (size: 0x8)
    FName __NameProperty_63;                                                          // 0x0018 (size: 0x8)
    int32 __IntProperty_64;                                                           // 0x0020 (size: 0x4)
    FName __NameProperty_65;                                                          // 0x0024 (size: 0x8)
    FName __NameProperty_66;                                                          // 0x002C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_67;                                         // 0x0038 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0058 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00D8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x00F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0120 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0150 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x0180 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x01B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x01E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0210 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x0240 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0270 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x02A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_3;           // 0x0300 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_2;           // 0x0330 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x0360 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x0390 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonFeetSolver;       // 0x03C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonSpineSolver;      // 0x03F0 (size: 0x30)

}; // Size: 0x420

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)

}; // Size: 0x8

class UMadreAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0390 (size: 0x80)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0410 (size: 0x48)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x0458 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0480 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x04F0 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0510 (size: 0xC8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x05D8 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x05F8 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0618 (size: 0x20)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x0638 (size: 0x28)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0660 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_3;                                  // 0x0680 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_2;                                  // 0x07E8 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x0950 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x0AB8 (size: 0x168)
    FAnimNode_DragonFeetSolver AnimGraphNode_DragonFeetSolver;                        // 0x0C20 (size: 0x9C0)
    FAnimNode_DragonSpineSolver AnimGraphNode_DragonSpineSolver;                      // 0x15E0 (size: 0xEC0)
    double Speed;                                                                     // 0x24A0 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_MadreAnimBP(int32 EntryPoint);
}; // Size: 0x24A8

#endif
