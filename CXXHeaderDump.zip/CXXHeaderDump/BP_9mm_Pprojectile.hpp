#ifndef UE4SS_SDK_BP_9mm_Pprojectile_HPP
#define UE4SS_SDK_BP_9mm_Pprojectile_HPP

class ABP_9mm_Pprojectile_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UAudioComponent* SC_Submachine_Fire;                                        // 0x0298 (size: 0x8)
    class URadialForceComponent* RadialForce1;                                        // 0x02A0 (size: 0x8)
    class UProjectileMovementComponent* ProjectileMovement1;                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_Projectile;                                        // 0x02B0 (size: 0x8)
    class USphereComponent* CollisionComponent;                                       // 0x02B8 (size: 0x8)
    double 9mm_Damage_Caused;                                                         // 0x02C0 (size: 0x8)
    class UParticleSystemComponent* Emiter;                                           // 0x02C8 (size: 0x8)
    double Decal_Life_Span;                                                           // 0x02D0 (size: 0x8)
    class UPrimitiveComponent* NewVar_0;                                              // 0x02D8 (size: 0x8)
    bool IsSniper?;                                                                   // 0x02E0 (size: 0x1)

    void ReceiveHit(class UPrimitiveComponent* MyComp, class AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_9mm_Pprojectile(int32 EntryPoint);
}; // Size: 0x2E1

#endif
