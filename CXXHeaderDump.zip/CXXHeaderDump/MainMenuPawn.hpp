#ifndef UE4SS_SDK_MainMenuPawn_HPP
#define UE4SS_SDK_MainMenuPawn_HPP

class AMainMenuPawn_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0318 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0320 (size: 0x8)
    bool Ready;                                                                       // 0x0328 (size: 0x1)

    void ReadyUp(bool Ready);
    void ReadyUpOnServer(bool Ready);
    void ExecuteUbergraph_MainMenuPawn(int32 EntryPoint);
}; // Size: 0x329

#endif
