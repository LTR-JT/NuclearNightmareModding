#ifndef UE4SS_SDK_BP_Cable_LightingWires_HPP
#define UE4SS_SDK_BP_Cable_LightingWires_HPP

class ABP_Cable_LightingWires_C : public AActor
{
    class USplineComponent* Spline1;                                                  // 0x0290 (size: 0x8)
    class USceneComponent* spline_mesh;                                               // 0x0298 (size: 0x8)
    class UMeshComponent* MeshComponent;                                              // 0x02A0 (size: 0x8)
    class UMaterialInstanceDynamic* Dynamic Material;                                 // 0x02A8 (size: 0x8)
    class UMaterialInstanceDynamic* Dynamic Material1;                                // 0x02B0 (size: 0x8)
    class UMaterialInstanceDynamic* Dynamic Material2;                                // 0x02B8 (size: 0x8)

    void UserConstructionScript();
}; // Size: 0x2C0

#endif
