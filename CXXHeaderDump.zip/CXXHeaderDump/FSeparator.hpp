#ifndef UE4SS_SDK_FSeparator_HPP
#define UE4SS_SDK_FSeparator_HPP

struct FFSeparator
{
    int32 Priority_10_E04421BD42003493FCCC7A9F81BC17F7;                               // 0x0000 (size: 0x4)

}; // Size: 0x4

#endif
