#ifndef UE4SS_SDK_BP_SnowmobileOld_HPP
#define UE4SS_SDK_BP_SnowmobileOld_HPP

class ABP_SnowmobileOld_C : public AWheeledVehiclePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UOpenLand_DeformComponent_C* OpenLand_DeformComponent2;                     // 0x0330 (size: 0x8)
    class UOpenLand_DeformComponent_C* OpenLand_DeformComponent1;                     // 0x0338 (size: 0x8)
    class UOpenLand_DeformComponent_C* OpenLand_DeformComponent;                      // 0x0340 (size: 0x8)
    class UArrowComponent* SpawnLocation_B;                                           // 0x0348 (size: 0x8)
    class UArrowComponent* SpawnLocation_R;                                           // 0x0350 (size: 0x8)
    class UArrowComponent* SpawnLocation_F;                                           // 0x0358 (size: 0x8)
    class UChaosWheeledVehicleMovementComponent* ChaosWheeledVehicleMovement;         // 0x0360 (size: 0x8)
    class UBoxComponent* BL_Light_Front;                                              // 0x0368 (size: 0x8)
    class UBoxComponent* BL_Light_back;                                               // 0x0370 (size: 0x8)
    class UBoxComponent* BL_Indictaor_R;                                              // 0x0378 (size: 0x8)
    class UBoxComponent* BL_Indictaor_L;                                              // 0x0380 (size: 0x8)
    class UPointLightComponent* Indicator_Light_L;                                    // 0x0388 (size: 0x8)
    class UAudioComponent* SC_Indicators;                                             // 0x0390 (size: 0x8)
    class UPointLightComponent* Indicator_Light_R;                                    // 0x0398 (size: 0x8)
    class UPointLightComponent* Indicator_Light_Back_R;                               // 0x03A0 (size: 0x8)
    class UPointLightComponent* Indicator_Light_Back_L;                               // 0x03A8 (size: 0x8)
    class UAudioComponent* SC_Horn;                                                   // 0x03B0 (size: 0x8)
    class UBoxComponent* TR_Enter_Vehicle;                                            // 0x03B8 (size: 0x8)
    class UParticleSystemComponent* PS_Exhasut_Smoke;                                 // 0x03C0 (size: 0x8)
    class UAudioComponent* SC_Indicators_On_OFF;                                      // 0x03C8 (size: 0x8)
    class UPointLightComponent* Back:_Light;                                          // 0x03D0 (size: 0x8)
    class USpotLightComponent* Front_Light;                                           // 0x03D8 (size: 0x8)
    class USpringArmComponent* Springarm_cockpit;                                     // 0x03E0 (size: 0x8)
    class UAudioComponent* SC_Stress;                                                 // 0x03E8 (size: 0x8)
    class UAudioComponent* SC_Engine;                                                 // 0x03F0 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x03F8 (size: 0x8)
    class UArrowComponent* SpawnLocation_L;                                           // 0x0400 (size: 0x8)
    class UAudioComponent* SC_Tracks;                                                 // 0x0408 (size: 0x8)
    class USpringArmComponent* SpringArmBack;                                         // 0x0410 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0418 (size: 0x8)
    class USpringArmComponent* SpringArmFront;                                        // 0x0420 (size: 0x8)
    float Timeline_Gagues_Gauges_07E1115C4656733CACF8408A93623790;                    // 0x0428 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_Gagues__Direction_07E1115C4656733CACF8408A93623790; // 0x042C (size: 0x1)
    class UTimelineComponent* Timeline_Gagues;                                        // 0x0430 (size: 0x8)
    float Timeline_indicator_back_R_Indicators_4DC0685248F842505FE2A2A65052A8A2;      // 0x0438 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_indicator_back_R__Direction_4DC0685248F842505FE2A2A65052A8A2; // 0x043C (size: 0x1)
    class UTimelineComponent* Timeline_indicator_back_R;                              // 0x0440 (size: 0x8)
    float Indicator_BL_Indicators_7C45AB45477EFA44CE7B1892B8E76ADD;                   // 0x0448 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Indicator_BL__Direction_7C45AB45477EFA44CE7B1892B8E76ADD; // 0x044C (size: 0x1)
    class UTimelineComponent* Indicator_BL;                                           // 0x0450 (size: 0x8)
    float Timeline_indicator_back_L_Indicators_F2BDE5B243754FB5193676BFAAA39441;      // 0x0458 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_indicator_back_L__Direction_F2BDE5B243754FB5193676BFAAA39441; // 0x045C (size: 0x1)
    class UTimelineComponent* Timeline_indicator_back_L;                              // 0x0460 (size: 0x8)
    float Timeline_indicator_side_R_Indicators_A0F8D0D44A21627C5C6765A90049E2F1;      // 0x0468 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_indicator_side_R__Direction_A0F8D0D44A21627C5C6765A90049E2F1; // 0x046C (size: 0x1)
    class UTimelineComponent* Timeline_indicator_side_R;                              // 0x0470 (size: 0x8)
    float Timeline_2_Indicators_inside_54958A434610DD4FC5811DA58EC12306;              // 0x0478 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_54958A434610DD4FC5811DA58EC12306; // 0x047C (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x0480 (size: 0x8)
    float Timeline_Handbrake_NewTrack_0_FE56ACE84C68724C7BACF19A7B76C91F;             // 0x0488 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_Handbrake__Direction_FE56ACE84C68724C7BACF19A7B76C91F; // 0x048C (size: 0x1)
    class UTimelineComponent* Timeline_Handbrake;                                     // 0x0490 (size: 0x8)
    float Timeline_Popup_light_NewTrack_0_65BAE35D4921C338C34B54A31C1B02EC;           // 0x0498 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_Popup_light__Direction_65BAE35D4921C338C34B54A31C1B02EC; // 0x049C (size: 0x1)
    class UTimelineComponent* Timeline_Popup_light;                                   // 0x04A0 (size: 0x8)
    float Timeline__Reverse_Velocity_NewTrack_0_0012366546AC0D3E66F74F80977AED06;     // 0x04A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Reverse_Velocity__Direction_0012366546AC0D3E66F74F80977AED06; // 0x04AC (size: 0x1)
    class UTimelineComponent* Timeline__Reverse_Velocity;                             // 0x04B0 (size: 0x8)
    TEnumAsByte<ETimelineDirection::Type> Timeline_springarm_arm_lenght__Direction_89E0020743CFADA9E942C7BEEC4363F5; // 0x04B8 (size: 0x1)
    class UTimelineComponent* Timeline_springarm_arm_lenght;                          // 0x04C0 (size: 0x8)
    float Timeline_boost_duration_Boost_delay_81DCF74641E3636AD6E72B9BE73FB185;       // 0x04C8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_boost_duration__Direction_81DCF74641E3636AD6E72B9BE73FB185; // 0x04CC (size: 0x1)
    class UTimelineComponent* Timeline_boost_duration;                                // 0x04D0 (size: 0x8)
    FVector Timeline_starting_nudge_NewTrack_0_59F36F8B445511A3317C3CA3356D7819;      // 0x04D8 (size: 0x18)
    TEnumAsByte<ETimelineDirection::Type> Timeline_starting_nudge__Direction_59F36F8B445511A3317C3CA3356D7819; // 0x04F0 (size: 0x1)
    class UTimelineComponent* Timeline_starting_nudge;                                // 0x04F8 (size: 0x8)
    double Health_Snowmobile;                                                         // 0x0500 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0508 (size: 0x8)
    bool Use_Snowmobile;                                                              // 0x0510 (size: 0x1)
    bool Handbrake;                                                                   // 0x0511 (size: 0x1)
    double Health_Refresh_rate;                                                       // 0x0518 (size: 0x8)
    double Health_refresh_cooldown;                                                   // 0x0520 (size: 0x8)
    bool Taking damage;                                                               // 0x0528 (size: 0x1)
    FName Physics_Tire_FR_1;                                                          // 0x052C (size: 0x8)
    FName Physics_Tire_FR_3;                                                          // 0x0534 (size: 0x8)
    FName Physics_Tire_FL_3;                                                          // 0x053C (size: 0x8)
    FName Physics_Tire_FL_1;                                                          // 0x0544 (size: 0x8)
    double Wheel_radius;                                                              // 0x0550 (size: 0x8)
    bool Use_Particles;                                                               // 0x0558 (size: 0x1)
    bool Use_Lights;                                                                  // 0x0559 (size: 0x1)
    bool Hide_Health_Widget_?;                                                        // 0x055A (size: 0x1)
    class UMaterialInstanceDynamic* Lights;                                           // 0x0560 (size: 0x8)
    double Delta_seconds;                                                             // 0x0568 (size: 0x8)
    class UParticleSystem* PS_Impact_emiiter;                                         // 0x0570 (size: 0x8)
    class USoundBase* Impac_sound;                                                    // 0x0578 (size: 0x8)
    bool bStuck_?;                                                                    // 0x0580 (size: 0x1)
    bool Use_vehicle_without_character_;                                              // 0x0581 (size: 0x1)
    double Move_forward;                                                              // 0x0588 (size: 0x8)
    double Invert_Pitch;                                                              // 0x0590 (size: 0x8)
    bool bDrive_Torque_Boost;                                                         // 0x0598 (size: 0x1)
    bool Use_boost;                                                                   // 0x0599 (size: 0x1)
    double Handbrake_torque;                                                          // 0x05A0 (size: 0x8)
    double Drive_Torque_Dellay;                                                       // 0x05A8 (size: 0x8)
    double Drive_Torque_Durration;                                                    // 0x05B0 (size: 0x8)
    double Drive_Torque_Power;                                                        // 0x05B8 (size: 0x8)
    FVector Event_Hit_location;                                                       // 0x05C0 (size: 0x18)
    bool Use_free_camera;                                                             // 0x05D8 (size: 0x1)
    bool Use_inverted_pitch;                                                          // 0x05D9 (size: 0x1)
    bool Aquamarine_Skin;                                                             // 0x05DA (size: 0x1)
    double Max_velocity;                                                              // 0x05E0 (size: 0x8)
    double Move_right;                                                                // 0x05E8 (size: 0x8)
    class UMaterialInstanceDynamic* Tracks;                                           // 0x05F0 (size: 0x8)
    double Track_speed_texture_panner;                                                // 0x05F8 (size: 0x8)
    double Turret_rotation_Speed_BP;                                                  // 0x0600 (size: 0x8)
    class UUMG_HUD_Snowmobile_C* UMG_HUD_widget;                                      // 0x0608 (size: 0x8)
    double Damage;                                                                    // 0x0610 (size: 0x8)
    FName hit_bone_name;                                                              // 0x0618 (size: 0x8)
    class UPrimitiveComponent* Hit_component;                                         // 0x0620 (size: 0x8)
    bool bIn_air;                                                                     // 0x0628 (size: 0x1)
    bool bWheel_L_In_air;                                                             // 0x0629 (size: 0x1)
    bool bWheel_R_In_air;                                                             // 0x062A (size: 0x1)
    FTimerHandle Handle_Limit_Vehicle_Speed;                                          // 0x0630 (size: 0x8)
    double Down_Impulse_Power;                                                        // 0x0638 (size: 0x8)
    FTimerHandle Handle_Sound_of_suspension;                                          // 0x0640 (size: 0x8)
    FTimerHandle Handle_Tires_roling_over;                                            // 0x0648 (size: 0x8)
    FTimerHandle Handle_Engine_audio;                                                 // 0x0650 (size: 0x8)
    double Forward_Speed;                                                             // 0x0658 (size: 0x8)
    FTimerHandle Handle_Spawn_particle_effects_on_wheels;                             // 0x0660 (size: 0x8)
    FTimerHandle Handle_Health_Regen;                                                 // 0x0668 (size: 0x8)
    double Distance_Needed_T_Hide_3p_Widget;                                          // 0x0670 (size: 0x8)
    FTimerHandle Handle_Engine_particles;                                             // 0x0678 (size: 0x8)
    FTimerHandle Handle_Sound_of_suspension ;                                         // 0x0680 (size: 0x8)
    double Max_velocity_MAX;                                                          // 0x0688 (size: 0x8)
    bool Use_CRAWL;                                                                   // 0x0690 (size: 0x1)
    double Handbrake_torque_MAX;                                                      // 0x0698 (size: 0x8)
    double Drive_Torque_Turn_Power_MAX;                                               // 0x06A0 (size: 0x8)
    double Drive_Torque_Power_MAX;                                                    // 0x06A8 (size: 0x8)
    double Drive_Torque_Turn_Power;                                                   // 0x06B0 (size: 0x8)
    bool Digital_Urban_Skin;                                                          // 0x06B8 (size: 0x1)
    bool Arctic_Skin;                                                                 // 0x06B9 (size: 0x1)
    bool Red_Mosaic_Skin;                                                             // 0x06BA (size: 0x1)
    FName Skin_name;                                                                  // 0x06BC (size: 0x8)
    bool Use_Posess_Character;                                                        // 0x06C4 (size: 0x1)
    FTimerHandle Handle_In_Air;                                                       // 0x06C8 (size: 0x8)
    TEnumAsByte<EPhysicalSurface> Surface_Type;                                       // 0x06D0 (size: 0x1)
    FVector Rim_Physics_FR_Location;                                                  // 0x06D8 (size: 0x18)
    FVector Rim_Physics_FL_Location;                                                  // 0x06F0 (size: 0x18)
    double Stearing;                                                                  // 0x0708 (size: 0x8)
    class UMaterialInstanceDynamic* Taho;                                             // 0x0710 (size: 0x8)
    FTimerHandle Handle_Tracks;                                                       // 0x0718 (size: 0x8)
    double Handbrake_BP;                                                              // 0x0720 (size: 0x8)
    double BP_popup_light;                                                            // 0x0728 (size: 0x8)
    double BP_Gauges;                                                                 // 0x0730 (size: 0x8)
    bool Use_indicators;                                                              // 0x0738 (size: 0x1)
    bool Light_Backt_Destroyed;                                                       // 0x0739 (size: 0x1)
    bool Light_Front_Destroyed;                                                       // 0x073A (size: 0x1)
    FName Dummy_Tire_S_FL;                                                            // 0x073C (size: 0x8)
    FName Dummy_Tire_S_FR;                                                            // 0x0744 (size: 0x8)
    bool bEngine_MLF;                                                                 // 0x074C (size: 0x1)
    double Spawn_Line_Trace;                                                          // 0x0750 (size: 0x8)
    bool bBlocking_Exit_Left;                                                         // 0x0758 (size: 0x1)
    class USceneComponent* Spawn_Point;                                               // 0x0760 (size: 0x8)
    float Default FOV;                                                                // 0x0768 (size: 0x4)
    bool Use_Stuck_Flip;                                                              // 0x076C (size: 0x1)
    double Flip_vector_Right_Line;                                                    // 0x0770 (size: 0x8)
    double Direction_Right;                                                           // 0x0778 (size: 0x8)
    double UP_impulse_Power;                                                          // 0x0780 (size: 0x8)
    float Seconds_to_SelfDestroy_if_stuck;                                            // 0x0788 (size: 0x4)
    class AController* ControllerPTR;                                                 // 0x0790 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void FC_Flip_If_Stucked();
    void FC_Check_Exit_Spawn_ponts();
    void FC_check_is_vehicle_in_air();
    void FC_Add_Hud();
    void FC_Volume_level_cockpit_or_external();
    void FC_Get_Particle(TEnumAsByte<EPhysicalSurface> surface, class UParticleSystem*& Particle);
    void UserConstructionScript();
    void Timeline_starting_nudge__FinishedFunc();
    void Timeline_starting_nudge__UpdateFunc();
    void Timeline_boost_duration__FinishedFunc();
    void Timeline_boost_duration__UpdateFunc();
    void Timeline_springarm_arm_lenght__FinishedFunc();
    void Timeline_springarm_arm_lenght__UpdateFunc();
    void Timeline__Reverse_Velocity__FinishedFunc();
    void Timeline__Reverse_Velocity__UpdateFunc();
    void Timeline_Handbrake__FinishedFunc();
    void Timeline_Handbrake__UpdateFunc();
    void Timeline_Popup_light__FinishedFunc();
    void Timeline_Popup_light__UpdateFunc();
    void Timeline_indicator_back_R__FinishedFunc();
    void Timeline_indicator_back_R__UpdateFunc();
    void Indicator_BL__FinishedFunc();
    void Indicator_BL__UpdateFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void Timeline_indicator_back_L__FinishedFunc();
    void Timeline_indicator_back_L__UpdateFunc();
    void Timeline_indicator_side_R__FinishedFunc();
    void Timeline_indicator_side_R__UpdateFunc();
    void Timeline_Gagues__FinishedFunc();
    void Timeline_Gagues__UpdateFunc();
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraToggle_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Crouch_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Crouch_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void ReceiveHit(class UPrimitiveComponent* MyComp, class AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit);
    void BndEvt__Enter_Vehicle_K2Node_ComponentBoundEvent_171_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__Enter_Vehicle_K2Node_ComponentBoundEvent_166_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ReceivePossessed(class AController* NewController);
    void Use_vehicle_without_character();
    void ReceiveAnyDamage(float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, class AActor* DamageCauser);
    void CE_destroy_vehicle();
    void ReceiveBeginPlay();
    void CE_Tracks();
    void CE_Brake_ON();
    void CE_Brake_OFF();
    void InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_0(float AxisValue);
    void CE_Limit_Vehicle_Speed();
    void CE_Stuck();
    void CE Sound of suspension ();
    void CE Tires roling over();
    void CE Engine audio();
    void CE Spawning particle effects on wheels();
    void CE_Health_Regeneration();
    void CE 3p_health_widget_rotate();
    void CE Engine particles();
    void CE_Reset_Crawl();
    void ReceiveTick(float DeltaSeconds);
    void CE_Posses_after_Destruction();
    void CE_Turn_OFF_Lights();
    void CE_In_Air();
    void CE_Stop_Indicators();
    void CE_Reset_Tracks();
    void SecondaryInteraction();
    void FPCAM();
    void ExecuteUbergraph_BP_SnowmobileOld(int32 EntryPoint);
}; // Size: 0x798

#endif
