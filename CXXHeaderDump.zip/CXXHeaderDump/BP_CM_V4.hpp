#ifndef UE4SS_SDK_BP_CM_V4_HPP
#define UE4SS_SDK_BP_CM_V4_HPP

class ABP_CM_V4_C : public ABP_ClassifiedMaterial_C
{
    char padding_0[0x2F0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x2F0

#endif
