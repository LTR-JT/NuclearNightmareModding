namespace EItemSpawnProbability {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EItemSpawnProbability_MAX = 3,
    };
}

