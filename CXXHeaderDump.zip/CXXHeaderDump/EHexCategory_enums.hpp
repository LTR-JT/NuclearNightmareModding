namespace EHexCategory {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        NewEnumerator5 = 4,
        NewEnumerator6 = 5,
        NewEnumerator7 = 6,
        NewEnumerator8 = 7,
        NewEnumerator9 = 8,
        NewEnumerator10 = 9,
        NewEnumerator11 = 10,
        NewEnumerator12 = 11,
        NewEnumerator13 = 12,
        NewEnumerator14 = 13,
        NewEnumerator15 = 14,
        NewEnumerator16 = 15,
        EHexCategory_MAX = 16,
    };
}

