#ifndef UE4SS_SDK_ClassifiedPickedUpLocation_HPP
#define UE4SS_SDK_ClassifiedPickedUpLocation_HPP

class AClassifiedPickedUpLocation_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)

}; // Size: 0x298

#endif
