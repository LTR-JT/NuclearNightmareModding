#ifndef UE4SS_SDK_BP_Wall_light_HPP
#define UE4SS_SDK_BP_Wall_light_HPP

class ABP_Wall_light_C : public AActor
{
    class UPointLightComponent* PointLight;                                           // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Wall_Light;                                        // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)

}; // Size: 0x2A8

#endif
