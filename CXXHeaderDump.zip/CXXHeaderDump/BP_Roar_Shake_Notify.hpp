#ifndef UE4SS_SDK_BP_Roar_Shake_Notify_HPP
#define UE4SS_SDK_BP_Roar_Shake_Notify_HPP

class UBP_Roar_Shake_Notify_C : public UAnimNotifyState
{

    bool Received_NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference);
    bool Received_NotifyTick(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x30

#endif
