#ifndef UE4SS_SDK_BP_Roar_Shake_Notify_HPP
#define UE4SS_SDK_BP_Roar_Shake_Notify_HPP

class UBP_Roar_Shake_Notify_C : public UAnimNotifyState
{
    char padding_0[0x30];                                                             // 0x0000 (size: 0x0)

    bool Received_NotifyBegin(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference);
    bool Received_NotifyTick(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, float FrameDeltaTime, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x30

#endif
