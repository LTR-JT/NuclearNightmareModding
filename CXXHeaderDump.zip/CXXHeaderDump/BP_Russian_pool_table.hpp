#ifndef UE4SS_SDK_BP_Russian_pool_table_HPP
#define UE4SS_SDK_BP_Russian_pool_table_HPP

class ABP_Russian_pool_table_C : public AActor
{
    class UStaticMeshComponent* StaticMesh7;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Billiards_gird2;                                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMesh6;                                          // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh5;                                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_Billiards_gird1;                                   // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_Billiards_legs_Russian_center;                     // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* SM_Billiards_legs_Russian;                            // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* SM_Billiards_Russian;                                 // 0x02F0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02F8 (size: 0x8)

}; // Size: 0x300

#endif
