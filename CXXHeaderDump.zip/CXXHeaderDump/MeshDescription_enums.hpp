enum class EComputeNTBsOptions {
    None = 0,
    Normals = 1,
    Tangents = 2,
    WeightedNTBs = 4,
    EComputeNTBsOptions_MAX = 5,
};

