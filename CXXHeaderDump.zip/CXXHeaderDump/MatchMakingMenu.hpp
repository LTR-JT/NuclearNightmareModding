#ifndef UE4SS_SDK_MatchMakingMenu_HPP
#define UE4SS_SDK_MatchMakingMenu_HPP

class UMatchMakingMenu_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UCircularThrobber* CircularThrobber_0;                                      // 0x02E8 (size: 0x8)
    class UImage* Gradient_Left;                                                      // 0x02F0 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F8 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master;                                      // 0x0300 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_1;                                    // 0x0308 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_2;                                    // 0x0310 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_3;                                    // 0x0318 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_0;                                          // 0x0320 (size: 0x8)
    FMatchMakingMenu_CBack Back;                                                      // 0x0328 (size: 0x10)
    void Back();
    bool EngageMatchMaking;                                                           // 0x0338 (size: 0x1)
    TArray<FServerInfo> Server List Del;                                              // 0x0340 (size: 0x10)
    class UMainMenu_C* MainMenuHud;                                                   // 0x0350 (size: 0x8)
    int32 SelectedServerIndex;                                                        // 0x0358 (size: 0x4)
    class UBP_GameInstance_C* GameInstance;                                           // 0x0360 (size: 0x8)
    TArray<FBlueprintSessionResult> Servers;                                          // 0x0368 (size: 0x10)

    void OnFailure_C981C87C4841B023D09C468A4053FA87(const TArray<FBlueprintSessionResult>& Results);
    void OnSuccess_C981C87C4841B023D09C468A4053FA87(const TArray<FBlueprintSessionResult>& Results);
    void OnFailure_48A614B14B79C45213D55F983ECD52E1();
    void OnSuccess_48A614B14B79C45213D55F983ECD52E1();
    void BndEvt__MatchMakingMenu_UI_Button_Master_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MatchMakingMenu_UI_Button_Master_3_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MatchMakingMenu_UI_Button_Master_1_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MatchMakingMenu_UI_Button_Master_2_K2Node_ComponentBoundEvent_3_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void Construct();
    void ExecuteUbergraph_MatchMakingMenu(int32 EntryPoint);
    void Back__DelegateSignature();
}; // Size: 0x378

#endif
