#ifndef UE4SS_SDK_CrewMemberAnimBP_HPP
#define UE4SS_SDK_CrewMemberAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_64;                                                          // 0x0004 (size: 0x8)
    int32 __IntProperty_65;                                                           // 0x000C (size: 0x4)
    bool __BoolProperty_66;                                                           // 0x0010 (size: 0x1)
    float __FloatProperty_67;                                                         // 0x0014 (size: 0x4)
    float __FloatProperty_68;                                                         // 0x0018 (size: 0x4)
    bool __BoolProperty_69;                                                           // 0x001C (size: 0x1)
    EAnimSyncMethod __EnumProperty_70;                                                // 0x001D (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_71;                              // 0x001E (size: 0x1)
    FName __NameProperty_72;                                                          // 0x0020 (size: 0x8)
    FName __NameProperty_73;                                                          // 0x0028 (size: 0x8)
    int32 __IntProperty_74;                                                           // 0x0030 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_75;                                         // 0x0038 (size: 0x20)
    FName __NameProperty_76;                                                          // 0x0058 (size: 0x8)
    FName __NameProperty_77;                                                          // 0x0060 (size: 0x8)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0068 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00E8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ControlRig;             // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x03A0 (size: 0x30)

}; // Size: 0x3D0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)

}; // Size: 0xC

class UCrewMemberAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0xC)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0398 (size: 0x48)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x03E0 (size: 0x28)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0408 (size: 0x80)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0488 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x04B0 (size: 0x28)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x04D8 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x04F8 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0518 (size: 0x128)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0640 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x06B0 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x06D0 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0740 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0760 (size: 0xC8)
    FAnimNode_ControlRig AnimGraphNode_ControlRig;                                    // 0x0828 (size: 0x4D0)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0CF8 (size: 0x20)
    float WalkSpeed;                                                                  // 0x0D18 (size: 0x4)
    double NewVar;                                                                    // 0x0D20 (size: 0x8)
    class AMimic_AI_C* As Mimic AI;                                                   // 0x0D28 (size: 0x8)
    TEnumAsByte<EMimicState::Type> Behavior;                                          // 0x0D30 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_CrewMemberAnimBP_AnimGraphNode_TransitionResult_80D0861F4F5E680D32D4F085C720D7AD();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_CrewMemberAnimBP_AnimGraphNode_TransitionResult_8D0EB2834C856AB25A15368EAD190EC2();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintInitializeAnimation();
    void ExecuteUbergraph_CrewMemberAnimBP(int32 EntryPoint);
}; // Size: 0xD31

#endif
