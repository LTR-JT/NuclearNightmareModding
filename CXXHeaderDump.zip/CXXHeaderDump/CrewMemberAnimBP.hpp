#ifndef UE4SS_SDK_CrewMemberAnimBP_HPP
#define UE4SS_SDK_CrewMemberAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_47;                                                          // 0x0004 (size: 0x8)
    bool __BoolProperty_48;                                                           // 0x000C (size: 0x1)
    char padding_0[0x3];                                                              // 0x000D (size: 0x3)
    float __FloatProperty_49;                                                         // 0x0010 (size: 0x4)
    float __FloatProperty_50;                                                         // 0x0014 (size: 0x4)
    bool __BoolProperty_51;                                                           // 0x0018 (size: 0x1)
    EAnimSyncMethod __EnumProperty_52;                                                // 0x0019 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_53;                              // 0x001A (size: 0x1)
    char padding_1[0x1];                                                              // 0x001B (size: 0x1)
    FName __NameProperty_54;                                                          // 0x001C (size: 0x8)
    FName __NameProperty_55;                                                          // 0x0024 (size: 0x8)
    FName __NameProperty_56;                                                          // 0x002C (size: 0x8)
    int32 __IntProperty_57;                                                           // 0x0034 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_58;                                         // 0x0038 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0058 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00D8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ControlRig;             // 0x0120 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x0150 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0180 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x01B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x01E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0210 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0240 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_3;           // 0x0270 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x02D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_2;           // 0x0300 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x0330 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x0360 (size: 0x30)

}; // Size: 0x390

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)

}; // Size: 0x8

class UCrewMemberAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0390 (size: 0x20)
    FAnimNode_ControlRig AnimGraphNode_ControlRig;                                    // 0x03B0 (size: 0x4D0)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0880 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x08F0 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0910 (size: 0xC8)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x09D8 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x0A58 (size: 0x28)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0A80 (size: 0x48)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_3;                                  // 0x0AC8 (size: 0x168)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0C30 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0C50 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_2;                                  // 0x0C70 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x0DD8 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x0F40 (size: 0x168)
    float WalkSpeed;                                                                  // 0x10A8 (size: 0x4)
    char padding_0[0x4];                                                              // 0x10AC (size: 0x4)
    double NewVar;                                                                    // 0x10B0 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_CrewMemberAnimBP(int32 EntryPoint);
}; // Size: 0x10B8

#endif
