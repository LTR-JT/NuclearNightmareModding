#ifndef UE4SS_SDK_InfectedDogAnimBPV2_HPP
#define UE4SS_SDK_InfectedDogAnimBPV2_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_35;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_36;                                                          // 0x000C (size: 0x8)
    float __FloatProperty_37;                                                         // 0x0014 (size: 0x4)
    bool __BoolProperty_38;                                                           // 0x0018 (size: 0x1)
    float __FloatProperty_39;                                                         // 0x001C (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_40;                                // 0x0020 (size: 0x2C)
    float __FloatProperty_41;                                                         // 0x004C (size: 0x4)
    float __FloatProperty_42;                                                         // 0x0050 (size: 0x4)
    bool __BoolProperty_43;                                                           // 0x0054 (size: 0x1)
    EAnimSyncMethod __EnumProperty_44;                                                // 0x0055 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_45;                              // 0x0056 (size: 0x1)
    FName __NameProperty_46;                                                          // 0x0058 (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_47;                                         // 0x0060 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0080 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0100 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0118 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x0148 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0178 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x01A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x01D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0208 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend;       // 0x0238 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0268 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0298 (size: 0x30)

}; // Size: 0x2C8

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UInfectedDogAnimBPV2_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0380 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0388 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x03A8 (size: 0x168)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0510 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0530 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x0550 (size: 0x168)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x06B8 (size: 0x48)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x0700 (size: 0xF0)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07F0 (size: 0x48)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0838 (size: 0x128)

    void AnimGraph(FPoseLink& AnimGraph);
    void ExecuteUbergraph_InfectedDogAnimBPV2(int32 EntryPoint);
}; // Size: 0x960

#endif
