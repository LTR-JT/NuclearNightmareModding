#ifndef UE4SS_SDK_BloodFX_HPP
#define UE4SS_SDK_BloodFX_HPP

class UBloodFX_C : public UAnimNotify
{

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x38

#endif
