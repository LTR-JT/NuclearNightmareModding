#ifndef UE4SS_SDK_BTTask_UFO_GetRanLocation_HPP
#define UE4SS_SDK_BTTask_UFO_GetRanLocation_HPP

class UBTTask_UFO_GetRanLocation_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FVector TargetLocation;                                                           // 0x00B0 (size: 0x18)
    FBlackboardKeySelector MoveTo;                                                    // 0x00C8 (size: 0x28)
    FBlackboardKeySelector IsMoving;                                                  // 0x00F0 (size: 0x28)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_UFO_GetRanLocation(int32 EntryPoint);
}; // Size: 0x118

#endif
