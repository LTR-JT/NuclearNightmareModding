#ifndef UE4SS_SDK_GlobalChat_HPP
#define UE4SS_SDK_GlobalChat_HPP

class UGlobalChat_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button;                                                            // 0x02E8 (size: 0x8)
    class UButton* Button_136;                                                        // 0x02F0 (size: 0x8)
    class UEditableText* EditableText_0;                                              // 0x02F8 (size: 0x8)
    class UImage* Image_115;                                                          // 0x0300 (size: 0x8)
    class UScrollBox* ScrollBox_54;                                                   // 0x0308 (size: 0x8)
    int32 LastMessage;                                                                // 0x0310 (size: 0x4)
    class ABP_FirstPersonGameState_C* As BP First Person Game State;                  // 0x0318 (size: 0x8)
    FGlobalChat_CClose Close;                                                         // 0x0320 (size: 0x10)
    void Close();
    FGlobalChat_CSendMessage SendMessage;                                             // 0x0330 (size: 0x10)
    void SendMessage(FText Text, FString UserName);

    void BndEvt__GlobalChat_Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__GlobalChat_EditableText_0_K2Node_ComponentBoundEvent_1_OnEditableTextCommittedEvent__DelegateSignature(const FText& Text, TEnumAsByte<ETextCommit::Type> CommitMethod);
    void Construct();
    void ReactToMessage();
    void ExecuteUbergraph_GlobalChat(int32 EntryPoint);
    void SendMessage__DelegateSignature(FText Text, FString UserName);
    void Close__DelegateSignature();
}; // Size: 0x340

#endif
