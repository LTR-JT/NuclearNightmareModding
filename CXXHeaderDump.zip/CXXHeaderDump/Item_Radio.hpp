#ifndef UE4SS_SDK_Item_Radio_HPP
#define UE4SS_SDK_Item_Radio_HPP

class AItem_Radio_C : public AItemActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E8 (size: 0x8)

    void BPOnEquip(class ANuclearNightmareCharacter* Character);
    void BPOnUnEquip(class ANuclearNightmareCharacter* Character);
    void ExecuteUbergraph_Item_Radio(int32 EntryPoint);
}; // Size: 0x2F0

#endif
