#ifndef UE4SS_SDK_InfectedDecatorator_HPP
#define UE4SS_SDK_InfectedDecatorator_HPP

class UInfectedDecatorator_C : public UBTDecorator_BlueprintBase
{
    FBlackboardKeySelector Key;                                                       // 0x00A0 (size: 0x28)

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xC8

#endif
