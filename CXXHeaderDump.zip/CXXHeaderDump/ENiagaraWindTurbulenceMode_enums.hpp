namespace ENiagaraWindTurbulenceMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraWindTurbulenceMode_MAX = 2,
    };
}

