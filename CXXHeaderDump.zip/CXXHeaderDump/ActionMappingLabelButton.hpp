#ifndef UE4SS_SDK_ActionMappingLabelButton_HPP
#define UE4SS_SDK_ActionMappingLabelButton_HPP

class UActionMappingLabelButton_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Create_1;                                                          // 0x02E8 (size: 0x8)
    class UImage* Image_31;                                                           // 0x02F0 (size: 0x8)
    class UInputKeySelector* InputKeySelector;                                        // 0x02F8 (size: 0x8)
    class UInputKeySelector* InputKeySelector_128;                                    // 0x0300 (size: 0x8)
    class UTextBlock* TextBlock_39;                                                   // 0x0308 (size: 0x8)
    FPlayerKeyMapping KeyMap;                                                         // 0x0310 (size: 0x80)
    class UEnhancedInputUserSettings* UserSetting;                                    // 0x0390 (size: 0x8)
    bool SelectionChange;                                                             // 0x0398 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0399 (size: 0x7)
    FKey Key;                                                                         // 0x03A0 (size: 0x18)
    FPlayerKeyMapping KeyMapSecond;                                                   // 0x03B8 (size: 0x80)
    bool 2nd Not Found;                                                               // 0x0438 (size: 0x1)

    void Update2ND(FKey Key);
    void Update(FKey Key);
    FText GetText_0();
    FText GetText();
    void Construct();
    void BndEvt__ActionMappingLabelButton_InputKeySelector_128_K2Node_ComponentBoundEvent_0_OnKeySelected__DelegateSignature(FInputChord SelectedKey);
    void BndEvt__ActionMappingLabelButton_InputKeySelector_128_K2Node_ComponentBoundEvent_1_OnIsSelectingKeyChanged__DelegateSignature();
    void BndEvt__ActionMappingLabelButton_Create_1_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__ActionMappingLabelButton_InputKeySelector_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature();
    void BndEvt__ActionMappingLabelButton_InputKeySelector_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature(FInputChord SelectedKey);
    void ExecuteUbergraph_ActionMappingLabelButton(int32 EntryPoint);
}; // Size: 0x439

#endif
