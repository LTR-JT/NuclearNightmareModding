#ifndef UE4SS_SDK_BP_Cupboard_2_HPP
#define UE4SS_SDK_BP_Cupboard_2_HPP

class ABP_Cupboard_2_C : public AActor
{
    class UStaticMeshComponent* SM_cue_holder_big;                                    // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Cupboard_door_3;                                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_Cupboard_door_2;                                   // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_Cupboard_door_1;                                   // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Cupboard;                                          // 0x02C8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02D0 (size: 0x8)

}; // Size: 0x2D8

#endif
