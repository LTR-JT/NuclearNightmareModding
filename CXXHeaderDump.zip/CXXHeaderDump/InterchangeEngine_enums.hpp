enum class EInterchangePipelineConfigurationDialogResult {
    Cancel = 0,
    Import = 1,
    ImportAll = 2,
    EInterchangePipelineConfigurationDialogResult_MAX = 3,
};

