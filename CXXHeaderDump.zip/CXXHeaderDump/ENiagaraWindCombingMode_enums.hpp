namespace ENiagaraWindCombingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraWindCombingMode_MAX = 2,
    };
}

