#ifndef UE4SS_SDK_DrillingRigContent_HPP
#define UE4SS_SDK_DrillingRigContent_HPP

class UDrillingRigContent_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_0;                                                          // 0x02E8 (size: 0x8)
    FDrillingRigContent_CClicked Clicked;                                             // 0x02F0 (size: 0x10)
    void Clicked();

    void BndEvt__BaseCampContent_Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void OnClicked();
    void BndEvt__DrillingRigContent_Button_0_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();
    void ExecuteUbergraph_DrillingRigContent(int32 EntryPoint);
    void Clicked__DelegateSignature();
}; // Size: 0x300

#endif
