#ifndef UE4SS_SDK_AnimBP_EM02_HPP
#define UE4SS_SDK_AnimBP_EM02_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_82;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_83;                                                          // 0x000C (size: 0x8)
    int32 __IntProperty_84;                                                           // 0x0014 (size: 0x4)
    bool __BoolProperty_85;                                                           // 0x0018 (size: 0x1)
    float __FloatProperty_86;                                                         // 0x001C (size: 0x4)
    float __FloatProperty_87;                                                         // 0x0020 (size: 0x4)
    bool __BoolProperty_88;                                                           // 0x0024 (size: 0x1)
    EAnimSyncMethod __EnumProperty_89;                                                // 0x0025 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_90;                              // 0x0026 (size: 0x1)
    FName __NameProperty_91;                                                          // 0x0028 (size: 0x8)
    FName __NameProperty_92;                                                          // 0x0030 (size: 0x8)
    FName __NameProperty_93;                                                          // 0x0038 (size: 0x8)
    int32 __IntProperty_94;                                                           // 0x0040 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_95;                                         // 0x0048 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0068 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00E8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonSpineSolver;      // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonFeetSolver;       // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_3;           // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_2;           // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x04C0 (size: 0x30)

}; // Size: 0x4F0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)

}; // Size: 0xC

class UAnimBP_EM02_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0xC)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0398 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x03B8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x03E0 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0408 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0478 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0498 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0508 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0528 (size: 0xC8)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x05F0 (size: 0x48)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0638 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x06B8 (size: 0x28)
    FAnimNode_DragonSpineSolver AnimGraphNode_DragonSpineSolver;                      // 0x06E0 (size: 0xEC0)
    FAnimNode_DragonFeetSolver AnimGraphNode_DragonFeetSolver;                        // 0x15A0 (size: 0x9C0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x1F60 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x1F80 (size: 0x20)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x1FA0 (size: 0x28)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x1FC8 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_3;                                  // 0x1FE8 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_2;                                  // 0x2150 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x22B8 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x2420 (size: 0x168)
    class AActor* K2Node_PropertyAccess_2;                                            // 0x2588 (size: 0x8)
    FVector K2Node_PropertyAccess;                                                    // 0x2590 (size: 0x18)
    float Speed;                                                                      // 0x25A8 (size: 0x4)
    bool hit leg;                                                                     // 0x25AC (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    class AEyeMonster_AI_C* TryGetEyeMonster();
    void BlueprintThreadSafeUpdateAnimation(float DeltaTime);
    void ExecuteUbergraph_AnimBP_EM02(int32 EntryPoint);
}; // Size: 0x25AD

#endif
