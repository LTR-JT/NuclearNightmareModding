namespace Enum_Panels {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        NewEnumerator4 = 4,
        NewEnumerator5 = 5,
        NewEnumerator6 = 6,
        NewEnumerator7 = 7,
        NewEnumerator8 = 8,
        NewEnumerator9 = 9,
        Enum_MAX = 10,
    };
}

