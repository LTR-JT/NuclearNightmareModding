#ifndef UE4SS_SDK_BP_Table_Lamp_HPP
#define UE4SS_SDK_BP_Table_Lamp_HPP

class ABP_Table_Lamp_C : public AActor
{
    class UPointLightComponent* PointLight;                                           // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_table_lamp;                                        // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)

}; // Size: 0x2A8

#endif
