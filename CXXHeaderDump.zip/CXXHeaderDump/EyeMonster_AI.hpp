#ifndef UE4SS_SDK_EyeMonster_AI_HPP
#define UE4SS_SDK_EyeMonster_AI_HPP

class AEyeMonster_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UPhysicalAnimationComponent* PhysicalAnimation;                             // 0x0678 (size: 0x8)
    class UNavigationInvokerComponent* NavigationInvoker;                             // 0x0680 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction2;                                     // 0x0688 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0690 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0698 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x06A0 (size: 0x8)
    float Timeline_1_NewTrack_0_760573554E6515E01D457380D3ED251E;                     // 0x06A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_760573554E6515E01D457380D3ED251E; // 0x06AC (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x06B0 (size: 0x8)
    float Timeline_NewTrack_0_E3D684A0453B1BEA5DA93EA38B8090B4;                       // 0x06B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_E3D684A0453B1BEA5DA93EA38B8090B4; // 0x06BC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x06C0 (size: 0x8)
    float Timeline_0_NewTrack_0_5D654D22482692E261DD0FA9A699CA04;                     // 0x06C8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_5D654D22482692E261DD0FA9A699CA04; // 0x06CC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x06D0 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x06D8 (size: 0x1)
    class UStaticMeshComponent* Door;                                                 // 0x06E0 (size: 0x8)
    bool FlamethrowerAttack;                                                          // 0x06E8 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Target;                                         // 0x06F0 (size: 0x8)
    bool BPIsDead;                                                                    // 0x06F8 (size: 0x1)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0700 (size: 0x10)
    bool DeSpawn;                                                                     // 0x0710 (size: 0x1)
    double EyerDamage;                                                                // 0x0718 (size: 0x8)
    bool StillMovingToLocation;                                                       // 0x0720 (size: 0x1)
    class UMaterialInstanceDynamic* SkinMaterial;                                     // 0x0728 (size: 0x8)
    class AMusicManager_C* MusicManager;                                              // 0x0730 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Target_0;                                       // 0x0738 (size: 0x8)
    FRotator OldControlRot;                                                           // 0x0740 (size: 0x18)
    bool HasBeenAttackedByDog;                                                        // 0x0758 (size: 0x1)
    bool hit leg;                                                                     // 0x0759 (size: 0x1)
    bool ElusiveFighter;                                                              // 0x075A (size: 0x1)

    bool Attacking();
    bool CanSeePlayer();
    bool Dead();
    bool CanBeSensed(class ANuclearNightmareCharacter* ResponsibleCharacter);
    bool InfectionDetector();
    void UserConstructionScript();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void OnNotifyEnd_B34AE26B47315E3147842D93F695AC2A(FName NotifyName);
    void OnNotifyBegin_B34AE26B47315E3147842D93F695AC2A(FName NotifyName);
    void OnInterrupted_B34AE26B47315E3147842D93F695AC2A(FName NotifyName);
    void OnBlendOut_B34AE26B47315E3147842D93F695AC2A(FName NotifyName);
    void OnCompleted_B34AE26B47315E3147842D93F695AC2A(FName NotifyName);
    void OnNotifyEnd_A5442A7546B9FF0B0EDED4A4C60C307C(FName NotifyName);
    void OnNotifyBegin_A5442A7546B9FF0B0EDED4A4C60C307C(FName NotifyName);
    void OnInterrupted_A5442A7546B9FF0B0EDED4A4C60C307C(FName NotifyName);
    void OnBlendOut_A5442A7546B9FF0B0EDED4A4C60C307C(FName NotifyName);
    void OnCompleted_A5442A7546B9FF0B0EDED4A4C60C307C(FName NotifyName);
    void OnNotifyEnd_43EA3AA347697997D325F995ED18BAC2(FName NotifyName);
    void OnNotifyBegin_43EA3AA347697997D325F995ED18BAC2(FName NotifyName);
    void OnInterrupted_43EA3AA347697997D325F995ED18BAC2(FName NotifyName);
    void OnBlendOut_43EA3AA347697997D325F995ED18BAC2(FName NotifyName);
    void OnCompleted_43EA3AA347697997D325F995ED18BAC2(FName NotifyName);
    void OnNotifyEnd_4C47C36F4D31734CAF8382A8E885F96C(FName NotifyName);
    void OnNotifyBegin_4C47C36F4D31734CAF8382A8E885F96C(FName NotifyName);
    void OnInterrupted_4C47C36F4D31734CAF8382A8E885F96C(FName NotifyName);
    void OnBlendOut_4C47C36F4D31734CAF8382A8E885F96C(FName NotifyName);
    void OnCompleted_4C47C36F4D31734CAF8382A8E885F96C(FName NotifyName);
    void OnNotifyEnd_4AD45D2B4C3B8C8225A9449B3F361876(FName NotifyName);
    void OnNotifyBegin_4AD45D2B4C3B8C8225A9449B3F361876(FName NotifyName);
    void OnInterrupted_4AD45D2B4C3B8C8225A9449B3F361876(FName NotifyName);
    void OnBlendOut_4AD45D2B4C3B8C8225A9449B3F361876(FName NotifyName);
    void OnCompleted_4AD45D2B4C3B8C8225A9449B3F361876(FName NotifyName);
    void OnNotifyEnd_D9D80A7D4941D403D3A320994D75EA4D(FName NotifyName);
    void OnNotifyBegin_D9D80A7D4941D403D3A320994D75EA4D(FName NotifyName);
    void OnInterrupted_D9D80A7D4941D403D3A320994D75EA4D(FName NotifyName);
    void OnBlendOut_D9D80A7D4941D403D3A320994D75EA4D(FName NotifyName);
    void OnCompleted_D9D80A7D4941D403D3A320994D75EA4D(FName NotifyName);
    void OnNotifyEnd_B796BABF43826F743BE3F291A67C4E60(FName NotifyName);
    void OnNotifyBegin_B796BABF43826F743BE3F291A67C4E60(FName NotifyName);
    void OnInterrupted_B796BABF43826F743BE3F291A67C4E60(FName NotifyName);
    void OnBlendOut_B796BABF43826F743BE3F291A67C4E60(FName NotifyName);
    void OnCompleted_B796BABF43826F743BE3F291A67C4E60(FName NotifyName);
    void OnFailure_680924D94729C7336056ADB542522DDB();
    void OnSuccess_680924D94729C7336056ADB542522DDB();
    void OnFailure_D5D1EA1046F89ACBE78F27A4972416B6(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_D5D1EA1046F89ACBE78F27A4972416B6(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnNotifyEnd_3B93C34C4E55760055B3888B3DA41DCB(FName NotifyName);
    void OnNotifyBegin_3B93C34C4E55760055B3888B3DA41DCB(FName NotifyName);
    void OnInterrupted_3B93C34C4E55760055B3888B3DA41DCB(FName NotifyName);
    void OnBlendOut_3B93C34C4E55760055B3888B3DA41DCB(FName NotifyName);
    void OnCompleted_3B93C34C4E55760055B3888B3DA41DCB(FName NotifyName);
    void OnNotifyEnd_BA38DB13424833AE6E4999B104079D86(FName NotifyName);
    void OnNotifyBegin_BA38DB13424833AE6E4999B104079D86(FName NotifyName);
    void OnInterrupted_BA38DB13424833AE6E4999B104079D86(FName NotifyName);
    void OnBlendOut_BA38DB13424833AE6E4999B104079D86(FName NotifyName);
    void OnCompleted_BA38DB13424833AE6E4999B104079D86(FName NotifyName);
    void OnNotifyEnd_2BD0219547366366413A25AB7505B932(FName NotifyName);
    void OnNotifyBegin_2BD0219547366366413A25AB7505B932(FName NotifyName);
    void OnInterrupted_2BD0219547366366413A25AB7505B932(FName NotifyName);
    void OnBlendOut_2BD0219547366366413A25AB7505B932(FName NotifyName);
    void OnCompleted_2BD0219547366366413A25AB7505B932(FName NotifyName);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void AttackMulti(double Chance);
    void AttackServer();
    void ReceivePossessed(class AController* NewController);
    void RunBehavior();
    void CheckIfLooking();
    void DeSpawnServer();
    void DeSpawnFully();
    void StartInfection();
    void EyeMonsterDamage();
    void DeathMulti();
    void DeathServer(FName BonenName, FVector Location, FVector Impulse, bool IsSniper?);
    void DeathSkipALL(FName BoneName, FVector Location, double Damage, bool IsSniper);
    void FlareGun();
    void FindRandomMove();
    void FindRandomMoveAll();
    void DeathBlowUp(FName BoneName, FVector Location, double Damage);
    void DogDeath();
    void DestroyGen();
    void MoveToGenerator(class ABP_GeneratorGameplayNew_C* Generator, bool MoveTo?);
    void PlayMontageALL();
    void PlayMontageServer();
    void CheckForGenerator();
    void PlaySpawnAnimation();
    void PlaySpawnAnimationServer();
    void SpawnAttachedSound();
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void ExecuteUbergraph_EyeMonster_AI(int32 EntryPoint);
}; // Size: 0x75B

#endif
