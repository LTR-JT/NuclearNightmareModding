#ifndef UE4SS_SDK_BPI_MoveToGenerator_HPP
#define UE4SS_SDK_BPI_MoveToGenerator_HPP

class IBPI_MoveToGenerator_C : public IInterface
{

    void MoveToGenerator(class ABP_GeneratorGameplayNew_C* Generator, bool MoveTo?);
}; // Size: 0x28

#endif
