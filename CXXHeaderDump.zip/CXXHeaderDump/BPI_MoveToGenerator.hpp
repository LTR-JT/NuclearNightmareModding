#ifndef UE4SS_SDK_BPI_MoveToGenerator_HPP
#define UE4SS_SDK_BPI_MoveToGenerator_HPP

class IBPI_MoveToGenerator_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void MoveToGenerator(class ABP_GeneratorGameplayNew_C* Generator, bool MoveTo?);
}; // Size: 0x28

#endif
