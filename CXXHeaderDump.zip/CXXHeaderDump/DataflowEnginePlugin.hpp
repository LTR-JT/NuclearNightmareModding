#ifndef UE4SS_SDK_DataflowEnginePlugin_HPP
#define UE4SS_SDK_DataflowEnginePlugin_HPP

class ADataflowActor : public AActor
{
    class UDataflowComponent* DataflowComponent;                                      // 0x0290 (size: 0x8)

}; // Size: 0x298

class UDataflowComponent : public UPrimitiveComponent
{
}; // Size: 0x660

#endif
