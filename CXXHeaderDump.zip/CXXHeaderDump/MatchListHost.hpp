#ifndef UE4SS_SDK_MatchListHost_HPP
#define UE4SS_SDK_MatchListHost_HPP

class UMatchListHost_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UImage* I_Avatar;                                                           // 0x02E8 (size: 0x8)
    class UImage* Image_108;                                                          // 0x02F0 (size: 0x8)
    class UButton* KickButton;                                                        // 0x02F8 (size: 0x8)
    class UTextBlock* KickText;                                                       // 0x0300 (size: 0x8)
    class USlider* Slider_103;                                                        // 0x0308 (size: 0x8)
    class UButton* SteamButton;                                                       // 0x0310 (size: 0x8)
    class UTextBlock* T_PlayerName;                                                   // 0x0318 (size: 0x8)
    FBPFriendInfo FriendData;                                                         // 0x0320 (size: 0x68)
    FLinearColor Specified Color;                                                     // 0x0388 (size: 0x10)
    bool Succed;                                                                      // 0x0398 (size: 0x1)
    class UObject* Avatar;                                                            // 0x03A0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x03A8 (size: 0x8)
    FMatchListHost_CKickedPlayer KickedPlayer;                                        // 0x03B0 (size: 0x10)
    void KickedPlayer();

    float GetValue();
    FSlateColor Get_T_PlayerName_1_ColorAndOpacity();
    FText Get_T_PlayerName_1_Text();
    void BndEvt__MatchListHost_Slider_103_K2Node_ComponentBoundEvent_2_OnFloatValueChangedEvent__DelegateSignature(float Value);
    void BndEvt__MatchListHost_Create_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__MatchListHost_Create_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();
    void Construct();
    void ExecuteUbergraph_MatchListHost(int32 EntryPoint);
    void KickedPlayer__DelegateSignature();
}; // Size: 0x3C0

#endif
