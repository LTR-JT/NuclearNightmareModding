#ifndef UE4SS_SDK_BTTask_HuskyPlayMontage_HPP
#define UE4SS_SDK_BTTask_HuskyPlayMontage_HPP

class UBTTask_HuskyPlayMontage_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_HuskyPlayMontage(int32 EntryPoint);
}; // Size: 0xB0

#endif
