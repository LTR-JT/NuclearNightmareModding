#ifndef UE4SS_SDK_EndGameCam_HPP
#define UE4SS_SDK_EndGameCam_HPP

class AEndGameCam_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCineCameraComponent* CineCamera;                                           // 0x0298 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    float Timeline_NewTrack_0_3BCBE9374387067F1A61AE920323D5F0;                       // 0x02B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_3BCBE9374387067F1A61AE920323D5F0; // 0x02B4 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02B8 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> Players;                                // 0x02C0 (size: 0x10)
    int32 Index;                                                                      // 0x02D0 (size: 0x4)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnFailure_B48757444A3F52A311AE52990CBC7872();
    void OnSuccess_B48757444A3F52A311AE52990CBC7872();
    void OnFailure_1C22503047C4E334E066B7A465DABB30();
    void OnSuccess_1C22503047C4E334E066B7A465DABB30();
    void ReceiveBeginPlay();
    void Response?(bool Retry?);
    void ServerTravelToReset();
    void HostLeaveAll();
    void HostLeave();
    void ReplicateAllStatesFromSettings(int32 LobbyMins, TEnumAsByte<ENukeTimer::Type> NukeTimer, TEnumAsByte<EItemSpawnProbability::Type> ItemFrequency, TEnumAsByte<EDayNightCycle::Type> DayCycle, TEnumAsByte<EDiffculty::Type> Diffculty, bool FriendlyFire, bool NeverSpawnPlayable, bool AirbornInfections, bool PlayableEnemies, TEnumAsByte<EDiffculty::Type> Classified, bool AllowEnemyDaySpawn);
    void ReplicateAllStates(int32 LobbyMins, TEnumAsByte<ENukeTimer::Type> NukeTimer, TEnumAsByte<EItemSpawnProbability::Type> ItemFrequency, TEnumAsByte<EDayNightCycle::Type> DayCycle, TEnumAsByte<EDiffculty::Type> Diffculty, bool FriendlyFire, bool NeverSpawnPlayable, bool AirbornInfections, bool PlayableEnemies, TEnumAsByte<EDiffculty::Type> Classified, bool AllowEnemyDaySpawn);
    void ExecuteUbergraph_EndGameCam(int32 EntryPoint);
}; // Size: 0x2D4

#endif
