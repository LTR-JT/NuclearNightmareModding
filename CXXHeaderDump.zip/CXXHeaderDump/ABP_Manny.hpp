#ifndef UE4SS_SDK_ABP_Manny_HPP
#define UE4SS_SDK_ABP_Manny_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_109;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_110;                                                         // 0x000C (size: 0x8)
    int32 __IntProperty_111;                                                          // 0x0014 (size: 0x4)
    FName __NameProperty_112;                                                         // 0x0018 (size: 0x8)
    FName __NameProperty_113;                                                         // 0x0020 (size: 0x8)
    FName __NameProperty_114;                                                         // 0x0028 (size: 0x8)
    int32 __IntProperty_115;                                                          // 0x0030 (size: 0x4)
    class UBlendProfile* __BlendProfile_116;                                          // 0x0038 (size: 0x8)
    class UCurveFloat* __CurveFloat_117;                                              // 0x0040 (size: 0x8)
    EAlphaBlendOption __EnumProperty_118;                                             // 0x0048 (size: 0x1)
    EBlendListTransitionType __EnumProperty_119;                                      // 0x0049 (size: 0x1)
    TArray<float> __ArrayProperty_120;                                                // 0x0050 (size: 0x10)
    bool __BoolProperty_121;                                                          // 0x0060 (size: 0x1)
    float __FloatProperty_122;                                                        // 0x0064 (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_123;                               // 0x0068 (size: 0x2C)
    float __FloatProperty_124;                                                        // 0x0094 (size: 0x4)
    bool __BoolProperty_125;                                                          // 0x0098 (size: 0x1)
    EAnimSyncMethod __EnumProperty_126;                                               // 0x0099 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_127;                             // 0x009A (size: 0x1)
    FName __NameProperty_128;                                                         // 0x009C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_129;                                        // 0x00A8 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00C8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0148 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2;          // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_1;         // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_1;       // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_2;        // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonFeetSolver;       // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonSpineSolver;      // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_1;               // 0x05B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt;                 // 0x05E0 (size: 0x30)

}; // Size: 0x610

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)
    bool __BoolProperty_1;                                                            // 0x000C (size: 0x1)
    float __FloatProperty_2;                                                          // 0x0010 (size: 0x4)

}; // Size: 0x14

class UABP_Manny_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x14)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0390 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0398 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x03A0 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x03C0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x03E8 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0410 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_2;                                // 0x0480 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x04A0 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x04E8 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_1;                              // 0x0508 (size: 0xC8)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_1;                          // 0x05D0 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;                            // 0x0650 (size: 0x28)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0678 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0698 (size: 0xC8)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0760 (size: 0x48)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x07A8 (size: 0x48)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07F0 (size: 0x48)
    FAnimNode_DragonFeetSolver AnimGraphNode_DragonFeetSolver;                        // 0x0840 (size: 0x9C0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x1200 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x1220 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x1240 (size: 0x20)
    FAnimNode_DragonSpineSolver AnimGraphNode_DragonSpineSolver;                      // 0x1260 (size: 0xEC0)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x2120 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x21A0 (size: 0x28)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x21C8 (size: 0x28)
    FAnimNode_LookAt AnimGraphNode_LookAt_1;                                          // 0x21F0 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt;                                            // 0x2440 (size: 0x250)
    class ACharacter* Character;                                                      // 0x2690 (size: 0x8)
    class UCharacterMovementComponent* MovementComponent;                             // 0x2698 (size: 0x8)
    FVector Velocity;                                                                 // 0x26A0 (size: 0x18)
    double GroundSpeed;                                                               // 0x26B8 (size: 0x8)
    bool ShouldMove;                                                                  // 0x26C0 (size: 0x1)
    bool IsFalling;                                                                   // 0x26C1 (size: 0x1)
    float Direction;                                                                  // 0x26C4 (size: 0x4)
    bool Running;                                                                     // 0x26C8 (size: 0x1)
    FRotator Control Rotation;                                                        // 0x26D0 (size: 0x18)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Manny_AnimGraphNode_LookAt_8E76A35F45AE6FC41283A0A4870478CD();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Manny_AnimGraphNode_LookAt_B6F76F974F02C70FE4EE4F9607F203E2();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Manny_AnimGraphNode_SequencePlayer_34A5FD9647FA5B0D20C0BC8B0287B14A();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void BlueprintInitializeAnimation();
    void ExecuteUbergraph_ABP_Manny(int32 EntryPoint);
}; // Size: 0x26E8

#endif
