#ifndef UE4SS_SDK_BP_DemoRoom_HPP
#define UE4SS_SDK_BP_DemoRoom_HPP

class ABP_DemoRoom_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MWall;                                     // 0x0298 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MCurve;                                    // 0x02A0 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MPillar;                                   // 0x02A8 (size: 0x8)
    class UInstancedStaticMeshComponent* PillarCurve;                                 // 0x02B0 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MWall_Black;                               // 0x02B8 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MPillar_Black;                             // 0x02C0 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MEdge_White;                               // 0x02C8 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MWall_Colour;                              // 0x02D0 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MEdge_Colour;                              // 0x02D8 (size: 0x8)
    FString Debug;                                                                    // 0x02E0 (size: 0x10)
    class UInstancedStaticMeshComponent* Floor_Corner;                                // 0x02F0 (size: 0x8)
    class UInstancedStaticMeshComponent* Floor_Edge;                                  // 0x02F8 (size: 0x8)
    class UInstancedStaticMeshComponent* UELogo;                                      // 0x0300 (size: 0x8)
    TArray<FS_RoomSettings> Rooms;                                                    // 0x0308 (size: 0x10)
    double Segment Counter;                                                           // 0x0318 (size: 0x8)
    class UInstancedStaticMeshComponent* BackWall_Corner;                             // 0x0320 (size: 0x8)
    class UInstancedStaticMeshComponent* BackWall_Edge;                               // 0x0328 (size: 0x8)
    class UInstancedStaticMeshComponent* FloorFilter;                                 // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MWall_Grey;                                // 0x0338 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MWall_Ceiling;                             // 0x0340 (size: 0x8)
    class UInstancedStaticMeshComponent* BlackRibbedWall;                             // 0x0348 (size: 0x8)
    class UInstancedStaticMeshComponent* BlackRibbedCurve;                            // 0x0350 (size: 0x8)
    double SpacerSize;                                                                // 0x0358 (size: 0x8)
    class UInstancedStaticMeshComponent* WhiteRibbedWall;                             // 0x0360 (size: 0x8)
    class UInstancedStaticMeshComponent* Pipe;                                        // 0x0368 (size: 0x8)
    class UInstancedStaticMeshComponent* Trim_End;                                    // 0x0370 (size: 0x8)
    class UInstancedStaticMeshComponent* Trim_Straight;                               // 0x0378 (size: 0x8)
    class UInstancedStaticMeshComponent* Trim_Curve;                                  // 0x0380 (size: 0x8)
    class UInstancedStaticMeshComponent* Trim;                                        // 0x0388 (size: 0x8)
    class UInstancedStaticMeshComponent* LightPanel;                                  // 0x0390 (size: 0x8)
    class UInstancedStaticMeshComponent* PillarCurveCorner;                           // 0x0398 (size: 0x8)
    class UInstancedStaticMeshComponent* MetalTrim_Corner;                            // 0x03A0 (size: 0x8)
    class UInstancedStaticMeshComponent* MetalTrim_Straight;                          // 0x03A8 (size: 0x8)
    bool Draw End Wall;                                                               // 0x03B0 (size: 0x1)
    bool Draw Start Wall;                                                             // 0x03B1 (size: 0x1)
    char padding_0[0x6];                                                              // 0x03B2 (size: 0x6)
    class UInstancedStaticMeshComponent* 10MPillar2;                                  // 0x03B8 (size: 0x8)
    class UInstancedStaticMeshComponent* PillarCurveCornerBlack;                      // 0x03C0 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MPillar2Black;                             // 0x03C8 (size: 0x8)
    class UInstancedStaticMeshComponent* 10MEdgeBlack;                                // 0x03D0 (size: 0x8)

    void Redraw();
    void Lighting(const FS_RoomSettings& Room Params);
    void MetalStrip(FTransform BaseTransform);
    void Add Spacer(float Offset);
    void Make BackWall(FTransform Base Transform, int32 Room Width, int32 Room Height, double Floor Segment, double Inner Panel Percent, double Outer Panel Percent);
    void Make Rounded End(FTransform Base Transform, int32 Room Width, double Floor Segment, double Inner Panel Percent, double Outer Panel Percent);
    void Make Door(int32 Room Width, int32 Room Height, double Offset);
    void Make Pillar(FTransform Base Position, int32 Width, int32 Height, double PillarThickness, bool SquareExterior, bool White);
    void EndWall(FTransform WallPosition, int32 Width, int32 Height);
    void Create Instances();
    void Floor();
    void Create Room(FS_RoomSettings Room Params, double SegmentCounter);
    void UserConstructionScript();
}; // Size: 0x3D8

#endif
