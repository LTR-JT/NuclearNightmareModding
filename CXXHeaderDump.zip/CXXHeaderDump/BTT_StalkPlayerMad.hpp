#ifndef UE4SS_SDK_BTT_StalkPlayerMad_HPP
#define UE4SS_SDK_BTT_StalkPlayerMad_HPP

class UBTT_StalkPlayerMad_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    class AStalker_AI_C* Stalker;                                                     // 0x00D8 (size: 0x8)
    FVector Random Location;                                                          // 0x00E0 (size: 0x18)
    bool FinishedTask?;                                                               // 0x00F8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x00F9 (size: 0x7)
    class AMadPatent_AI_C* Stalker_0;                                                 // 0x0100 (size: 0x8)

    void OnFail_EBDC092E414B30D712B1A89A71DF955A(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_EBDC092E414B30D712B1A89A71DF955A(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_2D0C0CA04ED12BC31F04A280F46BB726(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_2D0C0CA04ED12BC31F04A280F46BB726(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_StalkPlayerMad(int32 EntryPoint);
}; // Size: 0x108

#endif
