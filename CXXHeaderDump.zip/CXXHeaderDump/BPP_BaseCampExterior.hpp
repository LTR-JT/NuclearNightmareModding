#ifndef UE4SS_SDK_BPP_BaseCampExterior_HPP
#define UE4SS_SDK_BPP_BaseCampExterior_HPP

class ABPP_BaseCampExterior_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh8;                        // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh7;                        // 0x0338 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh6;                        // 0x0340 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh5;                        // 0x0348 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh4;                        // 0x0350 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh3;                        // 0x0358 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh2;                        // 0x0360 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh1;                        // 0x0368 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0370 (size: 0x8)

}; // Size: 0x378

#endif
