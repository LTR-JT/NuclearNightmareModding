namespace EFallDamageType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EFallDamageType_MAX = 3,
    };
}

