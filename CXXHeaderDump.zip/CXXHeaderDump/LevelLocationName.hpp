#ifndef UE4SS_SDK_LevelLocationName_HPP
#define UE4SS_SDK_LevelLocationName_HPP

class ULevelLocationName_C : public UUserWidget
{
    class UTextBlock* AddMinus;                                                       // 0x02E0 (size: 0x8)
    class UHorizontalBox* HorizontalBox;                                              // 0x02E8 (size: 0x8)
    class UImage* Image_51;                                                           // 0x02F0 (size: 0x8)
    class UTextBlock* TextBlock_1;                                                    // 0x02F8 (size: 0x8)
    FText Name;                                                                       // 0x0300 (size: 0x10)
    bool Selected?;                                                                   // 0x0310 (size: 0x1)
    FSlateColor Color;                                                                // 0x0314 (size: 0x14)

    FSlateColor GetColorAndOpacity();
    FText Get_AddMinus_Text();
    FText GetText_0();
    FText GetText();
}; // Size: 0x328

#endif
