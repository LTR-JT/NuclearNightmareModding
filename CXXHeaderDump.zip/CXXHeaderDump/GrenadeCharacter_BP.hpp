#ifndef UE4SS_SDK_GrenadeCharacter_BP_HPP
#define UE4SS_SDK_GrenadeCharacter_BP_HPP

class AGrenadeCharacter_BP_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class USkeletalMeshComponent* FPPMesh;                                            // 0x0678 (size: 0x8)
    class UCameraComponent* FPPCamera;                                                // 0x0680 (size: 0x8)
    class UCameraComponent* TPPCamera;                                                // 0x0688 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0690 (size: 0x8)
    bool HasGrenade?;                                                                 // 0x0698 (size: 0x1)
    bool PullPin?;                                                                    // 0x0699 (size: 0x1)
    bool Aiming?;                                                                     // 0x069A (size: 0x1)
    bool CanThrow?;                                                                   // 0x069B (size: 0x1)
    bool Dead?;                                                                       // 0x069C (size: 0x1)
    bool CanEquip/Unequip?;                                                           // 0x069D (size: 0x1)
    bool FPPView?;                                                                    // 0x069E (size: 0x1)
    class UGrenadeTPP_AnimBP_C* TPPAnimationBP;                                       // 0x06A0 (size: 0x8)
    class UGrenadeFPP_AnimBP_C* FPPAnimationBP;                                       // 0x06A8 (size: 0x8)
    class AGrenade_BP_C* GrenadeReference;                                            // 0x06B0 (size: 0x8)
    class AGrenade_BP_C* GrenadeReferenceFPP;                                         // 0x06B8 (size: 0x8)

    void InpActEvt_LeftShift_K2Node_InputKeyEvent_7(FKey Key);
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_6(FKey Key);
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_5(FKey Key);
    void InpActEvt_SpaceBar_K2Node_InputKeyEvent_4(FKey Key);
    void InpActEvt_E_K2Node_InputKeyEvent_3(FKey Key);
    void InpActEvt_RightMouseButton_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_Escape_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_T_K2Node_InputKeyEvent_0(FKey Key);
    void ReceiveBeginPlay();
    void InpAxisEvt_Forward_K2Node_InputAxisEvent_0(float AxisValue);
    void InpAxisEvt_Right_K2Node_InputAxisEvent_9(float AxisValue);
    void InpAxisEvt_Turn_K2Node_InputAxisEvent_28(float AxisValue);
    void InpAxisEvt_LookUp_K2Node_InputAxisEvent_86(float AxisValue);
    void SetTPPAnimClass();
    void Death();
    void SetFPPAnimClass();
    void SpawnGrenade();
    void throwgrenade();
    void FPPView();
    void TPPView();
    void ExecuteUbergraph_GrenadeCharacter_BP(int32 EntryPoint);
}; // Size: 0x6C0

#endif
