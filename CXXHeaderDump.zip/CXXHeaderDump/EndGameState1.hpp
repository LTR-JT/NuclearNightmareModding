#ifndef UE4SS_SDK_EndGameState1_HPP
#define UE4SS_SDK_EndGameState1_HPP

class UEndGameState1_C : public UUserWidget
{
    char padding_0[0x2E0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x2E0

#endif
