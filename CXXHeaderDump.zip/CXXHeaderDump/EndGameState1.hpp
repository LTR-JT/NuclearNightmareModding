#ifndef UE4SS_SDK_EndGameState1_HPP
#define UE4SS_SDK_EndGameState1_HPP

class UEndGameState1_C : public UUserWidget
{
}; // Size: 0x2E0

#endif
