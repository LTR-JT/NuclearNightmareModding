#ifndef UE4SS_SDK_BP_NNFirstPersonPlayerState_HPP
#define UE4SS_SDK_BP_NNFirstPersonPlayerState_HPP

class ABP_NNFirstPersonPlayerState_C : public ANuclearNightmarePlayerState
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0380 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0388 (size: 0x8)
    int32 PointsAddedInGame;                                                          // 0x0390 (size: 0x4)

    void SendNotificationAsSelf(FString Text, TEnumAsByte<ENotificaitonIcon::Type> Icon);
    void LocalNotifAsSelf(FString Text, TEnumAsByte<ENotificaitonIcon::Type> Icon);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void LocalNotif(FText Text, TEnumAsByte<ENotificaitonIcon::Type> Icon);
    void RPCUpdatePointsadded(int32 PointsAddedInGame);
    void ExecuteUbergraph_BP_NNFirstPersonPlayerState(int32 EntryPoint);
}; // Size: 0x394

#endif
