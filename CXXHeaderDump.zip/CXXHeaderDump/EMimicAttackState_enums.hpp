namespace EMimicAttackState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        EMimicAttackState_MAX = 2,
    };
}

