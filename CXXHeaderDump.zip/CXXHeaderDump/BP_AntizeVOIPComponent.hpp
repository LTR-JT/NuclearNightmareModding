#ifndef UE4SS_SDK_BP_AntizeVOIPComponent_HPP
#define UE4SS_SDK_BP_AntizeVOIPComponent_HPP

class UBP_AntizeVOIPComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UVOIPTalker* MyVoiceRef;                                                    // 0x00A8 (size: 0x8)
    double MaxDistanceForVOIPWidget;                                                  // 0x00B0 (size: 0x8)
    double MaxDistanceForTeamVOIPWidget;                                              // 0x00B8 (size: 0x8)
    bool PlaySoundEffect?;                                                            // 0x00C0 (size: 0x1)
    bool VOIPLoopBack?;                                                               // 0x00C1 (size: 0x1)
    char padding_0[0x2];                                                              // 0x00C2 (size: 0x2)
    int32 PlayerId;                                                                   // 0x00C4 (size: 0x4)
    int32 Attempt;                                                                    // 0x00C8 (size: 0x4)
    char padding_1[0x4];                                                              // 0x00CC (size: 0x4)
    class ACharacter* CharacterRef;                                                   // 0x00D0 (size: 0x8)
    FTimerHandle Timer_CheckForLoop;                                                  // 0x00D8 (size: 0x8)
    FTimerHandle Timer_Secure;                                                        // 0x00E0 (size: 0x8)
    class UW_VOIPHUD_C* HUDRef;                                                       // 0x00E8 (size: 0x8)
    bool VOIPIconVisible?;                                                            // 0x00F0 (size: 0x1)
    bool IsMuted?;                                                                    // 0x00F1 (size: 0x1)
    char padding_2[0x6];                                                              // 0x00F2 (size: 0x6)
    class UW_PlayerList_C* PlayerLisrRef;                                             // 0x00F8 (size: 0x8)
    bool IsVOIPActivated?;                                                            // 0x0100 (size: 0x1)
    char padding_3[0x3];                                                              // 0x0101 (size: 0x3)
    int32 TeamID;                                                                     // 0x0104 (size: 0x4)
    class UAudioComponent* SoundEffect;                                               // 0x0108 (size: 0x8)
    bool HasTalker?;                                                                  // 0x0110 (size: 0x1)
    char padding_4[0x7];                                                              // 0x0111 (size: 0x7)
    class USoundBase* EffectSound;                                                    // 0x0118 (size: 0x8)
    class USoundBase* BipSound;                                                       // 0x0120 (size: 0x8)
    bool LastTry;                                                                     // 0x0128 (size: 0x1)
    bool WorldIconObstacle?;                                                          // 0x0129 (size: 0x1)
    bool HasRadio;                                                                    // 0x012A (size: 0x1)
    bool UsingRadioToTalk;                                                            // 0x012B (size: 0x1)
    bool IsSpectator;                                                                 // 0x012C (size: 0x1)

    void MySetAttenuation(bool AllPlayer?, int32 ToPlayerID, class USoundAttenuation* InAttenuationSettings);
    void OnDeath();
    void FlipFlopSoundEffect();
    void OnBip();
    void OnEffectSound(bool InHasTalker?);
    void OnRep_TeamID();
    void ShowHidePlayerList();
    void OnJoinTeam(int32 NewTeamID);
    void CheckForVOIP();
    void CanPassOnTeam(int32 PlayerTeamID, int32 MyTeamNewID, int32 MyTeamOldID, bool& CanPass?);
    void GetIsInSameTeam(int32 TeamID_1, int32 TeamID_2, bool& InSameTeam?);
    class USoundAttenuation* GetAttenutation(bool UsingRadio, bool IsMuted?, bool DoWeHaveRadio, bool Spectator, class USoundEffectSourcePresetChain*& Effect);
    void ActivateDeactivateVOIP(bool Activated?);
    void Local_MuteUnmutePlayer(int32 PlayerId);
    void Locally_SetIsMuted(bool Mute?, bool InMyTeam);
    void CreateVOIP();
    void ReceiveBeginPlay();
    void Local_SetVisibilityIcon(bool Visible?);
    void Secure();
    void Local_RefreshAttenuationOnTeam(bool UsingRadio?, bool Force?, bool DoWeHaveRadio, bool Spectator);
    void Server_SetVOIPActivated(bool VOIPActivated?);
    void OnTimer_CheckForVOIP();
    void CallSetAttenuationOnTeam(bool PassToAnotherPlayer?, bool UsingRadio?, class AActor* ToPlayerRef, class AActor* FromPlayerRef, bool DoWeHaveRadio?);
    void Server_SendSetAttenuationOnTeam(bool UsingRadio?, class AActor* ToPlayerRef, class AActor* FromPlayerRef, bool DoWeHaveRadio);
    void Server_SetTeamID(int32 TeamID);
    void Client_RefreshAttenuationOnTeam(bool UsingRadio?, class AActor* FromPlayerRef, bool DoWeHaveRadio?);
    void CallOnRepTeamID();
    void Server_PlayBipOnPlayer(class USoundBase* Sound);
    void Client_PlayBip(class USoundBase* Sound);
    void Server_SetPlayerID(int32 PlayerId);
    void SetVOIPLoopBack(bool VOIPLoopBack?);
    void CallOnEffectSound(bool InHasTalker?);
    void LocalUseRadio();
    void ReceiveTick(float DeltaSeconds);
    void VoiceChatStartEvent();
    void RefreshAttentuation();
    void SetVoiceChatTimer();
    void ExecuteUbergraph_BP_AntizeVOIPComponent(int32 EntryPoint);
}; // Size: 0x12D

#endif
