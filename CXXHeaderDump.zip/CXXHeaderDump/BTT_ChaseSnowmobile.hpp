#ifndef UE4SS_SDK_BTT_ChaseSnowmobile_HPP
#define UE4SS_SDK_BTT_ChaseSnowmobile_HPP

class UBTT_ChaseSnowmobile_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class AStalker_AI_C* As Stalker AI;                                               // 0x00B0 (size: 0x8)

    void OnFail_E46957ED4E20E6D51A9961B2AA6938B9(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_E46957ED4E20E6D51A9961B2AA6938B9(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_ChaseSnowmobile(int32 EntryPoint);
}; // Size: 0xB8

#endif
