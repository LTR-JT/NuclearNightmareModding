#ifndef UE4SS_SDK_BP_West_Bomb_MK82_HPP
#define UE4SS_SDK_BP_West_Bomb_MK82_HPP

class ABP_West_Bomb_MK82_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCineCameraComponent* CineCamera;                                           // 0x0298 (size: 0x8)
    class USpringArmComponent* SpringArm1;                                            // 0x02A0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x02A8 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02B8 (size: 0x8)
    float Timeline_NewTrack_0_71F21C9841A8E9360BC15CB123D8BFD9;                       // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_71F21C9841A8E9360BC15CB123D8BFD9; // 0x02C4 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02C8 (size: 0x8)
    bool Check;                                                                       // 0x02D0 (size: 0x1)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void ReceiveBeginPlay();
    void BndEvt__BP_West_Bomb_MK82_StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(class UPrimitiveComponent* HitComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
    void ExecuteUbergraph_BP_West_Bomb_MK82(int32 EntryPoint);
}; // Size: 0x2D1

#endif
