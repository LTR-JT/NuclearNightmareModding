#ifndef UE4SS_SDK_Chat_Message_UI_HPP
#define UE4SS_SDK_Chat_Message_UI_HPP

class UChat_Message_UI_C : public UUserWidget
{
    class UTextBlock* TextBlock;                                                      // 0x02E0 (size: 0x8)
    class UTextBlock* TextBlock_26;                                                   // 0x02E8 (size: 0x8)
    FText UserName;                                                                   // 0x02F0 (size: 0x10)
    FText MessageText;                                                                // 0x0300 (size: 0x10)

    FText GetText_0();
    FText GetText();
}; // Size: 0x310

#endif
