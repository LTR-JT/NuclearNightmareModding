namespace ENiagaraWindFrictionDistanceMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraWindFrictionDistanceMode_MAX = 2,
    };
}

