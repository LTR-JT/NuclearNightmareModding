#ifndef UE4SS_SDK_BP_DogBowl_HPP
#define UE4SS_SDK_BP_DogBowl_HPP

class ABP_DogBowl_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_DogBowl(int32 EntryPoint);
}; // Size: 0x2A8

#endif
