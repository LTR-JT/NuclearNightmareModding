#ifndef UE4SS_SDK_BP_ButtonStyle-Top_HPP
#define UE4SS_SDK_BP_ButtonStyle-Top_HPP

class UBP_ButtonStyle-Top_C : public UBP_ButtonStyle_Master_C
{
    char padding_0[0x7B0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x7B0

#endif
