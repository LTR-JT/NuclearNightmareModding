#ifndef UE4SS_SDK_BP_ButtonStyle-Top_HPP
#define UE4SS_SDK_BP_ButtonStyle-Top_HPP

class UBP_ButtonStyle-Top_C : public UBP_ButtonStyle_Master_C
{
}; // Size: 0x7B0

#endif
