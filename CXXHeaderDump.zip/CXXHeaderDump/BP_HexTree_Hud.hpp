#ifndef UE4SS_SDK_BP_HexTree_Hud_HPP
#define UE4SS_SDK_BP_HexTree_Hud_HPP

class ABP_HexTree_Hud_C : public AHUD
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0380 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0388 (size: 0x8)

    void ReceiveDrawHUD(int32 SizeX, int32 SizeY);
    void ExecuteUbergraph_BP_HexTree_Hud(int32 EntryPoint);
}; // Size: 0x390

#endif
