#ifndef UE4SS_SDK_BP_FirstPersonGameState_HPP
#define UE4SS_SDK_BP_FirstPersonGameState_HPP

class ABP_FirstPersonGameState_C : public AGameStateBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02F0 (size: 0x8)
    class AGameStartService_C* ServiceStart;                                          // 0x02F8 (size: 0x8)
    int32 LobbyMinutes;                                                               // 0x0300 (size: 0x4)
    int32 LobbySeconds;                                                               // 0x0304 (size: 0x4)
    TArray<class APlayerStart*> LobbyStarts;                                          // 0x0308 (size: 0x10)
    FTimerHandle LobbyTimer;                                                          // 0x0318 (size: 0x8)
    int32 SelectedIndex;                                                              // 0x0320 (size: 0x4)
    TArray<class ABP_FirstPersonCharacter_C*> PlayersInHeliRadius;                    // 0x0328 (size: 0x10)
    TArray<class ABP_FirstPersonCharacter_C*> AllCharacters;                          // 0x0338 (size: 0x10)
    bool bAllPlayersInHeli?;                                                          // 0x0348 (size: 0x1)
    double RandomValueFloat;                                                          // 0x0350 (size: 0x8)
    int32 RandomValueInteger;                                                         // 0x0358 (size: 0x4)
    int32 GenIndex;                                                                   // 0x035C (size: 0x4)
    TArray<class ABP_GeneratorGameplayNew_C*> GenList;                                // 0x0360 (size: 0x10)
    int32 NukeMins;                                                                   // 0x0370 (size: 0x4)
    int32 NukeSecs;                                                                   // 0x0374 (size: 0x4)
    FTimerHandle NukeTimeHandle;                                                      // 0x0378 (size: 0x8)
    int32 TotalClassified;                                                            // 0x0380 (size: 0x4)
    TMap<FString, int32> ClassifiedMap;                                               // 0x0388 (size: 0x50)
    bool StartedGame?;                                                                // 0x03D8 (size: 0x1)
    bool SateliteOn?;                                                                 // 0x03D9 (size: 0x1)
    FBP_FirstPersonGameState_CSateliteTurnedON SateliteTurnedON;                      // 0x03E0 (size: 0x10)
    void SateliteTurnedON();
    bool InteractedWithBaseCamp1;                                                     // 0x03F0 (size: 0x1)
    bool InteractedWithBaseCamp2;                                                     // 0x03F1 (size: 0x1)
    TMap<class FString, class bool> DrillPanels;                                      // 0x03F8 (size: 0x50)
    bool GeneratedReport?;                                                            // 0x0448 (size: 0x1)
    FBP_FirstPersonGameState_CDrill1 Drill1;                                          // 0x0450 (size: 0x10)
    void Drill1();
    FBP_FirstPersonGameState_CDrill2 Drill2;                                          // 0x0460 (size: 0x10)
    void Drill2();
    int32 PhotosTaken;                                                                // 0x0470 (size: 0x4)
    int32 NuclearTaken;                                                               // 0x0474 (size: 0x4)
    TMap<class FString, class bool> OilPanels;                                        // 0x0478 (size: 0x50)
    int32 OilTaken;                                                                   // 0x04C8 (size: 0x4)
    int32 SlaughterTaken;                                                             // 0x04CC (size: 0x4)
    bool ScannedForInfection;                                                         // 0x04D0 (size: 0x1)
    bool GeneratedReport?2;                                                           // 0x04D1 (size: 0x1)
    TMap<class FString, class bool> Drones;                                           // 0x04D8 (size: 0x50)
    FBP_FirstPersonGameState_CDrone1 Drone1;                                          // 0x0528 (size: 0x10)
    void Drone1();
    FBP_FirstPersonGameState_CDrone2 Drone2;                                          // 0x0538 (size: 0x10)
    void Drone2();
    FBP_FirstPersonGameState_CDrone3 Drone3;                                          // 0x0548 (size: 0x10)
    void Drone3();
    TEnumAsByte<EDiffculty::Type> Diffculty;                                          // 0x0558 (size: 0x1)
    TEnumAsByte<EDayNightCycle::Type> Night Cycle;                                    // 0x0559 (size: 0x1)
    TEnumAsByte<EItemSpawnProbability::Type> Item Spawn;                              // 0x055A (size: 0x1)
    TEnumAsByte<ENukeTimer::Type> Nuke Timer;                                         // 0x055B (size: 0x1)
    bool TurnOffNuke?;                                                                // 0x055C (size: 0x1)
    class ABP_West_Heli_Lobby_C* LobbyHelicopter;                                     // 0x0560 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> FP;                                     // 0x0568 (size: 0x10)
    TEnumAsByte<EDiffculty::Type> Classified Minium;                                  // 0x0578 (size: 0x1)
    bool Day Night Allow Enemy;                                                       // 0x0579 (size: 0x1)
    bool CalledEvakHelicopter;                                                        // 0x057A (size: 0x1)
    FBP_FirstPersonGameState_CGameHasStarted GameHasStarted;                          // 0x0580 (size: 0x10)
    void GameHasStarted();
    TArray<FText> Messages;                                                           // 0x0590 (size: 0x10)
    TArray<FString> UsernameAssioated;                                                // 0x05A0 (size: 0x10)
    FVector RandomGenLocation;                                                        // 0x05B0 (size: 0x18)
    TArray<FString> ItemSpawns;                                                       // 0x05C8 (size: 0x10)
    TArray<class APlayerState*> PlayerStates;                                         // 0x05D8 (size: 0x10)
    FTimerHandle MatchTimer;                                                          // 0x05E8 (size: 0x8)
    int32 MatchOverallTime;                                                           // 0x05F0 (size: 0x4)
    bool Playable Enemy;                                                              // 0x05F4 (size: 0x1)
    FBP_FirstPersonGameState_CStarted Started;                                        // 0x05F8 (size: 0x10)
    void Started();
    FBP_FirstPersonGameState_CCanTakeFallDamage CanTakeFallDamage;                    // 0x0608 (size: 0x10)
    void CanTakeFallDamage();
    FBP_FirstPersonGameState_CReleaseMovement ReleaseMovement;                        // 0x0618 (size: 0x10)
    void ReleaseMovement();
    bool EOGLock;                                                                     // 0x0628 (size: 0x1)
    bool Airborn Infection;                                                           // 0x0629 (size: 0x1)
    bool Never Spawn Playable;                                                        // 0x062A (size: 0x1)
    double ClosestLocation;                                                           // 0x0630 (size: 0x8)
    class AHelicopter_BP_Showcase_Landing_C* FoundHeliShowcase;                       // 0x0638 (size: 0x8)
    FBP_FirstPersonGameState_CRequestReplay? RequestReplay?;                          // 0x0640 (size: 0x10)
    void RequestReplay?();
    TMap<class ABP_FirstPersonCharacter_C*, class AController*> QuedPlayers;          // 0x0650 (size: 0x50)
    bool CanMassInfectDogs?;                                                          // 0x06A0 (size: 0x1)
    bool Disable Reinforcement;                                                       // 0x06A1 (size: 0x1)
    TMap<class ABP_FirstPersonCharacter_C*, class AItem_Radio_C*> RadioMap;           // 0x06A8 (size: 0x50)
    bool SpawnRadiosOnStart;                                                          // 0x06F8 (size: 0x1)
    bool DisableWorm;                                                                 // 0x06F9 (size: 0x1)
    bool Disable Trip Mine;                                                           // 0x06FA (size: 0x1)
    int32 TimesUsedReinforcements;                                                    // 0x06FC (size: 0x4)
    bool Disable Infection Notifies;                                                  // 0x0700 (size: 0x1)
    FBP_FirstPersonGameState_CCalledRevive CalledRevive;                              // 0x0708 (size: 0x10)
    void CalledRevive(class ABP_FirstPersonCharacter_C* NewCharacter);
    class AController* ControlledPassedToQue;                                         // 0x0718 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterPassedToQue;                           // 0x0720 (size: 0x8)
    bool GameHasEnded;                                                                // 0x0728 (size: 0x1)
    FBP_FirstPersonGameState_CGameEnded GameEnded;                                    // 0x0730 (size: 0x10)
    void GameEnded();
    TMap<class AController*, class bool> HeliControllerMap;                           // 0x0740 (size: 0x50)
    FBP_FirstPersonGameState_CEnemyDestroyedGen EnemyDestroyedGen;                    // 0x0790 (size: 0x10)
    void EnemyDestroyedGen();
    bool Disable Leeches;                                                             // 0x07A0 (size: 0x1)
    TMap<class ABP_FirstPersonCharacter_C*, class AController*> QuedPlayersLOCAL;     // 0x07A8 (size: 0x50)
    int32 Enemy Freq;                                                                 // 0x07F8 (size: 0x4)
    TEnumAsByte<EVehicleSpawnFrequency::Type> SnowcatFreq;                            // 0x07FC (size: 0x1)
    TEnumAsByte<EVehicleSpawnFrequency::Type> SnowmobileFreq;                         // 0x07FD (size: 0x1)
    TEnumAsByte<EVehicleSpawnFrequency::Type> HelicopterFreq;                         // 0x07FE (size: 0x1)

    int32 FindRandomIntegerServer(int32 Min, int32 Max);
    double FindRandomFloatServer(double Min, double Max);
    void ReceiveBeginPlay();
    void Timer();
    void AddPlayerToHeli(class ABP_FirstPersonCharacter_C* Character, class AHelicopterRadius_C* RadiusActor);
    void RemovePlayerFromHeli(class ABP_FirstPersonCharacter_C* Character);
    void FindRandomFloatOnlyServ(double Min, double Max);
    void ReturnedValue(double RandomValueFloat);
    void FindRandomIntOnlyServer(int32 Min, int32 Max);
    void ReturnedValueInteger(int32 RandomValueInteger);
    void FindGenSpawn(class ABP_GeneratorGameplayNew_C* Gen);
    void UpdateGenOnClient(class ABP_GeneratorGameplayNew_C* Gen, FVector Location);
    void NuclearTimer();
    void UpdateSiren();
    void UpdateSirenServer();
    void UpdateNukeTime(int32 Amount);
    void UpdateNukeTimeServer(int32 Amount);
    void UpdateFriendlyFireALL(bool State, TEnumAsByte<EDayNightCycle::Type> NightCycle, TEnumAsByte<EDiffculty::Type> Diffculty, TEnumAsByte<EItemSpawnProbability::Type> ItemSpawn, TEnumAsByte<ENukeTimer::Type> NukeTimer, TEnumAsByte<EDiffculty::Type> ClassifiedMinium, bool DayNightAllowEnemy, bool PlayableEnemy, bool AirbornInfection, bool NeverSpawnPlayable, bool DisableReinforcement, bool DogMass, bool DisableWorm, bool DisableTripMine, bool DisableInfectionNotifies, bool DisableLeeches, int32 EnemyFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowmobileFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowcatFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> HelicopterFreq);
    void UpdateFriendlyFire(bool State, TEnumAsByte<EDayNightCycle::Type> NightCycle, TEnumAsByte<EDiffculty::Type> Diffculty, TEnumAsByte<EItemSpawnProbability::Type> ItemSpawn, TEnumAsByte<ENukeTimer::Type> NukeTimer, TEnumAsByte<EDiffculty::Type> ClassifiedMinium, bool DayNightAllowEnemy, bool PlayableEnemy, bool AirbornInfection, bool NeverSpawnPlayable, bool DisableReinforcement, bool DogMass, bool DisableWorm, bool DisableTripMine, bool DisableInfectionNotifies, bool DisableLeeches, int32 EnemyFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowmobileFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowcatFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> HelicopterFreq);
    void NonTeamSpawn();
    void AddPlayerToLobby();
    void SendMessages?(FText Message, FString UserName);
    void RPCMessage(FText Message, FString UserName);
    void GameOverallTime();
    void CleanUpAll();
    void CleanUpAllMulti();
    void LoadLevelStream(FName LevelName);
    void LoadLevelStreamServer(FName LevelName);
    void UpdateHeliVis(class AHelicopter_BP_Showcase_Landing_C* Heli);
    void UpdateHeliShowcaseNearest(class AHelicopter_BP_Showcase_Landing_C* Heli);
    void UpdatePlayerJoinEvent();
    void UpdateJoinEvent();
    void UpdateRespawnQue(class AController* Controller, class ABP_FirstPersonCharacter_C* Character);
    void UpdateRespawnQueAll(class AController* Controller, class ABP_FirstPersonCharacter_C* Character);
    void AddRadioItem(class AItem_Radio_C* Radio, class ABP_FirstPersonCharacter_C* Character);
    void AddRadioItemRPC(class AItem_Radio_C* Radio, class ABP_FirstPersonCharacter_C* Character);
    void RemoveFromQue(const class ABP_FirstPersonCharacter_C*& Key);
    void RemoveFromRespawnQue(const class ABP_FirstPersonCharacter_C*& Key);
    void StartEndGameTimer();
    void StartEndGame();
    void SendNotificationToAll(FString Text, class ABP_NNFirstPersonPlayerState_C* TargetedPlayer, TEnumAsByte<ENotificaitonIcon::Type> Icon);
    void ExecuteUbergraph_BP_FirstPersonGameState(int32 EntryPoint);
    void EnemyDestroyedGen__DelegateSignature();
    void GameEnded__DelegateSignature();
    void CalledRevive__DelegateSignature(class ABP_FirstPersonCharacter_C* NewCharacter);
    void RequestReplay?__DelegateSignature();
    void ReleaseMovement__DelegateSignature();
    void CanTakeFallDamage__DelegateSignature();
    void Started__DelegateSignature();
    void GameHasStarted__DelegateSignature();
    void Drone3__DelegateSignature();
    void Drone2__DelegateSignature();
    void Drone1__DelegateSignature();
    void Drill2__DelegateSignature();
    void Drill1__DelegateSignature();
    void SateliteTurnedON__DelegateSignature();
}; // Size: 0x7FF

#endif
