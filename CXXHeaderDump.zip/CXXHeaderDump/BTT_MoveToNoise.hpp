#ifndef UE4SS_SDK_BTT_MoveToNoise_HPP
#define UE4SS_SDK_BTT_MoveToNoise_HPP

class UBTT_MoveToNoise_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector NoiseLocation;                                             // 0x00B0 (size: 0x28)
    bool FinishExecute?;                                                              // 0x00D8 (size: 0x1)
    FBlackboardKeySelector Player;                                                    // 0x00E0 (size: 0x28)

    void OnFail_C989815B47F50C87EEB5218186C13F43(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_C989815B47F50C87EEB5218186C13F43(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MoveToNoise(int32 EntryPoint);
}; // Size: 0x108

#endif
