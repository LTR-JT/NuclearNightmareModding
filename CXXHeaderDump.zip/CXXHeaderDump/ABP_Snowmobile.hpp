#ifndef UE4SS_SDK_ABP_Snowmobile_HPP
#define UE4SS_SDK_ABP_Snowmobile_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_79;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_80;                                                          // 0x000C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_81;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_8;           // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_WheelController;        // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_MeshRefPose;            // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_7;           // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_6;           // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_11;            // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_10;            // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_9;             // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_8;             // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_7;             // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_6;             // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_5;             // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_4;             // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_3;             // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_2;             // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt_1;               // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LookAt;                 // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_1;             // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone;               // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_5;           // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_4;           // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_3;           // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_2;           // 0x0550 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0580 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x05B0 (size: 0x30)

}; // Size: 0x5E0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
}; // Size: 0x1

class UABP_Snowmobile_C : public UVehicleAnimationInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0AF0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0AF8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0B00 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0B08 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;                                  // 0x0B28 (size: 0x128)
    FAnimNode_WheelController AnimGraphNode_WheelController;                          // 0x0C50 (size: 0xE0)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x0D30 (size: 0x10)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0D40 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;                                  // 0x0D60 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;                                  // 0x0E88 (size: 0x128)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_11;                                     // 0x0FB0 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_10;                                     // 0x10A0 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_9;                                      // 0x1190 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_8;                                      // 0x1280 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_7;                                      // 0x1370 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_6;                                      // 0x1460 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_5;                                      // 0x1550 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_4;                                      // 0x1640 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_3;                                      // 0x1730 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_2;                                      // 0x1820 (size: 0xF0)
    FAnimNode_LookAt AnimGraphNode_LookAt_1;                                          // 0x1910 (size: 0x250)
    FAnimNode_LookAt AnimGraphNode_LookAt;                                            // 0x1B60 (size: 0x250)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_1;                                      // 0x1DB0 (size: 0xF0)
    FAnimNode_CopyBone AnimGraphNode_CopyBone;                                        // 0x1EA0 (size: 0xF0)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;                                  // 0x1F90 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;                                  // 0x20B8 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;                                  // 0x21E0 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;                                  // 0x2308 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x2430 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x2558 (size: 0x128)
    class ABP_SnowmobileOld_C* BP_Snowmobile;                                         // 0x2680 (size: 0x8)
    double Gauge Speed;                                                               // 0x2688 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_F1E4F1DB456DFAE3EDD5D8B3108EC83D();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_4BC614834AF74357D4C909A14579687E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_F6C468D04FFA070C38E6A8A872260C33();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_D5248853412642089C5AC4A06A45DA0E();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_461B474B48642D8957BFCD9B5A166AEB();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_7D10D35C4CC23EE394057B8181C55EF8();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_AC7692FF4850F8455C26ED8C1D2271A1();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_9F43D3374D36BD2627D1D39D18207D34();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Snowmobile_AnimGraphNode_ModifyBone_ADB1F5974863E3939957D3A8DCE60EFD();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_ABP_Snowmobile(int32 EntryPoint);
}; // Size: 0x2690

#endif
