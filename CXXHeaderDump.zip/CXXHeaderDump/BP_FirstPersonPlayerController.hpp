#ifndef UE4SS_SDK_BP_FirstPersonPlayerController_HPP
#define UE4SS_SDK_BP_FirstPersonPlayerController_HPP

class ABP_FirstPersonPlayerController_C : public ANuclearNightmarePlayerController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0860 (size: 0x8)
    class UAudioCaptureComponent* AudioCapture;                                       // 0x0868 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction;                             // 0x0870 (size: 0x8)
    class UChat_UI_Canavas_C* ChatUI;                                                 // 0x0878 (size: 0x8)
    TMap<class ABP_FirstPersonCharacter_C*, class APlayerState*> Players;             // 0x0880 (size: 0x50)
    int32 ProfilePictureAttempts;                                                     // 0x08D0 (size: 0x4)
    int32 PlayerProfileIndex;                                                         // 0x08D4 (size: 0x4)
    bool IsUsingGamepad;                                                              // 0x08D8 (size: 0x1)
    bool KeepRefreshingProfileAvatars?;                                               // 0x08D9 (size: 0x1)
    char padding_0[0x6];                                                              // 0x08DA (size: 0x6)
    class ABP_FirstPersonCharacter_C* DirectCharRef;                                  // 0x08E0 (size: 0x8)
    class UTutorialSaveGame_C* As Tutorial Save Game;                                 // 0x08E8 (size: 0x8)
    class UUI_NuclearPauseMenu_C* PauseMenu;                                          // 0x08F0 (size: 0x8)
    float AudioCaptureResult;                                                         // 0x08F8 (size: 0x4)
    bool InEndGameCircle;                                                             // 0x08FC (size: 0x1)
    char padding_1[0x3];                                                              // 0x08FD (size: 0x3)
    class UCurrentlyTalking_C* AudioCaptureWidget;                                    // 0x0900 (size: 0x8)
    bool bAudioCapture;                                                               // 0x0908 (size: 0x1)
    char padding_2[0x3];                                                              // 0x0909 (size: 0x3)
    int32 LastUsedChannel;                                                            // 0x090C (size: 0x4)
    bool UsingRadio?;                                                                 // 0x0910 (size: 0x1)
    bool AlreadyBindedToDelegate;                                                     // 0x0911 (size: 0x1)
    char padding_3[0x6];                                                              // 0x0912 (size: 0x6)
    class ABP_FirstPersonCharacter_C* As BP First Person Character;                   // 0x0918 (size: 0x8)
    class Uvoipsettings_save_C* VoipSettings;                                         // 0x0920 (size: 0x8)

    void LeaveSession();
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_4(FKey Key);
    void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3(FKey Key);
    void InpActEvt_Escape_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_Gamepad_Special_Right_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_0(FKey Key);
    void InpActEvt_IA_VoiceChat_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VoiceChat_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ExecuteAll(FKey Key, bool Release);
    void Pointer(FKey Key, bool Release);
    void CloseMenuChat();
    void ReceiveBeginPlay();
    void RecieveMessage(FText Text, FString UserName);
    void UpdateServerKey(FKey Key, bool Release);
    void UpdateKeyRPC(FKey Key, bool Release);
    void UpdateProfiles(class ABP_FirstPersonCharacter_C* Character, class APlayerState* PlayerState);
    void RPCUpdateAvatars(class ABP_FirstPersonCharacter_C* Character, class APlayerState* PlayerState);
    void SRSpawnPlayer();
    void ReInitateSearchForProfiles();
    void ReinitateSearchOwningClient();
    void TutorialHelp();
    void Started();
    void BndEvt__BP_FirstPersonPlayerController_AudioCapture_K2Node_ComponentBoundEvent_0_OnSynthEnvelopeValue__DelegateSignature(const float EnvelopeValue);
    void ReceiveTick(float DeltaSeconds);
    void UpdateRadioStatus(bool State);
    void GetDevices(const TArray<FAudioInputDeviceInfo2>& AvailableDevices);
    void ExecuteUbergraph_BP_FirstPersonPlayerController(int32 EntryPoint);
}; // Size: 0x928

#endif
