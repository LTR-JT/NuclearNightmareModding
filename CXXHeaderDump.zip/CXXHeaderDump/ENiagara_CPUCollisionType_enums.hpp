namespace ENiagara_CPUCollisionType {
    enum Type {
        NewEnumerator1 = 0,
        NewEnumerator3 = 1,
        ENiagara_MAX = 2,
    };
}

