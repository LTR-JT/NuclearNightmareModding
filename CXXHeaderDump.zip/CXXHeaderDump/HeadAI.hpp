#ifndef UE4SS_SDK_HeadAI_HPP
#define UE4SS_SDK_HeadAI_HPP

class AHeadAI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x0678 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0680 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0688 (size: 0x8)
    float Timeline_NewTrack_0_C7BC273C43F49A06156C10BF8365457F;                       // 0x0690 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_C7BC273C43F49A06156C10BF8365457F; // 0x0694 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x0698 (size: 0x8)
    bool Destroy;                                                                     // 0x06A0 (size: 0x1)
    bool JumpLogic;                                                                   // 0x06A1 (size: 0x1)
    class ABP_FirstPersonCharacter_C* As BP First Person Character;                   // 0x06A8 (size: 0x8)
    FVector NewLoc;                                                                   // 0x06B0 (size: 0x18)
    FVector CurLoc;                                                                   // 0x06C8 (size: 0x18)
    FRotator Rotator;                                                                 // 0x06E0 (size: 0x18)
    FRotator OldRotator;                                                              // 0x06F8 (size: 0x18)
    bool CnAttack?;                                                                   // 0x0710 (size: 0x1)
    bool Dead;                                                                        // 0x0711 (size: 0x1)

    bool CanBeSensed(class ANuclearNightmareCharacter* ResponsibleCharacter);
    bool InfectionDetector();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnFail_456184F143A7670CB717B3AF2207E9C9(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_456184F143A7670CB717B3AF2207E9C9(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnNotifyEnd_FBC689BD4CCC3EB18B7BC882C7477FFA(FName NotifyName);
    void OnNotifyBegin_FBC689BD4CCC3EB18B7BC882C7477FFA(FName NotifyName);
    void OnInterrupted_FBC689BD4CCC3EB18B7BC882C7477FFA(FName NotifyName);
    void OnBlendOut_FBC689BD4CCC3EB18B7BC882C7477FFA(FName NotifyName);
    void OnCompleted_FBC689BD4CCC3EB18B7BC882C7477FFA(FName NotifyName);
    void OnNotifyEnd_2A4F45934CD671202BB7DC809BCB10B2(FName NotifyName);
    void OnNotifyBegin_2A4F45934CD671202BB7DC809BCB10B2(FName NotifyName);
    void OnInterrupted_2A4F45934CD671202BB7DC809BCB10B2(FName NotifyName);
    void OnBlendOut_2A4F45934CD671202BB7DC809BCB10B2(FName NotifyName);
    void OnCompleted_2A4F45934CD671202BB7DC809BCB10B2(FName NotifyName);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void ReceiveBeginPlay();
    void Move();
    void DestroyMulti();
    void DisableFire();
    void BndEvt__HeadAI_Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void Start(class ABP_FirstPersonCharacter_C* Char);
    void StartALL(class ABP_FirstPersonCharacter_C* Char);
    void HitEvent(bool Fire, bool pickaxe);
    void HitEventAll(bool Fire, bool pickaxe);
    void ReceivePossessed(class AController* NewController);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void ExecuteUbergraph_HeadAI(int32 EntryPoint);
}; // Size: 0x712

#endif
