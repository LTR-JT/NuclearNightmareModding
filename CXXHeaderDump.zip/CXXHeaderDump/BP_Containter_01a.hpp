#ifndef UE4SS_SDK_BP_Containter_01a_HPP
#define UE4SS_SDK_BP_Containter_01a_HPP

class ABP_Containter_01a_C : public AActor
{
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01k;                              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01j;                              // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01i;                              // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01h;                              // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01g;                              // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01f;                              // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01e;                              // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01d;                              // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Case_01b_SM_Case_01b;                              // 0x02D0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02D8 (size: 0x8)

}; // Size: 0x2E0

#endif
