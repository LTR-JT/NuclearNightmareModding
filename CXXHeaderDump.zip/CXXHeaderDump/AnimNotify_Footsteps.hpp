#ifndef UE4SS_SDK_AnimNotify_Footsteps_HPP
#define UE4SS_SDK_AnimNotify_Footsteps_HPP

class UAnimNotify_Footsteps_C : public UAnimNotify
{

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x38

#endif
