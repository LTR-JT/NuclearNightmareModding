#ifndef UE4SS_SDK_BP_Common_UI_InputData_HPP
#define UE4SS_SDK_BP_Common_UI_InputData_HPP

class UBP_Common_UI_InputData_C : public UCommonUIInputData
{
    char padding_0[0x80];                                                             // 0x0000 (size: 0x0)
}; // Size: 0x80

#endif
