#ifndef UE4SS_SDK_BP_Common_UI_InputData_HPP
#define UE4SS_SDK_BP_Common_UI_InputData_HPP

class UBP_Common_UI_InputData_C : public UCommonUIInputData
{
}; // Size: 0x80

#endif
