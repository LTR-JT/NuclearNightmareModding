#ifndef UE4SS_SDK_HelicopterFuelPublic_HPP
#define UE4SS_SDK_HelicopterFuelPublic_HPP

class UHelicopterFuelPublic_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UAircraftGuage_C* AircraftGuage;                                            // 0x02E8 (size: 0x8)
    class UHeadingGuAGE_C* HeadingGuAGE;                                              // 0x02F0 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F8 (size: 0x8)
    class ABP_Helicopter_C* Snowmobile;                                               // 0x0300 (size: 0x8)

    FSlateBrush GetBrush_0();
    FSlateBrush GetBrush();
    void Construct();
    void ExecuteUbergraph_HelicopterFuelPublic(int32 EntryPoint);
}; // Size: 0x308

#endif
