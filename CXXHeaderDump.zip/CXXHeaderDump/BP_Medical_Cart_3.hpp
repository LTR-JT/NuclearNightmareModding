#ifndef UE4SS_SDK_BP_Medical_Cart_3_HPP
#define UE4SS_SDK_BP_Medical_Cart_3_HPP

class ABP_Medical_Cart_3_C : public AActor
{
    class UStaticMeshComponent* SM_Medical_Cart_3_cloth;                              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Drawer_3;                                             // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Drawer_2;                                             // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Drawer_1;                                             // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Door_1;                                               // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Door_2;                                               // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_4;                                      // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_3;                                      // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_2;                                      // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_1;                                      // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_Medical_Cart_3_body;                               // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* Wheel_4;                                              // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* Wheel_3;                                              // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* Wheel_2;                                              // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* Wheel_1;                                              // 0x0300 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0308 (size: 0x8)
    double Drawer1;                                                                   // 0x0310 (size: 0x8)
    double Drawer2;                                                                   // 0x0318 (size: 0x8)
    double Drawer3;                                                                   // 0x0320 (size: 0x8)
    double Door1;                                                                     // 0x0328 (size: 0x8)
    double Door2;                                                                     // 0x0330 (size: 0x8)
    bool ? Hide\Unhide Cloth;                                                         // 0x0338 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0339 (size: 0x7)
    double Wheel_element_1_Rotate;                                                    // 0x0340 (size: 0x8)
    double Wheel_element_2_Rotate;                                                    // 0x0348 (size: 0x8)
    double Wheel_element_3_Rotate;                                                    // 0x0350 (size: 0x8)
    double Wheel_element_4_Rotate;                                                    // 0x0358 (size: 0x8)

    void Position X(double X, bool Rotate X, class USceneComponent* TargetMesh);
    void Rotate Z(double Z (Yaw), bool Rotate Z, class USceneComponent* TargetMesh);
    void UserConstructionScript();
}; // Size: 0x360

#endif
