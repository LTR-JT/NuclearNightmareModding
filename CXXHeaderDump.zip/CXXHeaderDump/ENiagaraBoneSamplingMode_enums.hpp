namespace ENiagaraBoneSamplingMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        NewEnumerator4 = 3,
        NewEnumerator5 = 4,
        NewEnumerator6 = 5,
        ENiagaraBoneSamplingMode_MAX = 6,
    };
}

