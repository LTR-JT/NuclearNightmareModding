#ifndef UE4SS_SDK_BTT_StalkPlayer_HPP
#define UE4SS_SDK_BTT_StalkPlayer_HPP

class UBTT_StalkPlayer_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    class AStalker_AI_C* Stalker;                                                     // 0x00D8 (size: 0x8)
    FVector Random Location;                                                          // 0x00E0 (size: 0x18)
    bool FinishedTask?;                                                               // 0x00F8 (size: 0x1)

    void OnFail_AC0922D74E6D36D3EACB0FA38D9F09EA(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_AC0922D74E6D36D3EACB0FA38D9F09EA(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_751FCCDE4C2A62817408ECA3C3FE6A3E(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_751FCCDE4C2A62817408ECA3C3FE6A3E(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_StalkPlayer(int32 EntryPoint);
}; // Size: 0xF9

#endif
