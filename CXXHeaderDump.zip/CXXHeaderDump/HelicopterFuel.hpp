#ifndef UE4SS_SDK_HelicopterFuel_HPP
#define UE4SS_SDK_HelicopterFuel_HPP

class UHelicopterFuel_C : public UUserWidget
{
    class UProgressBar* ProgressBar_0;                                                // 0x02E0 (size: 0x8)
    class ABP_Helicopter_C* Snowmobile;                                               // 0x02E8 (size: 0x8)

    FLinearColor GetFillColorAndOpacity();
    float GetPercent();
}; // Size: 0x2F0

#endif
