#ifndef UE4SS_SDK_BabyWorm_AI_HPP
#define UE4SS_SDK_BabyWorm_AI_HPP

class ABabyWorm_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0678 (size: 0x8)
    class UAudioComponent* beetle;                                                    // 0x0680 (size: 0x8)
    class USphereComponent* Sphere1;                                                  // 0x0688 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x0690 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0698 (size: 0x8)
    float Timeline_NewTrack_0_BF6C892E4830DCE4D2A814A35123532B;                       // 0x06A0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_BF6C892E4830DCE4D2A814A35123532B; // 0x06A4 (size: 0x1)
    char padding_0[0x3];                                                              // 0x06A5 (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x06A8 (size: 0x8)
    class UStaticMeshComponent* Door;                                                 // 0x06B0 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x06B8 (size: 0x1)
    bool AlreadyAttacked?;                                                            // 0x06B9 (size: 0x1)
    char padding_1[0x6];                                                              // 0x06BA (size: 0x6)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x06C0 (size: 0x10)
    bool DeSpawn;                                                                     // 0x06D0 (size: 0x1)
    bool Dead?;                                                                       // 0x06D1 (size: 0x1)
    bool PlayingMontage;                                                              // 0x06D2 (size: 0x1)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnFail_6697FA4241A626C89F5D2F96542D2B65(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_6697FA4241A626C89F5D2F96542D2B65(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnNotifyEnd_877D54ED49337FB309C6EABBB97AFB1E(FName NotifyName);
    void OnNotifyBegin_877D54ED49337FB309C6EABBB97AFB1E(FName NotifyName);
    void OnInterrupted_877D54ED49337FB309C6EABBB97AFB1E(FName NotifyName);
    void OnBlendOut_877D54ED49337FB309C6EABBB97AFB1E(FName NotifyName);
    void OnCompleted_877D54ED49337FB309C6EABBB97AFB1E(FName NotifyName);
    void OnNotifyEnd_E163BB4742E897B1E5FF81AED0D93E99(FName NotifyName);
    void OnNotifyBegin_E163BB4742E897B1E5FF81AED0D93E99(FName NotifyName);
    void OnInterrupted_E163BB4742E897B1E5FF81AED0D93E99(FName NotifyName);
    void OnBlendOut_E163BB4742E897B1E5FF81AED0D93E99(FName NotifyName);
    void OnCompleted_E163BB4742E897B1E5FF81AED0D93E99(FName NotifyName);
    void OnNotifyEnd_5EB9E3244E4DBCC5CE5AD99CBBD8CF7F(FName NotifyName);
    void OnNotifyBegin_5EB9E3244E4DBCC5CE5AD99CBBD8CF7F(FName NotifyName);
    void OnInterrupted_5EB9E3244E4DBCC5CE5AD99CBBD8CF7F(FName NotifyName);
    void OnBlendOut_5EB9E3244E4DBCC5CE5AD99CBBD8CF7F(FName NotifyName);
    void OnCompleted_5EB9E3244E4DBCC5CE5AD99CBBD8CF7F(FName NotifyName);
    void OnNotifyEnd_8F83B54C4A4F68BB6C2A4F9017583F7A(FName NotifyName);
    void OnNotifyBegin_8F83B54C4A4F68BB6C2A4F9017583F7A(FName NotifyName);
    void OnInterrupted_8F83B54C4A4F68BB6C2A4F9017583F7A(FName NotifyName);
    void OnBlendOut_8F83B54C4A4F68BB6C2A4F9017583F7A(FName NotifyName);
    void OnCompleted_8F83B54C4A4F68BB6C2A4F9017583F7A(FName NotifyName);
    void OnNotifyEnd_EF03C59D4F7B935F87BBDFA71707258C(FName NotifyName);
    void OnNotifyBegin_EF03C59D4F7B935F87BBDFA71707258C(FName NotifyName);
    void OnInterrupted_EF03C59D4F7B935F87BBDFA71707258C(FName NotifyName);
    void OnBlendOut_EF03C59D4F7B935F87BBDFA71707258C(FName NotifyName);
    void OnCompleted_EF03C59D4F7B935F87BBDFA71707258C(FName NotifyName);
    void ReceiveBeginPlay();
    void BndEvt__BabyWorm_AI_Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void AttackServer(class ABP_FirstPersonCharacter_C* Character);
    void AttackAll(class ABP_FirstPersonCharacter_C* Character);
    void ReceiveTick(float DeltaSeconds);
    void MoveRan();
    void BndEvt__BabyWorm_AI_Sphere1_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void MoveAi();
    void DespawnBaby();
    void DespawnAll();
    void BndEvt__BabyWorm_AI_Mesh_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void DeathAll(FName HitBone, FVector Normal, bool Fire, bool Pickaxe);
    void DeathServer(FName HitBone, FVector Normal, bool Fre, bool Pickaxe);
    void ReceivePossessed(class AController* NewController);
    void ExecuteUbergraph_BabyWorm_AI(int32 EntryPoint);
}; // Size: 0x6D3

#endif
