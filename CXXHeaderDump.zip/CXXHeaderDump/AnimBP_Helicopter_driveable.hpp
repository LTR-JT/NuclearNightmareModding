#ifndef UE4SS_SDK_AnimBP_Helicopter_driveable_HPP
#define UE4SS_SDK_AnimBP_Helicopter_driveable_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_31;                                                          // 0x0004 (size: 0x8)
    FName __NameProperty_32;                                                          // 0x000C (size: 0x8)
    char padding_0[0x4];                                                              // 0x0014 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_33;                                         // 0x0018 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0038 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00B8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_MeshRefPose;            // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_WheelController;        // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace_1; // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x02B0 (size: 0x30)

}; // Size: 0x2E0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    char padding_0[0x1];                                                              // 0x0000 (size: 0x0)
}; // Size: 0x1

class UAnimBP_Helicopter_driveable_C : public UVehicleAnimationInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0AF0 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0AF8 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0B00 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0B08 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x0B28 (size: 0x10)
    FAnimNode_WheelController AnimGraphNode_WheelController;                          // 0x0B38 (size: 0xE0)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x0C18 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x0C38 (size: 0x128)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0D60 (size: 0x128)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0E88 (size: 0x80)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0F08 (size: 0x48)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x0F50 (size: 0x28)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0F78 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0F98 (size: 0x20)
    FRotator MainRotorRotation;                                                       // 0x0FB8 (size: 0x18)
    FRotator MainRotorRotation_0;                                                     // 0x0FD0 (size: 0x18)
    double RotorSpeedOffset;                                                          // 0x0FE8 (size: 0x8)
    double CurrentValue;                                                              // 0x0FF0 (size: 0x8)
    double TargetVlaue;                                                               // 0x0FF8 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void UpdateSpeedOffset(double Increment);
    void ExecuteUbergraph_AnimBP_Helicopter_driveable(int32 EntryPoint);
}; // Size: 0x1000

#endif
