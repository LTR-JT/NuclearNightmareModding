#ifndef UE4SS_SDK_HuskyAnimBP_HPP
#define UE4SS_SDK_HuskyAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_154;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_155;                                                         // 0x000C (size: 0x8)
    int32 __IntProperty_156;                                                          // 0x0014 (size: 0x4)
    FName __NameProperty_157;                                                         // 0x0018 (size: 0x8)
    int32 __IntProperty_158;                                                          // 0x0020 (size: 0x4)
    TArray<float> __ArrayProperty_159;                                                // 0x0028 (size: 0x10)
    FName __NameProperty_160;                                                         // 0x0038 (size: 0x8)
    FName __NameProperty_161;                                                         // 0x0040 (size: 0x8)
    int32 __IntProperty_162;                                                          // 0x0048 (size: 0x4)
    class UBlendProfile* __BlendProfile_163;                                          // 0x0050 (size: 0x8)
    class UCurveFloat* __CurveFloat_164;                                              // 0x0058 (size: 0x8)
    EAlphaBlendOption __EnumProperty_165;                                             // 0x0060 (size: 0x1)
    EBlendListTransitionType __EnumProperty_166;                                      // 0x0061 (size: 0x1)
    TArray<float> __ArrayProperty_167;                                                // 0x0068 (size: 0x10)
    FAnimNodeFunctionRef __StructProperty_168;                                        // 0x0078 (size: 0x20)
    bool __BoolProperty_169;                                                          // 0x0098 (size: 0x1)
    float __FloatProperty_170;                                                        // 0x009C (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_171;                               // 0x00A0 (size: 0x2C)
    float __FloatProperty_172;                                                        // 0x00CC (size: 0x4)
    bool __BoolProperty_173;                                                          // 0x00D0 (size: 0x1)
    EAnimSyncMethod __EnumProperty_174;                                               // 0x00D1 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_175;                             // 0x00D2 (size: 0x1)
    FName __NameProperty_176;                                                         // 0x00D4 (size: 0x8)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00E0 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0160 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0178 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3;     // 0x01A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2;     // 0x01D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x0208 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x0238 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x0268 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2;          // 0x0298 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x02C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x02F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0328 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_1;      // 0x0358 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0388 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend_1;     // 0x03B8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x03E8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0418 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0448 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0478 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x04A8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_2;        // 0x04D8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonFeetSolver;       // 0x0508 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x0538 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x0568 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x0598 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x05C8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonSpineSolver;      // 0x05F8 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x0628 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend;       // 0x0658 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0688 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x06B8 (size: 0x30)

}; // Size: 0x6E8

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)
    bool __BoolProperty_1;                                                            // 0x000C (size: 0x1)
    float __FloatProperty_2;                                                          // 0x0010 (size: 0x4)
    float __FloatProperty_3;                                                          // 0x0014 (size: 0x4)
    bool __BoolProperty_4;                                                            // 0x0018 (size: 0x1)

}; // Size: 0x19

class UHuskyAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x1C)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0398 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x03A0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x03A8 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;                      // 0x03C8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;                      // 0x03F0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0418 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0440 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x0468 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_2;                                // 0x04B0 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x04D0 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0518 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0538 (size: 0x70)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_1;                        // 0x05A8 (size: 0x48)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x05F0 (size: 0x48)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_1;                      // 0x0638 (size: 0xF0)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0728 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0798 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x07B8 (size: 0xC8)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0880 (size: 0x48)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x08C8 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;                            // 0x0948 (size: 0x28)
    FAnimNode_DragonFeetSolver AnimGraphNode_DragonFeetSolver;                        // 0x0970 (size: 0x9C0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x1330 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x1350 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x1370 (size: 0x20)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x1390 (size: 0x28)
    FAnimNode_DragonSpineSolver AnimGraphNode_DragonSpineSolver;                      // 0x13C0 (size: 0xEC0)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x2280 (size: 0x48)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x22C8 (size: 0xF0)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x23B8 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x23E0 (size: 0x48)
    double Speed;                                                                     // 0x2428 (size: 0x8)
    float Direction;                                                                  // 0x2430 (size: 0x4)
    class ABP_FirstPersonCharacter_C* Overlapped Player;                              // 0x2438 (size: 0x8)
    TEnumAsByte<HuskyBehavior::Type> Behavior;                                        // 0x2440 (size: 0x1)
    class AHusky_AI_C* Husky;                                                         // 0x2448 (size: 0x8)
    FVector LF;                                                                       // 0x2450 (size: 0x18)
    FVector RF;                                                                       // 0x2468 (size: 0x18)
    FVector RB;                                                                       // 0x2480 (size: 0x18)
    FVector LB;                                                                       // 0x2498 (size: 0x18)
    double WorldCorrection;                                                           // 0x24B0 (size: 0x8)
    float Alpha;                                                                      // 0x24B8 (size: 0x4)
    float RotationOffset;                                                             // 0x24BC (size: 0x4)
    bool OpeningDoor;                                                                 // 0x24C0 (size: 0x1)
    bool Opening Door;                                                                // 0x24C1 (size: 0x1)
    bool Set Barking;                                                                 // 0x24C2 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    bool BoneTrace(FName InSocketName, double Z, FVector& Location);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_HuskyAnimBP_AnimGraphNode_TransitionResult_E8F7FCBC44BCE161D4E00C9F5625C5A2();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_HuskyAnimBP_AnimGraphNode_TransitionResult_66C910A949D7EE63FEEE548039202271();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_HuskyAnimBP_AnimGraphNode_TransitionResult_8C6E08824DC780B35A73E68F6EEE6E6A();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_HuskyAnimBP_AnimGraphNode_TransitionResult_E13BE8594F6345C4123E8F8C0439EB48();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_HuskyAnimBP_AnimGraphNode_BlendListByBool_1EAC59924D65BB74FEC4C48100D6E36F();
    void ExecuteUbergraph_HuskyAnimBP(int32 EntryPoint);
}; // Size: 0x24C3

#endif
