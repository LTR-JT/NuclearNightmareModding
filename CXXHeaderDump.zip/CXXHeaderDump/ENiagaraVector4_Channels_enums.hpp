namespace ENiagaraVector4_Channels {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        ENiagaraVector4_MAX = 4,
    };
}

