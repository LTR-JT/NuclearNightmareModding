#ifndef UE4SS_SDK_BP_West_Heli_Lobby_HPP
#define UE4SS_SDK_BP_West_Heli_Lobby_HPP

class ABP_West_Heli_Lobby_C : public ABP_West_Heli_UH60A_Showcase_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0378 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0380 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger1;                                     // 0x0388 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger2;                                     // 0x0390 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> PassengersInside;                       // 0x0398 (size: 0x10)
    bool enableCameraEffect;                                                          // 0x03A8 (size: 0x1)
    bool CANFLYeffect;                                                                // 0x03A9 (size: 0x1)
    char padding_0[0x6];                                                              // 0x03AA (size: 0x6)
    FVector interpeffectlocation;                                                     // 0x03B0 (size: 0x18)
    FVector Inital;                                                                   // 0x03C8 (size: 0x18)
    class ABP_FirstPersonCharacter_C* Passenger3;                                     // 0x03E0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger4;                                     // 0x03E8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger5;                                     // 0x03F0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger6;                                     // 0x03F8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger7;                                     // 0x0400 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger8;                                     // 0x0408 (size: 0x8)

    void CheckifInHelicopter(TArray<class ABP_FirstPersonCharacter_C*>& Array, bool& TRUE);
    void AddPlayerToHelicopter(const TArray<class ABP_FirstPersonCharacter_C*>& Passengers);
    void AddPlayerToHelicopterServer(const TArray<class ABP_FirstPersonCharacter_C*>& Passengers);
    void RemovePlayersFromHeli();
    void ReceiveTick(float DeltaSeconds);
    void SetMove(FVector interpeffectlocation, bool CANFLYeffect);
    void SetMoveAll(FVector interpeffectlocation, bool CANFLYeffect);
    void KickPlayerFromHelicopter(class ABP_FirstPersonCharacter_C* Character);
    void KickPlayerFromHelicopterServer(class ABP_FirstPersonCharacter_C* Character);
    void UpdateID(FString ID, class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_BP_West_Heli_Lobby(int32 EntryPoint);
}; // Size: 0x410

#endif
