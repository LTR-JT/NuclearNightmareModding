#ifndef UE4SS_SDK_BP_HexTree_AC_HPP
#define UE4SS_SDK_BP_HexTree_AC_HPP

class UBP_HexTree_AC_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A0 (size: 0x8)
    class UW_MainFrame_C* HexFrame;                                                   // 0x00A8 (size: 0x8)
    class APlayerController* PlayerController;                                        // 0x00B0 (size: 0x8)
    FSTreePoints TreePoints;                                                          // 0x00B8 (size: 0xC)
    char padding_0[0x4];                                                              // 0x00C4 (size: 0x4)
    TArray<FSHex> AllValues;                                                          // 0x00C8 (size: 0x10)
    bool IsDebug;                                                                     // 0x00D8 (size: 0x1)
    char padding_1[0x7];                                                              // 0x00D9 (size: 0x7)
    class UBP_SaveTree_C* SaveGame;                                                   // 0x00E0 (size: 0x8)
    bool IsInitialized;                                                               // 0x00E8 (size: 0x1)
    bool IsOpen;                                                                      // 0x00E9 (size: 0x1)
    TEnumAsByte<ETreeType::Type> OpenTree;                                            // 0x00EA (size: 0x1)
    char padding_2[0x5];                                                              // 0x00EB (size: 0x5)
    FBP_HexTree_AC_COnHexPurchased OnHexPurchased;                                    // 0x00F0 (size: 0x10)
    void OnHexPurchased(TEnumAsByte<EHex::Type> Hex);
    FBP_HexTree_AC_COnHexTreeInit OnHexTreeInit;                                      // 0x0100 (size: 0x10)
    void OnHexTreeInit(TArray<FSHex>& AllValues);

    void FFIndHexDataTable(TEnumAsByte<EHex::Type> EHexType, bool& IsSuccess, FSHex& Out Row);
    void FLockHex(TEnumAsByte<EHex::Type> EHexType);
    void FUndo(TEnumAsByte<EHex::Type> EHexType, bool IsNeighbours, bool& IsSuccess, TArray<TEnumAsByte<EHex::Type>>& CanceledHexes);
    void FUndoBuyHex(TEnumAsByte<EHex::Type> EHexType, bool& IsSuccess, TArray<TEnumAsByte<EHex::Type>>& CanceledHexes);
    void FGetAllHexValues(TArray<FSHex>& AllValues);
    void FGetSaveDataForPlayer(class APlayerController* PlayerController, bool IsLoad, bool& IsSuccess, FSSaveTree& SaveData, int32& Array Index);
    void FRemovePoints(TEnumAsByte<ETreeType::Type> TreeType, int32 Points, bool& IsSuccess);
    void FUpdateWidgetPoints();
    void FUpdateHexWidget(TEnumAsByte<EHex::Type> EHexType, const FSHex& SPerks);
    void FSaveHexes();
    void FBuyHex(TEnumAsByte<EHex::Type> EHexType, bool& IsSuccess);
    void FUnlockHex(TEnumAsByte<EHex::Type> EHexType);
    void FCustomPrintString(FString InString);
    void FGetHexInfo(TEnumAsByte<EHex::Type> EHexType, FSHex& HexInfo, int32& Array Index);
    int32 FGetPoints(TEnumAsByte<ETreeType::Type> TreeType);
    void FSetPoints(TEnumAsByte<ETreeType::Type> TreeType, int32 Points);
    void FAddPoints(TEnumAsByte<ETreeType::Type> TreeType, int32 Points);
    void FCloseHexTree(bool IsHideCursor, TEnumAsByte<ETreeType::Type> TreeType, bool& IsVis);
    void FOpen Close Hex Tree(bool IsShowCursor, TEnumAsByte<ETreeType::Type> TreeType);
    void FLoadGame();
    void Server_LoadGame();
    void OnBuy_Widget(TEnumAsByte<EHex::Type> HexType);
    void Client_UpdateWidgetPoints(FSTreePoints TreePoints);
    void Client_UpdateHexes(const TArray<FSHex>& AllValues);
    void Server_BuyHex(TEnumAsByte<EHex::Type> EHexType);
    void Client_UpdateHex(TEnumAsByte<EHex::Type> EHexType, const FSHex& SPerks);
    void ReceiveBeginPlay();
    void Client_Notification(const FSNotifications& NewNotification);
    void OnSwitchTree(TEnumAsByte<ETreeType::Type> TreeType);
    void OnSellPerk(TEnumAsByte<EHex::Type> HexType);
    void ExecuteUbergraph_BP_HexTree_AC(int32 EntryPoint);
    void OnHexTreeInit__DelegateSignature(TArray<FSHex>& AllValues);
    void OnHexPurchased__DelegateSignature(TEnumAsByte<EHex::Type> Hex);
}; // Size: 0x110

#endif
