namespace ENiagaraWindFrictionMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraWindFrictionMode_MAX = 2,
    };
}

