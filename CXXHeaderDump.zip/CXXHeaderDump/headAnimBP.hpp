#ifndef UE4SS_SDK_headAnimBP_HPP
#define UE4SS_SDK_headAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_13;                                                          // 0x0004 (size: 0x8)
    bool __BoolProperty_14;                                                           // 0x000C (size: 0x1)
    float __FloatProperty_15;                                                         // 0x0010 (size: 0x4)
    float __FloatProperty_16;                                                         // 0x0014 (size: 0x4)
    bool __BoolProperty_17;                                                           // 0x0018 (size: 0x1)
    EAnimSyncMethod __EnumProperty_18;                                                // 0x0019 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_19;                              // 0x001A (size: 0x1)
    FName __NameProperty_20;                                                          // 0x001C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_21;                                         // 0x0028 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0048 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00C8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x00E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x0110 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0140 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0170 (size: 0x30)

}; // Size: 0x1A0

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)

}; // Size: 0x8

class UheadAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0390 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x03B0 (size: 0x70)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0420 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x04A0 (size: 0x28)
    bool Active Value;                                                                // 0x04C8 (size: 0x1)
    bool leg1;                                                                        // 0x04C9 (size: 0x1)
    bool leg2;                                                                        // 0x04CA (size: 0x1)
    bool leg3;                                                                        // 0x04CB (size: 0x1)
    double Z;                                                                         // 0x04D0 (size: 0x8)
    double Z_0;                                                                       // 0x04D8 (size: 0x8)
    double Z_1;                                                                       // 0x04E0 (size: 0x8)
    double Z_2;                                                                       // 0x04E8 (size: 0x8)
    FVector FWV;                                                                      // 0x04F0 (size: 0x18)
    double Speed;                                                                     // 0x0508 (size: 0x8)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_headAnimBP(int32 EntryPoint);
}; // Size: 0x510

#endif
