#ifndef UE4SS_SDK_DialogueBox_HPP
#define UE4SS_SDK_DialogueBox_HPP

class UDialogueBox_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UTextBlock* TextBlock_0;                                                    // 0x02E8 (size: 0x8)
    FString DisplayText;                                                              // 0x02F0 (size: 0x10)
    FString DescText;                                                                 // 0x0300 (size: 0x10)

    void Construct();
    void ExecuteUbergraph_DialogueBox(int32 EntryPoint);
}; // Size: 0x310

#endif
