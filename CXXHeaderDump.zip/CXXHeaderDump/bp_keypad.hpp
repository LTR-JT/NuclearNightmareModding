#ifndef UE4SS_SDK_bp_keypad_HPP
#define UE4SS_SDK_bp_keypad_HPP

class Abp_keypad_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0298 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    float Timeline_NewTrack_0_8D73DB474923DCC65B1CA085A86EFD89;                       // 0x02B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_8D73DB474923DCC65B1CA085A86EFD89; // 0x02BC (size: 0x1)
    char padding_0[0x3];                                                              // 0x02BD (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x02C0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02C8 (size: 0x8)
    class ABP_Door_Base_C* Door;                                                      // 0x02D0 (size: 0x8)
    bool Interacting?;                                                                // 0x02D8 (size: 0x1)
    bool State;                                                                       // 0x02D9 (size: 0x1)
    bool Interacted?;                                                                 // 0x02DA (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_0B7402A24C985DA50028FF904ED9C172(FName NotifyName);
    void OnNotifyBegin_0B7402A24C985DA50028FF904ED9C172(FName NotifyName);
    void OnInterrupted_0B7402A24C985DA50028FF904ED9C172(FName NotifyName);
    void OnBlendOut_0B7402A24C985DA50028FF904ED9C172(FName NotifyName);
    void OnCompleted_0B7402A24C985DA50028FF904ED9C172(FName NotifyName);
    void RandomSpawn();
    void DestroyAll();
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SpawnKeyPadOnClient();
    void UpdateKeypad();
    void ReceiveBeginPlay();
    void ToggleEquipment(bool Power);
    void ExecuteUbergraph_bp_keypad(int32 EntryPoint);
}; // Size: 0x2DB

#endif
