#ifndef UE4SS_SDK_LevelLocationMap_HPP
#define UE4SS_SDK_LevelLocationMap_HPP

class ALevelLocationMap_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)
    FString Name;                                                                     // 0x0298 (size: 0x10)

}; // Size: 0x2A8

#endif
