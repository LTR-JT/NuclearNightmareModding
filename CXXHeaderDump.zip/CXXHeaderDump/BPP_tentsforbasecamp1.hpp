#ifndef UE4SS_SDK_BPP_tentsforbasecamp1_HPP
#define UE4SS_SDK_BPP_tentsforbasecamp1_HPP

class ABPP_tentsforbasecamp1_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh4;                        // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh3;                        // 0x0338 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh2;                        // 0x0340 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh1;                        // 0x0348 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0350 (size: 0x8)

}; // Size: 0x358

#endif
