#ifndef UE4SS_SDK_BPP_UndergroundBunkerInterior2_HPP
#define UE4SS_SDK_BPP_UndergroundBunkerInterior2_HPP

class ABPP_UndergroundBunkerInterior2_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0330 (size: 0x8)

}; // Size: 0x338

#endif
