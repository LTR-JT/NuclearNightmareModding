#ifndef UE4SS_SDK_BP_PowerController_HPP
#define UE4SS_SDK_BP_PowerController_HPP

class ABP_PowerController_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    TArray<class ABP_PowerGenerator_C*> Generators;                                   // 0x02A8 (size: 0x10)
    TArray<class ABP_PowerConsumer_C*> Consumers;                                     // 0x02B8 (size: 0x10)
    double Generation;                                                                // 0x02C8 (size: 0x8)
    double Consumption;                                                               // 0x02D0 (size: 0x8)

    void CheckActive(bool& Active?, double& Amount);
    void ConsumePower();
    void ReceiveBeginPlay();
    void CheckChildren();
    void ExecuteUbergraph_BP_PowerController(int32 EntryPoint);
}; // Size: 0x2D8

#endif
