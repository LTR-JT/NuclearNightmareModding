namespace Enum_Icons {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        Enum_MAX = 3,
    };
}

