#ifndef UE4SS_SDK_MadPatent_AI_HPP
#define UE4SS_SDK_MadPatent_AI_HPP

class AMadPatent_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UAudioComponent* Audio1;                                                    // 0x0678 (size: 0x8)
    class USkeletalMeshComponent* SK_NC08_Claw;                                       // 0x0680 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh3;                                      // 0x0688 (size: 0x8)
    class UPhysicalAnimationComponent* PhysicalAnimation;                             // 0x0690 (size: 0x8)
    class UNiagaraComponent* CalfLTenticles;                                          // 0x0698 (size: 0x8)
    class UNiagaraComponent* CalfRTenticles;                                          // 0x06A0 (size: 0x8)
    class UNavigationInvokerComponent* NavigationInvoker;                             // 0x06A8 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x06B0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x06B8 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x06C0 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x06C8 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x06D0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x06D8 (size: 0x8)
    float Timeline_2_NewTrack_0_3959D5A64F6D7488968C5CAA028BDD4E;                     // 0x06E0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_3959D5A64F6D7488968C5CAA028BDD4E; // 0x06E4 (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x06E8 (size: 0x8)
    float Timeline_1_NewTrack_0_FAF83C1C4881C4D5CC2DC3AE0822C61C;                     // 0x06F0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_FAF83C1C4881C4D5CC2DC3AE0822C61C; // 0x06F4 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x06F8 (size: 0x8)
    float Timeline_0_NewTrack_0_D8A5F8EB46E46B9D02D656A76E7E390C;                     // 0x0700 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_D8A5F8EB46E46B9D02D656A76E7E390C; // 0x0704 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0708 (size: 0x8)
    float Timeline_NewTrack_0_900A89394AA43B4B4AD0B6862ABF6781;                       // 0x0710 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_900A89394AA43B4B4AD0B6862ABF6781; // 0x0714 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x0718 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Target;                                         // 0x0720 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x0728 (size: 0x1)
    class UStaticMeshComponent* Door;                                                 // 0x0730 (size: 0x8)
    bool AttackingPlayer;                                                             // 0x0738 (size: 0x1)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0740 (size: 0x10)
    bool DeSpawn;                                                                     // 0x0750 (size: 0x1)
    class UMaterialInstanceDynamic* BodyMaterial;                                     // 0x0758 (size: 0x8)
    class UMaterialInstanceDynamic* CreatureMat;                                      // 0x0760 (size: 0x8)
    bool FlamethrowerAttack;                                                          // 0x0768 (size: 0x1)
    bool BPIsDead;                                                                    // 0x0769 (size: 0x1)
    double StalkerDamage;                                                             // 0x0770 (size: 0x8)
    FVector Relative Location;                                                        // 0x0778 (size: 0x18)
    bool SeePlayerBool;                                                               // 0x0790 (size: 0x1)
    class ABP_FirstPersonCharacter_C* FoundPlayer;                                    // 0x0798 (size: 0x8)
    bool HearNoise;                                                                   // 0x07A0 (size: 0x1)
    FVector Noise Location;                                                           // 0x07A8 (size: 0x18)
    class ABP_FirstPersonCharacter_C* Found Player2;                                  // 0x07C0 (size: 0x8)
    bool SniperHit;                                                                   // 0x07C8 (size: 0x1)
    int32 Hits;                                                                       // 0x07CC (size: 0x4)
    class AMusicManager_C* MusicManager;                                              // 0x07D0 (size: 0x8)
    FRotator OldControlRot;                                                           // 0x07D8 (size: 0x18)
    bool hit leg;                                                                     // 0x07F0 (size: 0x1)
    bool HaveBeenAttackedByDog;                                                       // 0x07F1 (size: 0x1)
    bool ElusiveFighter;                                                              // 0x07F2 (size: 0x1)

    bool Attacking();
    bool CanSeePlayer();
    bool Dead();
    bool CanBeSensed(class ANuclearNightmareCharacter* ResponsibleCharacter);
    bool InfectionDetector();
    void BurningFX(float Add Burnt Value);
    void OpenDoorMulti(class UObject* Target1);
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void OnNotifyEnd_3CE61F3446E9382CAA20AA9FAA14CA76(FName NotifyName);
    void OnNotifyBegin_3CE61F3446E9382CAA20AA9FAA14CA76(FName NotifyName);
    void OnInterrupted_3CE61F3446E9382CAA20AA9FAA14CA76(FName NotifyName);
    void OnBlendOut_3CE61F3446E9382CAA20AA9FAA14CA76(FName NotifyName);
    void OnCompleted_3CE61F3446E9382CAA20AA9FAA14CA76(FName NotifyName);
    void OnNotifyEnd_952B09EA415E7EBE016EF7A58D5491C4(FName NotifyName);
    void OnNotifyBegin_952B09EA415E7EBE016EF7A58D5491C4(FName NotifyName);
    void OnInterrupted_952B09EA415E7EBE016EF7A58D5491C4(FName NotifyName);
    void OnBlendOut_952B09EA415E7EBE016EF7A58D5491C4(FName NotifyName);
    void OnCompleted_952B09EA415E7EBE016EF7A58D5491C4(FName NotifyName);
    void OnNotifyEnd_BA6ADB78458CB6A0CAB0F59837E78A7F(FName NotifyName);
    void OnNotifyBegin_BA6ADB78458CB6A0CAB0F59837E78A7F(FName NotifyName);
    void OnInterrupted_BA6ADB78458CB6A0CAB0F59837E78A7F(FName NotifyName);
    void OnBlendOut_BA6ADB78458CB6A0CAB0F59837E78A7F(FName NotifyName);
    void OnCompleted_BA6ADB78458CB6A0CAB0F59837E78A7F(FName NotifyName);
    void OnNotifyEnd_BB438097491AD5E8823F978CFF6E9057(FName NotifyName);
    void OnNotifyBegin_BB438097491AD5E8823F978CFF6E9057(FName NotifyName);
    void OnInterrupted_BB438097491AD5E8823F978CFF6E9057(FName NotifyName);
    void OnBlendOut_BB438097491AD5E8823F978CFF6E9057(FName NotifyName);
    void OnCompleted_BB438097491AD5E8823F978CFF6E9057(FName NotifyName);
    void OnNotifyEnd_C89B09B646E107BBAB8B0B9C28435A55(FName NotifyName);
    void OnNotifyBegin_C89B09B646E107BBAB8B0B9C28435A55(FName NotifyName);
    void OnInterrupted_C89B09B646E107BBAB8B0B9C28435A55(FName NotifyName);
    void OnBlendOut_C89B09B646E107BBAB8B0B9C28435A55(FName NotifyName);
    void OnCompleted_C89B09B646E107BBAB8B0B9C28435A55(FName NotifyName);
    void OnNotifyEnd_AE3941B14610C96F6FB32797758B1D70(FName NotifyName);
    void OnNotifyBegin_AE3941B14610C96F6FB32797758B1D70(FName NotifyName);
    void OnInterrupted_AE3941B14610C96F6FB32797758B1D70(FName NotifyName);
    void OnBlendOut_AE3941B14610C96F6FB32797758B1D70(FName NotifyName);
    void OnCompleted_AE3941B14610C96F6FB32797758B1D70(FName NotifyName);
    void OnFailure_5DB818814E0CB4679D8975AD6475C3A6();
    void OnSuccess_5DB818814E0CB4679D8975AD6475C3A6();
    void OnFailure_B44DE74B4A641FD1E7016CB03002255B(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_B44DE74B4A641FD1E7016CB03002255B(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnNotifyEnd_544E721D4264E58BA747C480F81843FD(FName NotifyName);
    void OnNotifyBegin_544E721D4264E58BA747C480F81843FD(FName NotifyName);
    void OnInterrupted_544E721D4264E58BA747C480F81843FD(FName NotifyName);
    void OnBlendOut_544E721D4264E58BA747C480F81843FD(FName NotifyName);
    void OnCompleted_544E721D4264E58BA747C480F81843FD(FName NotifyName);
    void OnNotifyEnd_FF0A005C45701C9A45AC83B297C1AF1F(FName NotifyName);
    void OnNotifyBegin_FF0A005C45701C9A45AC83B297C1AF1F(FName NotifyName);
    void OnInterrupted_FF0A005C45701C9A45AC83B297C1AF1F(FName NotifyName);
    void OnBlendOut_FF0A005C45701C9A45AC83B297C1AF1F(FName NotifyName);
    void OnCompleted_FF0A005C45701C9A45AC83B297C1AF1F(FName NotifyName);
    void OnNotifyEnd_89540A1C43B8A68891FE17ABA988E973(FName NotifyName);
    void OnNotifyBegin_89540A1C43B8A68891FE17ABA988E973(FName NotifyName);
    void OnInterrupted_89540A1C43B8A68891FE17ABA988E973(FName NotifyName);
    void OnBlendOut_89540A1C43B8A68891FE17ABA988E973(FName NotifyName);
    void OnCompleted_89540A1C43B8A68891FE17ABA988E973(FName NotifyName);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void ReceivePossessed(class AController* NewController);
    void ServiceStart();
    void ReceiveTick(float DeltaSeconds);
    void OpenDoor(class UObject* Target);
    void DoorMulti(class UObject* Target);
    void DoorServer(class UObject* Target);
    void AttackServer();
    void AttackMulti(double Chance);
    void DeSpawnServer();
    void DespawnMulti();
    void ReceiveBeginPlay();
    void Flamethrower();
    void Death();
    void BndEvt__MadPatent_AI_PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void SeePlayer(class ABP_FirstPersonCharacter_C* Character);
    void SeePlayerMulti(class ABP_FirstPersonCharacter_C* FoundPlayer);
    void BndEvt__MadPatent_AI_PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature(class APawn* Instigator, const FVector& Location, float Volume);
    void HeardNoise(FVector Location);
    void InfectPlayer(class ABP_FirstPersonCharacter_C* Character);
    void InfectPlayerAll(class ABP_FirstPersonCharacter_C* Character);
    void DeathServer(FVector Location, FName BoneName, FVector Normal, bool IsSniper);
    void DeathSkip(FName Bone Name, FVector Location, int32 Hits, FVector Normal, bool Sniper);
    void FlareGun();
    void UpdateDamage();
    void UpdateAttackMusic();
    void AttackDog();
    void MoveToGenerator(class ABP_GeneratorGameplayNew_C* Generator, bool MoveTo?);
    void DestroyGen();
    void PlayMontageALL();
    void PlayMontageServer();
    void CheckForGenerator();
    void PlaySpawnAnimation();
    void PlaySpawnAnimationServer();
    void RPCSpawnAnimation();
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void ExecuteUbergraph_MadPatent_AI(int32 EntryPoint);
}; // Size: 0x7F3

#endif
