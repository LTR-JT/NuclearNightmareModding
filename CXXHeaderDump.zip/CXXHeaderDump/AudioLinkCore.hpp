#ifndef UE4SS_SDK_AudioLinkCore_HPP
#define UE4SS_SDK_AudioLinkCore_HPP

class UAudioLinkSettingsAbstract : public UObject
{
    char padding_0[0x38];                                                             // 0x0000 (size: 0x0)
}; // Size: 0x38

#endif
