#ifndef UE4SS_SDK_AudioLinkCore_HPP
#define UE4SS_SDK_AudioLinkCore_HPP

class UAudioLinkSettingsAbstract : public UObject
{
}; // Size: 0x38

#endif
