#ifndef UE4SS_SDK_BP_Medical_Cart_7_HPP
#define UE4SS_SDK_BP_Medical_Cart_7_HPP

class ABP_Medical_Cart_7_C : public AActor
{
    class UStaticMeshComponent* SM_Medical_Cart_7_cloth;                              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_4;                                      // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_3;                                      // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_2;                                      // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_1;                                      // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Wheel_1;                                              // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Wheel_2;                                              // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Medical_Cart_7_body;                               // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Wheel_4;                                              // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Wheel_3;                                              // 0x02D8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E0 (size: 0x8)
    bool ? Hide\Unhide Cloth;                                                         // 0x02E8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02E9 (size: 0x7)
    double Wheel_element_1_Rotate;                                                    // 0x02F0 (size: 0x8)
    double Wheel_element_2_Rotate;                                                    // 0x02F8 (size: 0x8)
    double Wheel_element_3_Rotate;                                                    // 0x0300 (size: 0x8)
    double Wheel_element_4_Rotate;                                                    // 0x0308 (size: 0x8)

    void Rotate Z(double Z (Yaw), bool Invert Z, class USceneComponent* TargetMesh);
    void UserConstructionScript();
}; // Size: 0x310

#endif
