#ifndef UE4SS_SDK_MapWidget_HPP
#define UE4SS_SDK_MapWidget_HPP

class UMapWidget_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* Todo;                                                     // 0x02E8 (size: 0x8)
    class UBorder* Border_4;                                                          // 0x02F0 (size: 0x8)
    class UClassifiedMaterial_C* ClassifiedMaterial;                                  // 0x02F8 (size: 0x8)
    class UButton* Create_3;                                                          // 0x0300 (size: 0x8)
    class UFlareUI_C* FlareUI;                                                        // 0x0308 (size: 0x8)
    class UScrollBox* GraphicsScroll;                                                 // 0x0310 (size: 0x8)
    class UHelicopterUI_C* HelicopterUI;                                              // 0x0318 (size: 0x8)
    class UHuskyUI_C* HuskyUI;                                                        // 0x0320 (size: 0x8)
    class UImage* Image;                                                              // 0x0328 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0330 (size: 0x8)
    class UImage* Image_1;                                                            // 0x0338 (size: 0x8)
    class UImage* Image_2;                                                            // 0x0340 (size: 0x8)
    class UImage* Image_3;                                                            // 0x0348 (size: 0x8)
    class UImage* Image_61;                                                           // 0x0350 (size: 0x8)
    class UImage* Image_89;                                                           // 0x0358 (size: 0x8)
    class UImage* Image_92;                                                           // 0x0360 (size: 0x8)
    class UImage* Image_106;                                                          // 0x0368 (size: 0x8)
    class ULevelLocationUI_C* LevelLocationUI;                                        // 0x0370 (size: 0x8)
    class UMapUI_C* MapUI;                                                            // 0x0378 (size: 0x8)
    class UProgressBar* ProgressBar_0;                                                // 0x0380 (size: 0x8)
    class URetainerBox* RetainerBox_76;                                               // 0x0388 (size: 0x8)
    class USateliteUI_C* SateliteUI;                                                  // 0x0390 (size: 0x8)
    class UStackBox* StackBox_0;                                                      // 0x0398 (size: 0x8)
    class UTextBlock* TextBlock;                                                      // 0x03A0 (size: 0x8)
    class UTextBlock* TextBlock_4;                                                    // 0x03A8 (size: 0x8)
    class UTextBlock* TextBlock_47;                                                   // 0x03B0 (size: 0x8)
    class UTextBlock* TextBlock_49;                                                   // 0x03B8 (size: 0x8)
    class UTextBlock* TextBlock_51;                                                   // 0x03C0 (size: 0x8)
    class UTextBlock* TextBlock_53;                                                   // 0x03C8 (size: 0x8)
    class UTextBlock* TextBlock_86;                                                   // 0x03D0 (size: 0x8)
    class UVerticalBox* VerticalBox_1;                                                // 0x03D8 (size: 0x8)
    class UVerticalBox* VerticalBox_2;                                                // 0x03E0 (size: 0x8)
    class UVerticalBox* VerticalBox_11;                                               // 0x03E8 (size: 0x8)
    class UWaypoint_C* Waypoint;                                                      // 0x03F0 (size: 0x8)
    FMapWidget_CClickBack ClickBack;                                                  // 0x03F8 (size: 0x10)
    void ClickBack();
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0408 (size: 0x8)
    FMapWidget_CInitalizeCharacter InitalizeCharacter;                                // 0x0410 (size: 0x10)
    void InitalizeCharacter(class ABP_FirstPersonCharacter_C* Character);
    int32 Length;                                                                     // 0x0420 (size: 0x4)
    bool HoldingLeftDown;                                                             // 0x0424 (size: 0x1)
    class AUltra_Dynamic_Sky_C* DynamicSky;                                           // 0x0428 (size: 0x8)

    void ReorderObjectivesByClosest(TArray<class AObjectiveManager_C*>& Objective Manager Array, TArray<class AObjectiveManager_C*>& New Array);
    FSlateColor GetColorAndOpacity_2();
    FText GetText_8();
    FSlateColor GetColorAndOpacity_1();
    FText GetText_7();
    FSlateColor GetColorAndOpacity_0();
    FText GetText_6();
    FSlateColor GetColorAndOpacity();
    FText GetText_5();
    ECheckBoxState GetCheckedState_15();
    ECheckBoxState GetCheckedState_14();
    ECheckBoxState GetCheckedState_13();
    ECheckBoxState GetCheckedState_12();
    ECheckBoxState GetCheckedState_11();
    ECheckBoxState GetCheckedState_10();
    float GetPercent_2();
    FText GetText_4();
    ECheckBoxState GetCheckedState_9();
    ECheckBoxState GetCheckedState_8();
    ECheckBoxState GetCheckedState_7();
    float GetPercent_1();
    FText GetText_3();
    FText GetText_2();
    float GetPercent_0();
    ECheckBoxState GetCheckedState_6();
    ECheckBoxState GetCheckedState_5();
    ECheckBoxState GetCheckedState_4();
    ECheckBoxState GetCheckedState_3();
    ECheckBoxState GetCheckedState_2();
    ECheckBoxState GetCheckedState_1();
    ECheckBoxState GetCheckedState_0();
    ECheckBoxState GetCheckedState();
    FText GetText_1();
    FText GetText_0();
    FEventReply OnMouseButtonUp(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FEventReply OnMouseButtonDown(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FEventReply OnMouseMove(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FEventReply OnMouseWheel(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    float GetPercent();
    FText GetText();
    void Initalize(class ABP_FirstPersonCharacter_C* Character);
    void Construct();
    void BndEvt__MapWidget_Create_3_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_MapWidget(int32 EntryPoint);
    void InitalizeCharacter__DelegateSignature(class ABP_FirstPersonCharacter_C* Character);
    void ClickBack__DelegateSignature();
}; // Size: 0x430

#endif
