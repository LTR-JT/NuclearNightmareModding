namespace Enum_Headers {
    enum Type {
        NewEnumerator5 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator3 = 4,
        NewEnumerator4 = 5,
        Enum_MAX = 6,
    };
}

