#ifndef UE4SS_SDK_Item_GasCanster_HPP
#define UE4SS_SDK_Item_GasCanster_HPP

class AItem_GasCanster_C : public AItemActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E8 (size: 0x8)
    class USphereComponent* ExplosionRadius;                                          // 0x02F0 (size: 0x8)
    class URadialForceComponent* RadialForce;                                         // 0x02F8 (size: 0x8)
    double Fuel;                                                                      // 0x0300 (size: 0x8)

    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void BPOnEquip(class ANuclearNightmareCharacter* Character);
    void BPOnUnEquip(class ANuclearNightmareCharacter* Character);
    void Explode();
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void ExecuteUbergraph_Item_GasCanster(int32 EntryPoint);
}; // Size: 0x308

#endif
