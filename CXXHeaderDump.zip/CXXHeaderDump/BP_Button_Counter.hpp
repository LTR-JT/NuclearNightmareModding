#ifndef UE4SS_SDK_BP_Button_Counter_HPP
#define UE4SS_SDK_BP_Button_Counter_HPP

class ABP_Button_Counter_C : public AActor
{
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0290 (size: 0x8)
    class UMaterialInstanceDynamic* ButtonMID;                                        // 0x0298 (size: 0x8)
    class ATextRenderActor* Text Counter;                                             // 0x02A0 (size: 0x8)
    class ABP_Graph_C* Graph;                                                         // 0x02A8 (size: 0x8)
    double Increment;                                                                 // 0x02B0 (size: 0x8)
    bool Defines X;                                                                   // 0x02B8 (size: 0x1)
    bool Defines Max;                                                                 // 0x02B9 (size: 0x1)
    char padding_0[0x6];                                                              // 0x02BA (size: 0x6)
    double CurrentValue;                                                              // 0x02C0 (size: 0x8)

    void ToggleButton();
    void UserConstructionScript();
}; // Size: 0x2C8

#endif
