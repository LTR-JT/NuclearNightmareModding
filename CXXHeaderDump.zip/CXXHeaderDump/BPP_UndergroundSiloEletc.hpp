#ifndef UE4SS_SDK_BPP_UndergroundSiloEletc_HPP
#define UE4SS_SDK_BPP_UndergroundSiloEletc_HPP

class ABPP_UndergroundSiloEletc_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh14;                       // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh13;                       // 0x0338 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh12;                       // 0x0340 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh11;                       // 0x0348 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh10;                       // 0x0350 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh9;                        // 0x0358 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh8;                        // 0x0360 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh7;                        // 0x0368 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh6;                        // 0x0370 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh5;                        // 0x0378 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh4;                        // 0x0380 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh3;                        // 0x0388 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh2;                        // 0x0390 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh1;                        // 0x0398 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x03A0 (size: 0x8)

}; // Size: 0x3A8

#endif
