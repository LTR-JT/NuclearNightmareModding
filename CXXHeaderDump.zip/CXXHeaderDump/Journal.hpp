#ifndef UE4SS_SDK_Journal_HPP
#define UE4SS_SDK_Journal_HPP

class UJournal_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UBackgroundBlur* BackgroundBlur_50;                                         // 0x02F0 (size: 0x8)
    class UMapWidget_C* MapWidget;                                                    // 0x02F8 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_0;                                          // 0x0300 (size: 0x8)
    class APlayerController* Controller;                                              // 0x0308 (size: 0x8)
    bool OpenWithMap;                                                                 // 0x0310 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0318 (size: 0x8)

    FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent);
    void Construct();
    void ExecuteUbergraph_Journal(int32 EntryPoint);
}; // Size: 0x320

#endif
