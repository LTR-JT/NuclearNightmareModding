#ifndef UE4SS_SDK_MapUI_HPP
#define UE4SS_SDK_MapUI_HPP

class UMapUI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UTextBlock* AddMinus;                                                       // 0x02E8 (size: 0x8)
    class UTextBlock* AddMinus_1;                                                     // 0x02F0 (size: 0x8)
    class UButton* Button_0;                                                          // 0x02F8 (size: 0x8)
    class UCanvasPanel* CanvasPanel_15;                                               // 0x0300 (size: 0x8)
    class UCanvasPanel* CanvasPanel_52;                                               // 0x0308 (size: 0x8)
    class UHorizontalBox* HorizontalBox_0;                                            // 0x0310 (size: 0x8)
    class UImage* Image;                                                              // 0x0318 (size: 0x8)
    class UImage* Image_51;                                                           // 0x0320 (size: 0x8)
    class UImage* Image_119;                                                          // 0x0328 (size: 0x8)
    class UTextBlock* TextBlock_41;                                                   // 0x0330 (size: 0x8)
    class UWaypoint_C* Waypoint;                                                      // 0x0338 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0340 (size: 0x8)
    FMapUI_CInitalize Initalize;                                                      // 0x0348 (size: 0x10)
    void Initalize(class ABP_FirstPersonCharacter_C* Character);
    FVector2D WaypointLocation;                                                       // 0x0358 (size: 0x10)
    bool WaypointPlaced;                                                              // 0x0368 (size: 0x1)
    class AWaypointActor_C* WaypointActor;                                            // 0x0370 (size: 0x8)
    double X;                                                                         // 0x0378 (size: 0x8)
    double Y;                                                                         // 0x0380 (size: 0x8)
    bool Hovering;                                                                    // 0x0388 (size: 0x1)
    double Scale X;                                                                   // 0x0390 (size: 0x8)
    double Scale Y;                                                                   // 0x0398 (size: 0x8)
    float Wheel;                                                                      // 0x03A0 (size: 0x4)
    FVector2D Translation;                                                            // 0x03A8 (size: 0x10)
    FVector2D CursorTranslation;                                                      // 0x03B8 (size: 0x10)
    bool HoldingLeftDown;                                                             // 0x03C8 (size: 0x1)
    FGeometry My Geometry;                                                            // 0x03CC (size: 0x38)
    FPointerEvent Mouse Event;                                                        // 0x0408 (size: 0x78)
    TArray<class UClassifiedMaterial_C*> Classified;                                  // 0x0480 (size: 0x10)
    TArray<class UFlareUI_C*> Flares;                                                 // 0x0490 (size: 0x10)
    class USateliteUI_C* Satelite;                                                    // 0x04A0 (size: 0x8)
    TArray<class ULevelLocationUI_C*> Levels;                                         // 0x04A8 (size: 0x10)
    class UHelicopterWaypointUI_C* HeliRadius;                                        // 0x04B8 (size: 0x8)
    class UHelicopterUI_C* HeliLocation;                                              // 0x04C0 (size: 0x8)
    TArray<class ULevelLocationName_C*> Levels_0;                                     // 0x04C8 (size: 0x10)
    TArray<class UPlayerUI_C*> AllPlayers;                                            // 0x04D8 (size: 0x10)
    TArray<class ABP_FirstPersonCharacter_C*> AssioatedPlayer;                        // 0x04E8 (size: 0x10)
    TArray<class AHusky_AI_C*> TamedHuskies;                                          // 0x04F8 (size: 0x10)
    TArray<class UHuskyUI_C*> HuskyUI;                                                // 0x0508 (size: 0x10)

    FEventReply OnMouseButtonUp(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FEventReply OnMouseButtonDown(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FEventReply OnMouseMove(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    FText GetText();
    void Construct();
    void InitalizeCharacter(class ABP_FirstPersonCharacter_C* Character);
    void Tick(FGeometry MyGeometry, float InDeltaTime);
    void BndEvt__MapUI_Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__MapUI_Button_0_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();
    void BndEvt__MapUI_Button_0_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature();
    void SpawnWaypoint(class ABP_FirstPersonCharacter_C* Char, FVector Location);
    void SpawnWaypointMulti(class ABP_FirstPersonCharacter_C* Char, FVector Location);
    void UpdateMapZoom(double Axis);
    void UpdateMapMove(FVector2D Vector);
    void OnFocusLost(FFocusEvent InFocusEvent);
    void OnMouseLeave(const FPointerEvent& MouseEvent);
    void ExecuteUbergraph_MapUI(int32 EntryPoint);
    void Initalize__DelegateSignature(class ABP_FirstPersonCharacter_C* Character);
}; // Size: 0x518

#endif
