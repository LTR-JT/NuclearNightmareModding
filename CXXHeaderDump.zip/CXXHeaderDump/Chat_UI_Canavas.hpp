#ifndef UE4SS_SDK_Chat_UI_Canavas_HPP
#define UE4SS_SDK_Chat_UI_Canavas_HPP

class UChat_UI_Canavas_C : public UUserWidget
{
    class UGlobalChat_C* GlobalChat;                                                  // 0x02E0 (size: 0x8)

}; // Size: 0x2E8

#endif
