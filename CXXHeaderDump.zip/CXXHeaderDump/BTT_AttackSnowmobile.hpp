#ifndef UE4SS_SDK_BTT_AttackSnowmobile_HPP
#define UE4SS_SDK_BTT_AttackSnowmobile_HPP

class UBTT_AttackSnowmobile_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Driver Character;                               // 0x00B0 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_AttackSnowmobile(int32 EntryPoint);
}; // Size: 0xB8

#endif
