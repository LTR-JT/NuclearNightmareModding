#ifndef UE4SS_SDK_DoorNuclear_HPP
#define UE4SS_SDK_DoorNuclear_HPP

class ADoorNuclear_C : public ABP_Door_Base_C
{
    char padding_0[0x314];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x314

#endif
