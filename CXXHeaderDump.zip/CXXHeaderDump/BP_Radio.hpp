#ifndef UE4SS_SDK_BP_Radio_HPP
#define UE4SS_SDK_BP_Radio_HPP

class ABP_Radio_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0298 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* MilitaryComputer;                                     // 0x02A8 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x02B0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02C0 (size: 0x8)
    FString Location Name;                                                            // 0x02C8 (size: 0x10)
    FVector HelicopterLocation;                                                       // 0x02D8 (size: 0x18)
    bool Interacting;                                                                 // 0x02F0 (size: 0x1)
    bool PoweredOn?;                                                                  // 0x02F1 (size: 0x1)
    char padding_0[0x6];                                                              // 0x02F2 (size: 0x6)
    class APlayerStart* ReinformantLocation;                                          // 0x02F8 (size: 0x8)
    int32 AmountShared;                                                               // 0x0300 (size: 0x4)

    void PassiveInteraction(FText& ActorName);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void SpawnObjectiveHud(bool Won);
    void HeliEventALL(class ABP_FirstPersonCharacter_C* Character, bool Response);
    void HeliEventServer(class ABP_FirstPersonCharacter_C* Character, bool Response);
    void PlayerResponse(bool Yes?);
    void Close();
    void ExitComputerALL();
    void eXITcOMPUTERsERVER();
    void Manual Exit();
    void ToggleEquipment(bool Power);
    void Reinformant();
    void SpawnReinformant();
    void SpawnReinformantRPC(class AController* Controller, class ABP_FirstPersonCharacter_C* Character);
    void SpawnReinforcementMethod2(int32 PlayerIndex);
    void RPCReinforcementMethod2(class ABP_FirstPersonCharacter_C* SpawnedCharacter, class ABP_FirstPersonCharacter_C* OldCharacter, class AController* Controller, int32 TimesReinforced, int32 Classified, class APawn* ControlledPawn);
    void SpawnHeliRadius();
    void SpawnHeliRadiusOnServer(FVector Location);
    void SpawnHeliRadiusAll(FVector Location);
    void SendGameStateEvent();
    void Reinforced(class ABP_FirstPersonCharacter_C* Character);
    void ReinforceSpecficPlayer(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_BP_Radio(int32 EntryPoint);
}; // Size: 0x304

#endif
