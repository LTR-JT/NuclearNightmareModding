#ifndef UE4SS_SDK_FolderTemplate_HPP
#define UE4SS_SDK_FolderTemplate_HPP

class UFolderTemplate_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_58;                                                         // 0x02E8 (size: 0x8)
    class UImage* Image_24;                                                           // 0x02F0 (size: 0x8)
    class UImage* Image_61;                                                           // 0x02F8 (size: 0x8)
    class UTextBlock* TextBlock_79;                                                   // 0x0300 (size: 0x8)
    class UObject* Image;                                                             // 0x0308 (size: 0x8)
    FText Folder Name;                                                                // 0x0310 (size: 0x10)
    FFolderTemplate_CExit Exit;                                                       // 0x0320 (size: 0x10)
    void Exit();

    FText GetText();
    FSlateBrush GetBrush();
    void BndEvt__FolderTemplate_Button_58_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_FolderTemplate(int32 EntryPoint);
    void Exit__DelegateSignature();
}; // Size: 0x330

#endif
