#ifndef UE4SS_SDK_BP_HexTree_GameMode_HPP
#define UE4SS_SDK_BP_HexTree_GameMode_HPP

class ABP_HexTree_GameMode_C : public AGameMode
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0370 (size: 0x8)

}; // Size: 0x378

#endif
