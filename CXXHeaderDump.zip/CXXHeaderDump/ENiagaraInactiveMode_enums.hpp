namespace ENiagaraInactiveMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraInactiveMode_MAX = 3,
    };
}

