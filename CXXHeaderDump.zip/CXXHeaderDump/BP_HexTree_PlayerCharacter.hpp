#ifndef UE4SS_SDK_BP_HexTree_PlayerCharacter_HPP
#define UE4SS_SDK_BP_HexTree_PlayerCharacter_HPP

class ABP_HexTree_PlayerCharacter_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UBP_HexTree_AC_C* BPAC_HexTree;                                             // 0x0678 (size: 0x8)
    class UCameraComponent* FirstPersonCamera;                                        // 0x0680 (size: 0x8)
    float ForwardAxis;                                                                // 0x0688 (size: 0x4)
    float RightAxis;                                                                  // 0x068C (size: 0x4)
    double Damage;                                                                    // 0x0690 (size: 0x8)
    double Stamina;                                                                   // 0x0698 (size: 0x8)
    double Health;                                                                    // 0x06A0 (size: 0x8)
    class UW_Example_C* W_Example;                                                    // 0x06A8 (size: 0x8)
    double MaxStamina;                                                                // 0x06B0 (size: 0x8)
    double StaminaConsumption;                                                        // 0x06B8 (size: 0x8)
    bool WalkAcceleration;                                                            // 0x06C0 (size: 0x1)

    void FUpdateWidget();
    void FStaminaTimer();
    void FApplyHexTree(TEnumAsByte<EHex::Type> EHex);
    void InpActEvt_I_K2Node_InputKeyEvent_14(FKey Key);
    void InpActEvt_O_K2Node_InputKeyEvent_13(FKey Key);
    void InpActEvt_P_K2Node_InputKeyEvent_12(FKey Key);
    void InpActEvt_D_K2Node_InputKeyEvent_11(FKey Key);
    void InpActEvt_D_K2Node_InputKeyEvent_10(FKey Key);
    void InpActEvt_A_K2Node_InputKeyEvent_9(FKey Key);
    void InpActEvt_A_K2Node_InputKeyEvent_8(FKey Key);
    void InpActEvt_S_K2Node_InputKeyEvent_7(FKey Key);
    void InpActEvt_S_K2Node_InputKeyEvent_6(FKey Key);
    void InpActEvt_SpaceBar_K2Node_InputKeyEvent_5(FKey Key);
    void InpActEvt_SpaceBar_K2Node_InputKeyEvent_4(FKey Key);
    void InpActEvt_W_K2Node_InputKeyEvent_3(FKey Key);
    void InpActEvt_W_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_LeftShift_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_LeftShift_K2Node_InputKeyEvent_0(FKey Key);
    void BndEvt__BP_HexTree_PlayerCharacter_BPAC_HexTree_K2Node_ComponentBoundEvent_2_OnHexPurchased__DelegateSignature(TEnumAsByte<EHex::Type> Hex);
    void BndEvt__BP_HexTree_PlayerCharacter_BPAC_HexTree_K2Node_ComponentBoundEvent_3_OnHexTreeInit__DelegateSignature(TArray<FSHex>& AllValues);
    void StopAcceleration();
    void Client_UpdateWidget();
    void Client_AddWidget();
    void Client_ApplyHexTree(TEnumAsByte<EHex::Type> EHex);
    void Server_Jump();
    void Client_Jump();
    void Server_Acceleration(bool WalkAcceleration);
    void Client_Acceleration(bool WalkAcceleration);
    void InpAxisKeyEvt_MouseY_K2Node_InputAxisKeyEvent_1(float AxisValue);
    void InpAxisKeyEvt_MouseX_K2Node_InputAxisKeyEvent_0(float AxisValue);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_HexTree_PlayerCharacter(int32 EntryPoint);
}; // Size: 0x6C1

#endif
