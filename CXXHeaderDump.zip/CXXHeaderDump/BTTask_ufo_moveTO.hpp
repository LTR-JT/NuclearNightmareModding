#ifndef UE4SS_SDK_BTTask_ufo_moveTO_HPP
#define UE4SS_SDK_BTTask_ufo_moveTO_HPP

class UBTTask_ufo_moveTO_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector MoveToLocation;                                            // 0x00B0 (size: 0x28)
    FBlackboardKeySelector Is Moving;                                                 // 0x00D8 (size: 0x28)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_ufo_moveTO(int32 EntryPoint);
}; // Size: 0x100

#endif
