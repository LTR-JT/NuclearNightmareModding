#ifndef UE4SS_SDK_FTwinSliderControls_HPP
#define UE4SS_SDK_FTwinSliderControls_HPP

struct FFTwinSliderControls
{
    int32 Priority_24_63C2F5F846CE52CCA37D0D92983FC3B2;                               // 0x0000 (size: 0x4)
    FString Label_2_58F367ED41E6F6F389B8F2895C4D806A;                                 // 0x0008 (size: 0x10)
    float Default_5_B88F3B3E48B114680562BBB89555AD2D;                                 // 0x0018 (size: 0x4)
    float FirstMin_12_2709555A47E4DB5015F9A18BD80F03FE;                               // 0x001C (size: 0x4)
    float FirstMax_13_9EF5F355484139B8FDA52EB95295A8BD;                               // 0x0020 (size: 0x4)
    float SecondMin_19_37EE033A4236D7E511AF359688B04E31;                              // 0x0024 (size: 0x4)
    float SecondMax_20_118EF46443F5609908DBA1B709149967;                              // 0x0028 (size: 0x4)

}; // Size: 0x2C

#endif
