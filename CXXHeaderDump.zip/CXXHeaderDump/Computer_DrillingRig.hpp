#ifndef UE4SS_SDK_Computer_DrillingRig_HPP
#define UE4SS_SDK_Computer_DrillingRig_HPP

class UComputer_DrillingRig_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UButton* Button_65;                                                         // 0x02F0 (size: 0x8)
    class UButton* Button_233;                                                        // 0x02F8 (size: 0x8)
    class UCircularThrobber* CircularThrobber_36;                                     // 0x0300 (size: 0x8)
    class UWidgetSwitcher* Drill1Switcher;                                            // 0x0308 (size: 0x8)
    class UWidgetSwitcher* Drill2Switcher;                                            // 0x0310 (size: 0x8)
    class UDrillingRigContent_C* DrillingRigContent;                                  // 0x0318 (size: 0x8)
    class UFolderTemplate_C* FolderTemplate;                                          // 0x0320 (size: 0x8)
    class UFolderTemplate_C* FolderTemplate_184;                                      // 0x0328 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0330 (size: 0x8)
    class UOverlay* Overlay_3;                                                        // 0x0338 (size: 0x8)
    class UOverlay* Overlay_180;                                                      // 0x0340 (size: 0x8)
    class UTextBlock* TextBlock_64;                                                   // 0x0348 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_1;                                          // 0x0350 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_2;                                          // 0x0358 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_59;                                         // 0x0360 (size: 0x8)
    class AUltra_Dynamic_Sky_C* Sky;                                                  // 0x0368 (size: 0x8)
    FComputer_DrillingRig_CCloseComputer CloseComputer;                               // 0x0370 (size: 0x10)
    void CloseComputer();
    bool StartUpload;                                                                 // 0x0380 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0381 (size: 0x7)
    FComputer_DrillingRig_CCollectedClassified CollectedClassified;                   // 0x0388 (size: 0x10)
    void CollectedClassified();
    bool Reported;                                                                    // 0x0398 (size: 0x1)

    FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent);
    FText GetText();
    void Construct();
    void SateliteON();
    void BndEvt__Computer_OS_Main_Button_65_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void EndComputer();
    void ShowFolder();
    void BndEvt__Computer_OS_Main_FolderTemplate_K2Node_ComponentBoundEvent_1_Exit__DelegateSignature();
    void CustomEvent();
    void BndEvt__Computer_DrillingRig_DrillingRigContent_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature();
    void BndEvt__Computer_DrillingRig_Button_233_K2Node_ComponentBoundEvent_11_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__Computer_DrillingRig_FolderTemplate_184_K2Node_ComponentBoundEvent_3_Exit__DelegateSignature();
    void Drill1();
    void Drill2();
    void BndEvt__Computer_DrillingRig_Button_233_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature();
    void ExecuteUbergraph_Computer_DrillingRig(int32 EntryPoint);
    void CollectedClassified__DelegateSignature();
    void CloseComputer__DelegateSignature();
}; // Size: 0x399

#endif
