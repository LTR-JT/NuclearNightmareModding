#ifndef UE4SS_SDK_BP_Water_HPP
#define UE4SS_SDK_BP_Water_HPP

class ABP_Water_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* WaterPlane;                                           // 0x0298 (size: 0x8)
    class UMaterialInstanceDynamic* Water Material;                                   // 0x02A0 (size: 0x8)
    FVector Volume Extent;                                                            // 0x02A8 (size: 0x18)
    double Shore Depth;                                                               // 0x02C0 (size: 0x8)
    double Wave Speed;                                                                // 0x02C8 (size: 0x8)
    double Base Opacity;                                                              // 0x02D0 (size: 0x8)
    double Water Scale;                                                               // 0x02D8 (size: 0x8)
    double Variation Ammount;                                                         // 0x02E0 (size: 0x8)
    double Water Depth;                                                               // 0x02E8 (size: 0x8)
    FLinearColor Water Color A;                                                       // 0x02F0 (size: 0x10)
    FLinearColor Water Color B;                                                       // 0x0300 (size: 0x10)
    FLinearColor Water Color Deep;                                                    // 0x0310 (size: 0x10)
    FLinearColor Water Color Shallow;                                                 // 0x0320 (size: 0x10)
    TArray<class AActor*> Overlaping Actors;                                          // 0x0330 (size: 0x10)

    void UserConstructionScript();
    void OnNotifyEnd_2A415DC74F0C432DDCD421BEA4A75DB6(FName NotifyName);
    void OnNotifyBegin_2A415DC74F0C432DDCD421BEA4A75DB6(FName NotifyName);
    void OnInterrupted_2A415DC74F0C432DDCD421BEA4A75DB6(FName NotifyName);
    void OnBlendOut_2A415DC74F0C432DDCD421BEA4A75DB6(FName NotifyName);
    void OnCompleted_2A415DC74F0C432DDCD421BEA4A75DB6(FName NotifyName);
    void OnNotifyEnd_C73C7667457FBFBAC9452DAB81A3DE6E(FName NotifyName);
    void OnNotifyBegin_C73C7667457FBFBAC9452DAB81A3DE6E(FName NotifyName);
    void OnInterrupted_C73C7667457FBFBAC9452DAB81A3DE6E(FName NotifyName);
    void OnBlendOut_C73C7667457FBFBAC9452DAB81A3DE6E(FName NotifyName);
    void OnCompleted_C73C7667457FBFBAC9452DAB81A3DE6E(FName NotifyName);
    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void BndEvt__BP_Water_WaterPlane_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void DrownOnServer(class ABP_FirstPersonCharacter_C* Character);
    void DrownMulti(class ABP_FirstPersonCharacter_C* Character);
    void DrownOnOwningClient(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_BP_Water(int32 EntryPoint);
}; // Size: 0x340

#endif
