#ifndef UE4SS_SDK_BTTIsGenCloserSCP_HPP
#define UE4SS_SDK_BTTIsGenCloserSCP_HPP

class UBTTIsGenCloserSCP_C : public UBTDecorator_BlueprintBase
{
    char padding_0[0xA0];                                                             // 0x0000 (size: 0x0)

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
