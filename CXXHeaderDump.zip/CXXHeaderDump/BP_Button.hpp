#ifndef UE4SS_SDK_BP_Button_HPP
#define UE4SS_SDK_BP_Button_HPP

class ABP_Button_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBoxComponent* Trigger;                                                     // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Button base;                                          // 0x02A0 (size: 0x8)
    class USceneComponent* base;                                                      // 0x02A8 (size: 0x8)
    float Press_Glow_37C89A5243205ED7DCF3D6962FB93D0A;                                // 0x02B0 (size: 0x4)
    float Press_Press_37C89A5243205ED7DCF3D6962FB93D0A;                               // 0x02B4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Press__Direction_37C89A5243205ED7DCF3D6962FB93D0A; // 0x02B8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02B9 (size: 0x7)
    class UTimelineComponent* Press;                                                  // 0x02C0 (size: 0x8)
    class UMaterialInstanceDynamic* Button material;                                  // 0x02C8 (size: 0x8)
    class AActor* Target Blueprint;                                                   // 0x02D0 (size: 0x8)

    void UserConstructionScript();
    void Press__FinishedFunc();
    void Press__UpdateFunc();
    void BndEvt__Trigger_K2Node_ComponentBoundEvent_87_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Trigger_K2Node_ComponentBoundEvent_101_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_BP_Button(int32 EntryPoint);
}; // Size: 0x2D8

#endif
