namespace EMusicState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EMusicState_MAX = 3,
    };
}

