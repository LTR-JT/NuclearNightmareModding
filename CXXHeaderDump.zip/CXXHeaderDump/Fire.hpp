#ifndef UE4SS_SDK_Fire_HPP
#define UE4SS_SDK_Fire_HPP

class AFire_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0298 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x02A0 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    bool TriedToStop;                                                                 // 0x02B8 (size: 0x1)
    bool IsFirePropagation;                                                           // 0x02B9 (size: 0x1)

    void ReceiveBeginPlay();
    void BndEvt__Fire_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Fire_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_Fire(int32 EntryPoint);
}; // Size: 0x2BA

#endif
