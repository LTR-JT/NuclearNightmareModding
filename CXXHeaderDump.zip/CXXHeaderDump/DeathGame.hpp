#ifndef UE4SS_SDK_DeathGame_HPP
#define UE4SS_SDK_DeathGame_HPP

class UDeathGame_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UModular_ObjectiveComplete_C* Modular_ObjectiveComplete;                    // 0x02E8 (size: 0x8)
    class UObject* Avatar;                                                            // 0x02F0 (size: 0x8)
    FString UserName;                                                                 // 0x02F8 (size: 0x10)
    FString Location;                                                                 // 0x0308 (size: 0x10)

    void Construct();
    void ExecuteUbergraph_DeathGame(int32 EntryPoint);
}; // Size: 0x318

#endif
