#ifndef UE4SS_SDK_EndGameUI_HPP
#define UE4SS_SDK_EndGameUI_HPP

class UEndGameUI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UClassifiedCollected_C* ClassifiedCollected;                                // 0x02E8 (size: 0x8)
    class UEndGameState_C* EndGameState;                                              // 0x02F0 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F8 (size: 0x8)
    class UVerticalBox* VerticalBox;                                                  // 0x0300 (size: 0x8)
    class UVerticalBox* VerticalBox_0;                                                // 0x0308 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> Array;                                  // 0x0310 (size: 0x10)
    FEndGameUI_CResponse? Response?;                                                  // 0x0320 (size: 0x10)
    void Response?(bool Retry?);

    void Construct();
    void Retry();
    void BackToMenu();
    void ExecuteUbergraph_EndGameUI(int32 EntryPoint);
    void Response?__DelegateSignature(bool Retry?);
}; // Size: 0x330

#endif
