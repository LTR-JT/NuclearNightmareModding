#ifndef UE4SS_SDK_CallHeliObjective_HPP
#define UE4SS_SDK_CallHeliObjective_HPP

class UCallHeliObjective_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UModular_ObjectiveComplete4_C* Modular_ObjectiveComplete4;                  // 0x02F0 (size: 0x8)

    void Construct();
    void ExecuteUbergraph_CallHeliObjective(int32 EntryPoint);
}; // Size: 0x2F8

#endif
