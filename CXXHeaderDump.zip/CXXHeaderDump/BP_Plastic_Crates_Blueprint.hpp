#ifndef UE4SS_SDK_BP_Plastic_Crates_Blueprint_HPP
#define UE4SS_SDK_BP_Plastic_Crates_Blueprint_HPP

class ABP_Plastic_Crates_Blueprint_C : public AActor
{
    class UStaticMeshComponent* StaticMeshComponent012;                               // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent011;                               // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent010;                               // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent09;                                // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent08;                                // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent07;                                // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent06;                                // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent05;                                // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent04;                                // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent03;                                // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent02;                                // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent01;                                // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent0;                                 // 0x02F0 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x02F8 (size: 0x8)

}; // Size: 0x300

#endif
