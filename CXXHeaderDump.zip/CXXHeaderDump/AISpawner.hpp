#ifndef UE4SS_SDK_AISpawner_HPP
#define UE4SS_SDK_AISpawner_HPP

class AAISpawner_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    TArray<class ABP_FirstPersonCharacter_C*> Players;                                // 0x02A0 (size: 0x10)
    TArray<class ABP_Snowmobile_C*> Snowmobile;                                       // 0x02B0 (size: 0x10)
    TArray<class AActor*> Actors to Ignore;                                           // 0x02C0 (size: 0x10)
    FVector SpawnLocation;                                                            // 0x02D0 (size: 0x18)
    bool CanSpawn;                                                                    // 0x02E8 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Player;                                         // 0x02F0 (size: 0x8)
    bool RandomBool;                                                                  // 0x02F8 (size: 0x1)
    int32 LastType;                                                                   // 0x02FC (size: 0x4)
    int32 CurrentType;                                                                // 0x0300 (size: 0x4)
    float LobbyDuration;                                                              // 0x0304 (size: 0x4)
    class AUltra_Dynamic_Sky_C* DynamicSky;                                           // 0x0308 (size: 0x8)
    int32 NumOfTimesAttempted;                                                        // 0x0310 (size: 0x4)
    bool CurrentlySpawning?;                                                          // 0x0314 (size: 0x1)

    void SpawnEnemies();
    void SpawnEnemiesMulti(bool enemybool, int32 Type, bool giantbool, int32 FastLearnerType);
    void SpawnWorm(FVector Location);
    void SpawnWormMulti(FVector Location);
    void DayReached();
    void SendDayMessage(int32 Days);
    void ExecuteUbergraph_AISpawner(int32 EntryPoint);
}; // Size: 0x315

#endif
