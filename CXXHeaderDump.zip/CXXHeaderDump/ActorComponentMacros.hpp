#ifndef UE4SS_SDK_ActorComponentMacros_HPP
#define UE4SS_SDK_ActorComponentMacros_HPP

class UActorComponentMacros_C : public UActorComponent
{
    char padding_0[0xA0];                                                             // 0x0000 (size: 0x0)
}; // Size: 0xA0

#endif
