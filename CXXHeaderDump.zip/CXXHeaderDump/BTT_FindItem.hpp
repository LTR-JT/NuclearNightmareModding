#ifndef UE4SS_SDK_BTT_FindItem_HPP
#define UE4SS_SDK_BTT_FindItem_HPP

class UBTT_FindItem_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    double Max;                                                                       // 0x00B0 (size: 0x8)
    FBlackboardKeySelector LocationKey;                                               // 0x00B8 (size: 0x28)
    FVector Location;                                                                 // 0x00E0 (size: 0x18)
    UClass* SelectedClass;                                                            // 0x00F8 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_FindItem(int32 EntryPoint);
}; // Size: 0x100

#endif
