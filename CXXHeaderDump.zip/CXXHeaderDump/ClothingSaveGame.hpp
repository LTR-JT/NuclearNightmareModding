#ifndef UE4SS_SDK_ClothingSaveGame_HPP
#define UE4SS_SDK_ClothingSaveGame_HPP

class UClothingSaveGame_C : public USaveGame
{
    TArray<FSClothingItem> ClothingItems;                                             // 0x0028 (size: 0x10)
    FLinearColor SavedColor;                                                          // 0x0038 (size: 0x10)

}; // Size: 0x48

#endif
