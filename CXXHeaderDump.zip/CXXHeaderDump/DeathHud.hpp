#ifndef UE4SS_SDK_DeathHud_HPP
#define UE4SS_SDK_DeathHud_HPP

class UDeathHud_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* Damage;                                                   // 0x02E8 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F0 (size: 0x8)

    void Construct();
    void ExecuteUbergraph_DeathHud(int32 EntryPoint);
}; // Size: 0x2F8

#endif
