#ifndef UE4SS_SDK_BPI_PowerEquipments_HPP
#define UE4SS_SDK_BPI_PowerEquipments_HPP

class IBPI_PowerEquipments_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void ToggleEquipment(bool Power);
}; // Size: 0x28

#endif
