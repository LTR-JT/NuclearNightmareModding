#ifndef UE4SS_SDK_BP_West_Heli_UH60A_Showcase_HPP
#define UE4SS_SDK_BP_West_Heli_UH60A_Showcase_HPP

class ABP_West_Heli_UH60A_Showcase_C : public ABP_West_Heli_UH60A_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02D0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh5;                                      // 0x02D8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh4;                                      // 0x02E0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh3;                                      // 0x02E8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh2;                                      // 0x02F0 (size: 0x8)
    class UPointLightComponent* PointLight2;                                          // 0x02F8 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x0300 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0308 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0310 (size: 0x8)
    class UAudioComponent* helicopter-loop;                                           // 0x0318 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x0320 (size: 0x8)
    class UBP_ShowcaseSetupComponent_C* BP_ShowcaseSetupComponent;                    // 0x0328 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat1Player;                                    // 0x0330 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat2Player;                                    // 0x0338 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat3Player;                                    // 0x0340 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat4Player;                                    // 0x0348 (size: 0x8)
    FVector Location;                                                                 // 0x0350 (size: 0x18)
    float Interp Speed;                                                               // 0x0368 (size: 0x4)
    bool IsMainMenuProp;                                                              // 0x036C (size: 0x1)
    bool LobbyAircraft?;                                                              // 0x036D (size: 0x1)

    void SetSliderVariable5(double NewValue);
    void SetSliderVariable6(double NewValue);
    void SetSliderVariable7(double NewValue);
    void SetCheckboxVariable2(bool NewState);
    void SetCheckboxVariable3(bool NewState);
    void SetCheckboxVariable4(bool NewState);
    void SetCheckboxVariable5(bool NewState);
    void SetCheckboxVariable6(bool NewState);
    void SetCheckboxVariable7(bool NewState);
    void SetTwinSliderVariable6(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable7(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetButtonsVariable0(int32 NewIndex);
    void SetButtonsVariable1(int32 NewIndex);
    void SetButtonsVariable2(int32 NewIndex);
    void SetButtonsVariable3(int32 NewIndex);
    void SetButtonsVariable4(int32 NewIndex);
    void SetButtonsVariable5(int32 NewIndex);
    void SetButtonsVariable6(int32 NewIndex);
    void SetButtonsVariable7(int32 NewIndex);
    void SetSliderVariable0(double NewValue);
    void SetSliderVariable1(double NewValue);
    void SetSliderVariable2(double NewValue);
    void SetCheckboxVariable0(bool NewState);
    void SetCheckboxVariable1(bool NewState);
    void SetSliderVariable4(double NewValue);
    void SetSliderVariable3(double NewValue);
    void SetTwinSliderVariable0(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable1(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable2(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable3(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable4(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable5(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_West_Heli_UH60A_Showcase(int32 EntryPoint);
}; // Size: 0x36E

#endif
