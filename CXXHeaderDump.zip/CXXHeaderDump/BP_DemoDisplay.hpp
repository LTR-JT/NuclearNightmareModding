#ifndef UE4SS_SDK_BP_DemoDisplay_HPP
#define UE4SS_SDK_BP_DemoDisplay_HPP

class ABP_DemoDisplay_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_Main;                                    // 0x0298 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_Corner;                                  // 0x02A0 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_Side;                                    // 0x02A8 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_ Curve;                                  // 0x02B0 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_ CurveEdge;                              // 0x02B8 (size: 0x8)
    double Width;                                                                     // 0x02C0 (size: 0x8)
    double Depth;                                                                     // 0x02C8 (size: 0x8)
    double Height;                                                                    // 0x02D0 (size: 0x8)
    FText Title Text;                                                                 // 0x02D8 (size: 0x10)
    TArray<FText> Description Text;                                                   // 0x02E8 (size: 0x10)
    TEnumAsByte<EHorizTextAligment> Text Alignment;                                   // 0x02F8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02F9 (size: 0x7)
    double Description Scale;                                                         // 0x0300 (size: 0x8)
    double Title Scale;                                                               // 0x0308 (size: 0x8)
    FColor Title Colour;                                                              // 0x0310 (size: 0x4)
    FColor Description Colour;                                                        // 0x0314 (size: 0x4)
    bool Seperate Title Panel;                                                        // 0x0318 (size: 0x1)
    bool Floor Text;                                                                  // 0x0319 (size: 0x1)
    bool SpotLight;                                                                   // 0x031A (size: 0x1)
    char padding_1[0x1];                                                              // 0x031B (size: 0x1)
    int32 Number of lines between paragraphs;                                         // 0x031C (size: 0x4)
    int32 Number of spaces between lines;                                             // 0x0320 (size: 0x4)
    char padding_2[0x4];                                                              // 0x0324 (size: 0x4)
    FString DescriptionFinal;                                                         // 0x0328 (size: 0x10)
    float Text Padding;                                                               // 0x0338 (size: 0x4)
    char padding_3[0x4];                                                              // 0x033C (size: 0x4)
    class UInstancedStaticMeshComponent* ISM_TitleBarMain;                            // 0x0340 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_TitleBarEnd;                             // 0x0348 (size: 0x8)
    bool Cast Shadows;                                                                // 0x0350 (size: 0x1)
    char padding_4[0x7];                                                              // 0x0351 (size: 0x7)
    class UInstancedStaticMeshComponent* ISM_ShadowStraight;                          // 0x0358 (size: 0x8)
    class UInstancedStaticMeshComponent* ISM_ShadowRound;                             // 0x0360 (size: 0x8)
    double ShadowCover;                                                               // 0x0368 (size: 0x8)
    FDataTableRowHandle Colour;                                                       // 0x0370 (size: 0x10)
    FLinearColor Custom Colour;                                                       // 0x0380 (size: 0x10)

    void ScaleSafeInstance(class UInstancedStaticMeshComponent* Instance, const FTransform& Transform);
    void Shadow Box();
    void Add Title Panel();
    void Format Text();
    void Redraw();
    void Scalable Panel(FTransform Base Position, double Length);
    void Create Display();
    void Create Instances();
    void UserConstructionScript();
}; // Size: 0x390

#endif
