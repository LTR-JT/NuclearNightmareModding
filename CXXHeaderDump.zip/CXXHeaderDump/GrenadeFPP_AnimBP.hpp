#ifndef UE4SS_SDK_GrenadeFPP_AnimBP_HPP
#define UE4SS_SDK_GrenadeFPP_AnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_213;                                                         // 0x0004 (size: 0x8)
    FName __NameProperty_214;                                                         // 0x000C (size: 0x8)
    int32 __IntProperty_215;                                                          // 0x0014 (size: 0x4)
    FName __NameProperty_216;                                                         // 0x0018 (size: 0x8)
    int32 __IntProperty_217;                                                          // 0x0020 (size: 0x4)
    FName __NameProperty_218;                                                         // 0x0024 (size: 0x8)
    int32 __IntProperty_219;                                                          // 0x002C (size: 0x4)
    FName __NameProperty_220;                                                         // 0x0030 (size: 0x8)
    int32 __IntProperty_221;                                                          // 0x0038 (size: 0x4)
    FName __NameProperty_222;                                                         // 0x003C (size: 0x8)
    int32 __IntProperty_223;                                                          // 0x0044 (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_224;                               // 0x0048 (size: 0x2C)
    FName __NameProperty_225;                                                         // 0x0074 (size: 0x8)
    int32 __IntProperty_226;                                                          // 0x007C (size: 0x4)
    FName __NameProperty_227;                                                         // 0x0080 (size: 0x8)
    int32 __IntProperty_228;                                                          // 0x0088 (size: 0x4)
    bool __BoolProperty_229;                                                          // 0x008C (size: 0x1)
    float __FloatProperty_230;                                                        // 0x0090 (size: 0x4)
    float __FloatProperty_231;                                                        // 0x0094 (size: 0x4)
    bool __BoolProperty_232;                                                          // 0x0098 (size: 0x1)
    EAnimSyncMethod __EnumProperty_233;                                               // 0x0099 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_234;                             // 0x009A (size: 0x1)
    FName __NameProperty_235;                                                         // 0x009C (size: 0x8)
    FName __NameProperty_236;                                                         // 0x00A4 (size: 0x8)
    FName __NameProperty_237;                                                         // 0x00AC (size: 0x8)
    int32 __IntProperty_238;                                                          // 0x00B4 (size: 0x4)
    FAnimNodeFunctionRef __StructProperty_239;                                        // 0x00B8 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00D8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0158 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0170 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_11;    // 0x01A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_10;    // 0x01D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_9;     // 0x0200 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_8;     // 0x0230 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_7;     // 0x0260 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_6;     // 0x0290 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_5;     // 0x02C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_4;     // 0x02F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3;     // 0x0320 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2;     // 0x0350 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x0380 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x03B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_5;       // 0x03E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_7;          // 0x0410 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_4;       // 0x0440 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_6;          // 0x0470 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3;       // 0x04A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_5;          // 0x04D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2;       // 0x0500 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_4;          // 0x0530 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0560 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3;          // 0x0590 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x05C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2;          // 0x05F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0620 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x0650 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x0680 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x06B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x06E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x0710 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0740 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0770 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x07A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend;       // 0x07D0 (size: 0x30)

}; // Size: 0x800

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)

}; // Size: 0xC

class UGrenadeFPP_AnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0xC)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0398 (size: 0x20)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;                     // 0x03B8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;                     // 0x03E0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;                      // 0x0408 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;                      // 0x0430 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;                      // 0x0458 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;                      // 0x0480 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;                      // 0x04A8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;                      // 0x04D0 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;                      // 0x04F8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;                      // 0x0520 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0548 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0570 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;                          // 0x0598 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_7;                                // 0x05E0 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;                          // 0x0600 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_6;                                // 0x0648 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;                          // 0x0668 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_5;                                // 0x06B0 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;                          // 0x06D0 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_4;                                // 0x0718 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x0738 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_3;                                // 0x0780 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07A0 (size: 0x48)
    FAnimNode_StateResult AnimGraphNode_StateResult_2;                                // 0x07E8 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0808 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0878 (size: 0x20)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0898 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0908 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0928 (size: 0xC8)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x09F0 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x0A70 (size: 0x28)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x0A98 (size: 0x28)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0AC0 (size: 0x48)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x0B08 (size: 0xF0)
    double Speed;                                                                     // 0x0BF8 (size: 0x8)
    bool PinPulled?;                                                                  // 0x0C00 (size: 0x1)
    bool IsAiming?;                                                                   // 0x0C01 (size: 0x1)
    bool IsInAir?;                                                                    // 0x0C02 (size: 0x1)
    bool HasGrenade?;                                                                 // 0x0C03 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_GrenadeFPP_AnimBP_AnimGraphNode_TransitionResult_7027C47F46D1966A98FF24AEE45E3182();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_GrenadeFPP_AnimBP_AnimGraphNode_TransitionResult_4C9BB5FB43DC25849C8F838C4AE042D6();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_GrenadeFPP_AnimBP_AnimGraphNode_TransitionResult_477D42FE40CF51CCA96506B02A62AB61();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_GrenadeFPP_AnimBP_AnimGraphNode_TransitionResult_D1E79102482B32D0DD5585A7377A4426();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_GrenadeFPP_AnimBP_AnimGraphNode_TransitionResult_BDF4B2064ADDFEBB9D2B5093A84E7405();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_GrenadeFPP_AnimBP(int32 EntryPoint);
}; // Size: 0xC04

#endif
