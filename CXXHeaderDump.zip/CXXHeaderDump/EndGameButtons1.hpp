#ifndef UE4SS_SDK_EndGameButtons1_HPP
#define UE4SS_SDK_EndGameButtons1_HPP

class UEndGameButtons1_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_36;                                                         // 0x02E8 (size: 0x8)
    FEndGameButtons1_CBackToMenu BackToMenu;                                          // 0x02F0 (size: 0x10)
    void BackToMenu();

    void BndEvt__EndGameButtons_Button_36_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_EndGameButtons1(int32 EntryPoint);
    void BackToMenu__DelegateSignature();
}; // Size: 0x300

#endif
