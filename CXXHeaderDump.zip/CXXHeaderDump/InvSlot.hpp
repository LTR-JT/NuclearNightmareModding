#ifndef UE4SS_SDK_InvSlot_HPP
#define UE4SS_SDK_InvSlot_HPP

class UInvSlot_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UImage* HighlightedSlot;                                                    // 0x02E8 (size: 0x8)
    class UImage* ItemImage;                                                          // 0x02F0 (size: 0x8)
    class UImage* NormalSlot;                                                         // 0x02F8 (size: 0x8)
    class UProgressBar* ProgressBar_44;                                               // 0x0300 (size: 0x8)
    class AItemActor* ItemPtr;                                                        // 0x0308 (size: 0x8)
    bool Empty?;                                                                      // 0x0310 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Player;                                         // 0x0318 (size: 0x8)

    FLinearColor GetFillColorAndOpacity();
    float GetPercent();
    void Construct();
    void ItemUpdate();
    void ForceReset();
    void HighlightedItem();
    void DeselectItem();
    void ExecuteUbergraph_InvSlot(int32 EntryPoint);
}; // Size: 0x320

#endif
