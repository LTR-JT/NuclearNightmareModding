#ifndef UE4SS_SDK_BP_Inside_HPP
#define UE4SS_SDK_BP_Inside_HPP

class ABP_Inside_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    bool NoHeater;                                                                    // 0x02A8 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02A9 (size: 0x7)
    class USoundBase* Sound;                                                          // 0x02B0 (size: 0x8)

    void BndEvt__BP_Inside_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_Inside_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_BP_Inside(int32 EntryPoint);
}; // Size: 0x2B8

#endif
