#ifndef UE4SS_SDK_AdvancedSteamSessions_HPP
#define UE4SS_SDK_AdvancedSteamSessions_HPP

#include "AdvancedSteamSessions_enums.hpp"

struct FBPSteamGroupInfo
{
    FBPUniqueNetId GroupID;                                                           // 0x0000 (size: 0x20)
    FString GroupName;                                                                // 0x0020 (size: 0x10)
    FString GroupTag;                                                                 // 0x0030 (size: 0x10)
    int32 numOnline;                                                                  // 0x0040 (size: 0x4)
    int32 numInGame;                                                                  // 0x0044 (size: 0x4)
    int32 numChatting;                                                                // 0x0048 (size: 0x4)

}; // Size: 0x50

struct FBPSteamGroupOfficer
{
    FBPUniqueNetId OfficerUniqueNetID;                                                // 0x0000 (size: 0x20)
    bool bIsOwner;                                                                    // 0x0020 (size: 0x1)

}; // Size: 0x28

struct FBPSteamWorkshopID
{
}; // Size: 0x8

struct FBPSteamWorkshopItemDetails
{
    FBPSteamResult ResultOfRequest;                                                   // 0x0000 (size: 0x1)
    FBPWorkshopFileType FileType;                                                     // 0x0001 (size: 0x1)
    int32 CreatorAppID;                                                               // 0x0004 (size: 0x4)
    int32 ConsumerAppID;                                                              // 0x0008 (size: 0x4)
    FString Title;                                                                    // 0x0010 (size: 0x10)
    FString Description;                                                              // 0x0020 (size: 0x10)
    FString ItemUrl;                                                                  // 0x0030 (size: 0x10)
    int32 VotesUp;                                                                    // 0x0040 (size: 0x4)
    int32 VotesDown;                                                                  // 0x0044 (size: 0x4)
    float CalculatedScore;                                                            // 0x0048 (size: 0x4)
    bool bBanned;                                                                     // 0x004C (size: 0x1)
    bool bAcceptedForUse;                                                             // 0x004D (size: 0x1)
    bool bTagsTruncated;                                                              // 0x004E (size: 0x1)
    FString CreatorSteamID;                                                           // 0x0050 (size: 0x10)

}; // Size: 0x60

class UAdvancedSteamFriendsLibrary : public UBlueprintFunctionLibrary
{

    bool RequestSteamFriendInfo(const FBPUniqueNetId UniqueNetId, bool bRequireNameOnly);
    bool OpenSteamUserOverlay(const FBPUniqueNetId UniqueNetId, ESteamUserOverlayType DialogType);
    bool IsSteamInBigPictureMode();
    bool IsOverlayEnabled();
    bool InitTextFiltering();
    FString GetSteamPersonaName(const FBPUniqueNetId UniqueNetId);
    void GetSteamGroups(TArray<FBPSteamGroupInfo>& SteamGroups);
    void GetSteamFriendGamePlayed(const FBPUniqueNetId UniqueNetId, EBlueprintResultSwitch& Result, int32& AppId);
    class UTexture2D* GetSteamFriendAvatar(const FBPUniqueNetId UniqueNetId, EBlueprintAsyncResultSwitch& Result, SteamAvatarSize AvatarSize);
    FBPUniqueNetId GetLocalSteamIDFromSteam();
    int32 GetFriendSteamLevel(const FBPUniqueNetId UniqueNetId);
    bool FilterText(FString TextToFilter, EBPTextFilteringContext Context, const FBPUniqueNetId TextSourceID, FString& FilteredText);
    FBPUniqueNetId CreateSteamIDFromString(const FString SteamID64);
}; // Size: 0x28

class UAdvancedSteamWorkshopLibrary : public UBlueprintFunctionLibrary
{

    TArray<FBPSteamWorkshopID> GetSubscribedWorkshopItems(int32& NumberOfItems);
    void GetNumSubscribedWorkshopItems(int32& NumberOfItems);
}; // Size: 0x28

class USteamNotificationsSubsystem : public UGameInstanceSubsystem
{
    FSteamNotificationsSubsystemOnSteamOverlayActivated_Bind OnSteamOverlayActivated_Bind; // 0x0030 (size: 0x10)
    void OnSteamOverlayActivated(bool bOverlayState);

}; // Size: 0x68

class USteamRequestGroupOfficersCallbackProxy : public UOnlineBlueprintCallProxyBase
{
    FSteamRequestGroupOfficersCallbackProxyOnSuccess OnSuccess;                       // 0x0030 (size: 0x10)
    void BlueprintGroupOfficerDetailsDelegate(const TArray<FBPSteamGroupOfficer>& OfficerList);
    FSteamRequestGroupOfficersCallbackProxyOnFailure OnFailure;                       // 0x0040 (size: 0x10)
    void BlueprintGroupOfficerDetailsDelegate(const TArray<FBPSteamGroupOfficer>& OfficerList);

    class USteamRequestGroupOfficersCallbackProxy* GetSteamGroupOfficerList(class UObject* WorldContextObject, FBPUniqueNetId GroupUniqueNetID);
}; // Size: 0xA0

class USteamWSRequestUGCDetailsCallbackProxy : public UOnlineBlueprintCallProxyBase
{
    FSteamWSRequestUGCDetailsCallbackProxyOnSuccess OnSuccess;                        // 0x0030 (size: 0x10)
    void BlueprintWorkshopDetailsDelegate(const FBPSteamWorkshopItemDetails& WorkShopDetails);
    FSteamWSRequestUGCDetailsCallbackProxyOnFailure OnFailure;                        // 0x0040 (size: 0x10)
    void BlueprintWorkshopDetailsDelegate(const FBPSteamWorkshopItemDetails& WorkShopDetails);

    class USteamWSRequestUGCDetailsCallbackProxy* GetWorkshopItemDetails(class UObject* WorldContextObject, FBPSteamWorkshopID WorkShopID);
}; // Size: 0x88

#endif
