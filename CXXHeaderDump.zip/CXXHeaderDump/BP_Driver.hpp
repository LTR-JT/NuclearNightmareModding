#ifndef UE4SS_SDK_BP_Driver_HPP
#define UE4SS_SDK_BP_Driver_HPP

class ABP_Driver_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class USkeletalMeshComponent* SK_Arms;                                            // 0x0678 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0680 (size: 0x8)
    class USpringArmComponent* CameraSpringArm;                                       // 0x0688 (size: 0x8)
    double Health;                                                                    // 0x0690 (size: 0x8)
    double YawControlRotation;                                                        // 0x0698 (size: 0x8)
    double PitchControlRotation;                                                      // 0x06A0 (size: 0x8)
    bool VehicleInSight;                                                              // 0x06A8 (size: 0x1)
    bool Driver;                                                                      // 0x06A9 (size: 0x1)
    bool Passenger;                                                                   // 0x06AA (size: 0x1)

    void OnRep_Driver();
    void Enter/ExitVehicleTraceLine(bool Pressed/Released);
    void InpActEvt_SpaceBar_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_SpaceBar_K2Node_InputKeyEvent_0(FKey Key);
    void InpActEvt_Enter/ExitVehicle_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Enter/ExitVehicle_K2Node_InputActionEvent_0(FKey Key);
    void ReceiveBeginPlay();
    void RPC Simulate Ragdoll "Server"();
    void RPC Simulate Ragdoll "Multicast"();
    void RPC Enter/Exit Vehicle "Server"(bool Pressed/Released);
    void RPC Set Yaw Control Rotation "Server"(double Value);
    void RPC Set Yaw Control Rotation "Multicast"(double Value);
    void RPC Set Pitch Control Rotation "Server"(double Value);
    void RPC Set Pitch Control Rotation "Multicast"(double Value);
    void InpAxisEvt_LookUp_K2Node_InputAxisEvent_1(float AxisValue);
    void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2(float AxisValue);
    void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_3(float AxisValue);
    void InpAxisEvt_LookRight_K2Node_InputAxisEvent_5(float AxisValue);
    void ExecuteUbergraph_BP_Driver(int32 EntryPoint);
}; // Size: 0x6AB

#endif
