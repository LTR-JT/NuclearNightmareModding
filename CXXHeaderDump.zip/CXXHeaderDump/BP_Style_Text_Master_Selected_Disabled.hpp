#ifndef UE4SS_SDK_BP_Style_Text_Master_Selected_Disabled_HPP
#define UE4SS_SDK_BP_Style_Text_Master_Selected_Disabled_HPP

class UBP_Style_Text_Master_Selected_Disabled_C : public UBP_Style_Text_Master_C
{
}; // Size: 0x1B0

#endif
