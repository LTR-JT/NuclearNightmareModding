#ifndef UE4SS_SDK_BP_Style_Text_Master_Selected_Disabled_HPP
#define UE4SS_SDK_BP_Style_Text_Master_Selected_Disabled_HPP

class UBP_Style_Text_Master_Selected_Disabled_C : public UBP_Style_Text_Master_C
{
    char padding_0[0x1B0];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x1B0

#endif
