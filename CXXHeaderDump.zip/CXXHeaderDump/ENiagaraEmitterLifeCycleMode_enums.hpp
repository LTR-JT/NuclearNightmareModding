namespace ENiagaraEmitterLifeCycleMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraEmitterLifeCycleMode_MAX = 2,
    };
}

