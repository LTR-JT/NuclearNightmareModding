namespace ENiagaraMeshOrSprite {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraMeshOrSprite_MAX = 2,
    };
}

