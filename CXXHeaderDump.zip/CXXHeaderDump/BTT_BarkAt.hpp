#ifndef UE4SS_SDK_BTT_BarkAt_HPP
#define UE4SS_SDK_BTT_BarkAt_HPP

class UBTT_BarkAt_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector playerkey;                                                 // 0x00B0 (size: 0x28)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_BarkAt(int32 EntryPoint);
}; // Size: 0xD8

#endif
