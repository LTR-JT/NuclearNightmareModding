#ifndef UE4SS_SDK_bp_laser_HPP
#define UE4SS_SDK_bp_laser_HPP

class Abp_laser_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class URadialForceComponent* RadialForce;                                         // 0x0298 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* KompakBM86;                                           // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Dynamite2;                                            // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Dynamite1;                                            // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Dynamite;                                             // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Cylinder;                                             // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Laser_Sight_Square__Laser_Sight1;                     // 0x02D0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02D8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02E0 (size: 0x8)
    bool PoweredOn;                                                                   // 0x02E8 (size: 0x1)
    bool Interacting;                                                                 // 0x02E9 (size: 0x1)
    char padding_0[0x6];                                                              // 0x02EA (size: 0x6)
    class UW_Task_lazer_C* TaskHud;                                                   // 0x02F0 (size: 0x8)
    bool CalledEarly;                                                                 // 0x02F8 (size: 0x1)
    char padding_1[0x7];                                                              // 0x02F9 (size: 0x7)
    FTimerHandle TimerHandle;                                                         // 0x0300 (size: 0x8)
    bool ReturnedState;                                                               // 0x0308 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void OnNotifyEnd_264C3F174F7F14A3644EE9BE4A421609(FName NotifyName);
    void OnNotifyBegin_264C3F174F7F14A3644EE9BE4A421609(FName NotifyName);
    void OnInterrupted_264C3F174F7F14A3644EE9BE4A421609(FName NotifyName);
    void OnBlendOut_264C3F174F7F14A3644EE9BE4A421609(FName NotifyName);
    void OnCompleted_264C3F174F7F14A3644EE9BE4A421609(FName NotifyName);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void BndEvt__bp_laser_Cylinder_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BlowUpPlayer(TArray<class AActor*>& Actors);
    void BlowUpServer(const TArray<class AActor*>& Actors);
    void SecondaryInteraction();
    void ReceiveBeginPlay();
    void RandomSpawn();
    void DestroyAll();
    void DesroyPlayer(class ABP_FirstPersonCharacter_C* CHAR);
    void ToggleEquipment(bool Power);
    void DestroyPlayer(class ABP_FirstPersonCharacter_C* CHAR);
    void CancelAction();
    void FinishTask();
    void UpdateState();
    void UpdateStateRPC();
    void UpdateLaserState(bool State);
    void RPCUpdateLaser(bool State);
    void TurnOnLaser();
    void TurnedOnLazerFully();
    void ExecuteUbergraph_bp_laser(int32 EntryPoint);
}; // Size: 0x309

#endif
