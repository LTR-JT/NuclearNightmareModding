#ifndef UE4SS_SDK_BP_ButtonStyle-Home_HPP
#define UE4SS_SDK_BP_ButtonStyle-Home_HPP

class UBP_ButtonStyle-Home_C : public UBP_ButtonStyle_Master_C
{
}; // Size: 0x7B0

#endif
