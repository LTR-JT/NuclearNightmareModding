#ifndef UE4SS_SDK_BPI_Interactions_DUPL_1_HPP
#define UE4SS_SDK_BPI_Interactions_DUPL_1_HPP

class IBPI_Interactions_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Toggle(bool On/off);
}; // Size: 0x28

#endif
