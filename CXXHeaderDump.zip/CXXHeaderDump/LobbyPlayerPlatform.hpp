#ifndef UE4SS_SDK_LobbyPlayerPlatform_HPP
#define UE4SS_SDK_LobbyPlayerPlatform_HPP

class ALobbyPlayerPlatform_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    class UMaterialInstanceDynamic* PlayerColor;                                      // 0x02A8 (size: 0x8)
    bool IsMe?;                                                                       // 0x02B0 (size: 0x1)
    class APlayerController* PC;                                                      // 0x02B8 (size: 0x8)
    class AActor* LobbyCamera;                                                        // 0x02C0 (size: 0x8)
    int32 Index;                                                                      // 0x02C8 (size: 0x4)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void SpawnPlayer(class APlayerController* PC);
    void DisconnectPlayer();
    void SpawnPlayerMulti(class APlayerController* PC);
    void SpawnPlayerServer(class APlayerController* PC);
    void ExecuteUbergraph_LobbyPlayerPlatform(int32 EntryPoint);
}; // Size: 0x2CC

#endif
