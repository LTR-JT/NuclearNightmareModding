#ifndef UE4SS_SDK_BP_Floodlight_02_HPP
#define UE4SS_SDK_BP_Floodlight_02_HPP

class ABP_Floodlight_02_C : public AActor
{
    class UAudioComponent* Audio;                                                     // 0x0290 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0298 (size: 0x8)
    class UParticleSystemComponent* P_Lensflare_Bot_01;                               // 0x02A0 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x02A8 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x02B0 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02C0 (size: 0x8)

}; // Size: 0x2C8

#endif
