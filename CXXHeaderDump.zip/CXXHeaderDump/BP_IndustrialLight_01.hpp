#ifndef UE4SS_SDK_BP_IndustrialLight_01_HPP
#define UE4SS_SDK_BP_IndustrialLight_01_HPP

class ABP_IndustrialLight_01_C : public AActor
{
    class UStaticMeshComponent* StaticMeshComponent0;                                 // 0x0290 (size: 0x8)
    class USpotLightComponent* LightComponent0;                                       // 0x0298 (size: 0x8)
    bool Lit;                                                                         // 0x02A0 (size: 0x1)
    char padding_0[0x7];                                                              // 0x02A1 (size: 0x7)
    double LightIntensity;                                                            // 0x02A8 (size: 0x8)
    double LightInt;                                                                  // 0x02B0 (size: 0x8)
    bool (Debug) Cast Shadows;                                                        // 0x02B8 (size: 0x1)

    void UserConstructionScript();
}; // Size: 0x2B9

#endif
