#ifndef UE4SS_SDK_BP_GameInstance_HPP
#define UE4SS_SDK_BP_GameInstance_HPP

class UBP_GameInstance_C : public UAdvancedFriendsGameInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0240 (size: 0x8)
    int32 New Connected Players;                                                      // 0x0248 (size: 0x4)
    bool LoadedForFirstTime?;                                                         // 0x024C (size: 0x1)
    FText Description Text;                                                           // 0x0250 (size: 0x10)
    bool FriendlyFire;                                                                // 0x0260 (size: 0x1)
    bool Team Spawn;                                                                  // 0x0261 (size: 0x1)
    TEnumAsByte<EDiffculty::Type> Diffculty;                                          // 0x0262 (size: 0x1)
    TEnumAsByte<EDayNightCycle::Type> DayNightCycle;                                  // 0x0263 (size: 0x1)
    TEnumAsByte<EItemSpawnProbability::Type> Frequency;                               // 0x0264 (size: 0x1)
    TEnumAsByte<ENukeTimer::Type> Nuke Timer;                                         // 0x0265 (size: 0x1)
    bool Allow Enemy Day Spawn;                                                       // 0x0266 (size: 0x1)
    TEnumAsByte<EDiffculty::Type> Minium Classified;                                  // 0x0267 (size: 0x1)
    FFServerSettings ServerOwnerStruct;                                               // 0x0268 (size: 0x20)
    bool WasThereAFailureServer;                                                      // 0x0288 (size: 0x1)
    bool LanOptionSelected?;                                                          // 0x0289 (size: 0x1)
    bool LanMode?;                                                                    // 0x028A (size: 0x1)
    bool Gamepadbeingused?;                                                           // 0x028B (size: 0x1)
    bool Playable Enemy;                                                              // 0x028C (size: 0x1)
    int32 LobbyMins;                                                                  // 0x0290 (size: 0x4)
    bool AirbornInfections;                                                           // 0x0294 (size: 0x1)
    bool Never Spawn Playable Enemy;                                                  // 0x0295 (size: 0x1)
    bool Disable Reinforcment;                                                        // 0x0296 (size: 0x1)
    bool Dog from Mass;                                                               // 0x0297 (size: 0x1)
    bool Radios;                                                                      // 0x0298 (size: 0x1)
    bool Disable Worm;                                                                // 0x0299 (size: 0x1)
    bool Disable Trip Mine;                                                           // 0x029A (size: 0x1)
    bool Disable Infection Notifies;                                                  // 0x029B (size: 0x1)
    bool Disable Leeches;                                                             // 0x029C (size: 0x1)
    int32 Enemy Frequency;                                                            // 0x02A0 (size: 0x4)
    TEnumAsByte<EVehicleSpawnFrequency::Type> Snowmobile Freq;                        // 0x02A4 (size: 0x1)
    TEnumAsByte<EVehicleSpawnFrequency::Type> Snowcat Freq;                           // 0x02A5 (size: 0x1)
    TEnumAsByte<EVehicleSpawnFrequency::Type> Heli Freq;                              // 0x02A6 (size: 0x1)

    void OnFailure_F3E5CC5A43988D4186E5BB83C3D48D8A();
    void OnSuccess_F3E5CC5A43988D4186E5BB83C3D48D8A();
    void OnFailure_D2E917E3494E2829E5667191DE6236EA();
    void OnSuccess_D2E917E3494E2829E5667191DE6236EA();
    void OnFailure_98D2E0294EBEAE3702E0AD8E66A89F79();
    void OnSuccess_98D2E0294EBEAE3702E0AD8E66A89F79();
    void OnFailure_5B454E1C4A792BF1DF20F7BB4293EFD5();
    void OnSuccess_5B454E1C4A792BF1DF20F7BB4293EFD5();
    void OnFailure_EA489B94469FE26DB629C789037C74BC();
    void OnSuccess_EA489B94469FE26DB629C789037C74BC();
    void OnFailure_05F5BCCC441A001392CBDE88A982FAA4();
    void OnSuccess_05F5BCCC441A001392CBDE88A982FAA4();
    void OnFailure_4A6C4937455DFCE936B4BE9D65562A0A();
    void OnSuccess_4A6C4937455DFCE936B4BE9D65562A0A();
    void OnFailure_6834587B42E511E67001509106E5EE15();
    void OnSuccess_6834587B42E511E67001509106E5EE15();
    void TravelToMap(int32 NewConnectedPlayers, FString MapName);
    void HandleNetworkError(TEnumAsByte<ENetworkFailure::Type> FailureType, bool bIsServer);
    void HandleTravelError(TEnumAsByte<ETravelFailure::Type> FailureType);
    void Leave Session();
    void DisconnectClient();
    void ExitingServer();
    void CreateSteamSession(FString Session Name, bool bShouldAdvertise, bool FriendlyFire, bool bUseLAN, bool bAllowJoinViaPresenceFriendsOnly, bool TeamSpawn, TEnumAsByte<EDiffculty::Type> Diffculty, TEnumAsByte<EDayNightCycle::Type> DayNightCycle, TEnumAsByte<EItemSpawnProbability::Type> Frequency, TEnumAsByte<ENukeTimer::Type> NukeTimer, bool AllowEnemyDaySpawn, TEnumAsByte<EDiffculty::Type> MiniumClassified, bool PlayableEnemy, int32 Minutes, bool AirbornInfections, bool NeverSpawnPlayableEnemy, bool DisableReinforcment, bool DogFromMass, bool Radios, bool Disable Worm, bool DisableTripMine, bool DisableInfectionNotifies, bool DisableLeeches, int32 EnemyFrequency, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowmobileFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> SnowcatFreq, TEnumAsByte<EVehicleSpawnFrequency::Type> HeliFreq);
    void OnSessionInviteAccepted(int32 LocalPlayerNum, FBPUniqueNetId PersonInvited, const FBlueprintSessionResult& SessionToJoin);
    void ShowFailureMessage();
    void UpdatePlayerCount(int32 CurrentPlayers);
    void HideServerFromPublic();
    void UpdateLobbyState(bool IsInProgress?);
    void ExecuteUbergraph_BP_GameInstance(int32 EntryPoint);
}; // Size: 0x2A7

#endif
