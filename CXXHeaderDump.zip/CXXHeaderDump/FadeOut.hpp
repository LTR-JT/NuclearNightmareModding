#ifndef UE4SS_SDK_FadeOut_HPP
#define UE4SS_SDK_FadeOut_HPP

class UFadeOut_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* fade;                                                     // 0x02E8 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F0 (size: 0x8)
    float Playback Speed;                                                             // 0x02F8 (size: 0x4)
    FFadeOut_CFadeOut FadeOut;                                                        // 0x0300 (size: 0x10)
    void FadeOut();

    void Construct();
    void FinishedFade();
    void ExecuteUbergraph_FadeOut(int32 EntryPoint);
    void FadeOut__DelegateSignature();
}; // Size: 0x310

#endif
