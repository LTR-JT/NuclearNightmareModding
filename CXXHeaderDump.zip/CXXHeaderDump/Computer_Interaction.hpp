#ifndef UE4SS_SDK_Computer_Interaction_HPP
#define UE4SS_SDK_Computer_Interaction_HPP

class AComputer_Interaction_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0298 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x02A0 (size: 0x8)
    class UAudioComponent* computer-fan;                                              // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Plane;                                                // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02B8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x02C8 (size: 0x8)
    double Closest;                                                                   // 0x02D0 (size: 0x8)
    class ABP_Radio_C* Radio;                                                         // 0x02D8 (size: 0x8)
    bool Interacting;                                                                 // 0x02E0 (size: 0x1)
    bool PoweredOn?;                                                                  // 0x02E1 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ClosingComputer();
    void CloseCompServer();
    void CloseCompALL();
    void Collected Classified();
    void CollectedClassifiedMaterial();
    void CollectedALL();
    void TryInteract();
    void ToggleEquipment(bool Power);
    void ExecuteUbergraph_Computer_Interaction(int32 EntryPoint);
}; // Size: 0x2E2

#endif
