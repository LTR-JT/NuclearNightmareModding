#ifndef UE4SS_SDK_ExameModularClassified_HPP
#define UE4SS_SDK_ExameModularClassified_HPP

class AExameModularClassified_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    float Timeline_NewTrack_0_472C52B24611F86C16F716B5E2FE3FC5;                       // 0x02A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_472C52B24611F86C16F716B5E2FE3FC5; // 0x02AC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02B0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02B8 (size: 0x8)
    double Closest;                                                                   // 0x02C0 (size: 0x8)
    class ABP_Radio_C* Radio;                                                         // 0x02C8 (size: 0x8)
    bool Interacting;                                                                 // 0x02D0 (size: 0x1)
    TArray<class AExameModularClassified_C*> AssioatedExamines;                       // 0x02D8 (size: 0x10)
    bool FinishedExamine;                                                             // 0x02E8 (size: 0x1)
    class AObjectiveManager_C* ObjectiveManager;                                      // 0x02F0 (size: 0x8)
    FString TaskID;                                                                   // 0x02F8 (size: 0x10)

    void PassiveInteraction(FText& ActorName);
    void All Examined?(bool& Returned Status);
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_0ADAD72241BFF82F54B0A59ED14BABAA(FName NotifyName);
    void OnNotifyBegin_0ADAD72241BFF82F54B0A59ED14BABAA(FName NotifyName);
    void OnInterrupted_0ADAD72241BFF82F54B0A59ED14BABAA(FName NotifyName);
    void OnBlendOut_0ADAD72241BFF82F54B0A59ED14BABAA(FName NotifyName);
    void OnCompleted_0ADAD72241BFF82F54B0A59ED14BABAA(FName NotifyName);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_ExameModularClassified(int32 EntryPoint);
}; // Size: 0x308

#endif
