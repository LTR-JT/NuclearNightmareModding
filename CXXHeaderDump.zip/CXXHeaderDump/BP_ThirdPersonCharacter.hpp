#ifndef UE4SS_SDK_BP_ThirdPersonCharacter_HPP
#define UE4SS_SDK_BP_ThirdPersonCharacter_HPP

class ABP_ThirdPersonCharacter_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction3;                                     // 0x0678 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction2;                                     // 0x0680 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0688 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0690 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0698 (size: 0x8)
    class UParticleSystemComponent* Fire;                                             // 0x06A0 (size: 0x8)
    class USpringArmComponent* CameraBoom;                                            // 0x06A8 (size: 0x8)
    class USkeletalMeshComponent* CharacterMesh1;                                     // 0x06B0 (size: 0x8)
    class UCameraComponent* FollowCamera;                                             // 0x06B8 (size: 0x8)
    float RotateToMonster_NewTrack_0_76A02A474E4AC635279113AA14A4A239;                // 0x06C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> RotateToMonster__Direction_76A02A474E4AC635279113AA14A4A239; // 0x06C4 (size: 0x1)
    char padding_0[0x3];                                                              // 0x06C5 (size: 0x3)
    class UTimelineComponent* RotateToMonster;                                        // 0x06C8 (size: 0x8)
    float Timeline_0_NewTrack_0_5D64B8394DE8BC5C6AAD7897134B6256;                     // 0x06D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_5D64B8394DE8BC5C6AAD7897134B6256; // 0x06D4 (size: 0x1)
    char padding_1[0x3];                                                              // 0x06D5 (size: 0x3)
    class UTimelineComponent* Timeline_0;                                             // 0x06D8 (size: 0x8)
    float Timeline_NewTrack_0_AB97CC6D4268414226E844B511547ED7;                       // 0x06E0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_AB97CC6D4268414226E844B511547ED7; // 0x06E4 (size: 0x1)
    char padding_2[0x3];                                                              // 0x06E5 (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x06E8 (size: 0x8)
    class UStaticMeshComponent* Door;                                                 // 0x06F0 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x06F8 (size: 0x1)
    bool Running;                                                                     // 0x06F9 (size: 0x1)
    char padding_3[0x6];                                                              // 0x06FA (size: 0x6)
    double HealthAttacker;                                                            // 0x0700 (size: 0x8)
    TArray<class USkeletalMesh*> Meshes;                                              // 0x0708 (size: 0x10)
    TArray<class USkeletalMesh*> MeshesComponents;                                    // 0x0718 (size: 0x10)
    char padding_4[0x8];                                                              // 0x0728 (size: 0x8)
    FVector4 Saturation;                                                              // 0x0730 (size: 0x20)
    class UMonster_Inventory_C* Inv;                                                  // 0x0750 (size: 0x8)
    bool dead;                                                                        // 0x0758 (size: 0x1)
    char padding_5[0x7];                                                              // 0x0759 (size: 0x7)
    FRotator ControlRotation;                                                         // 0x0760 (size: 0x18)
    FBP_ThirdPersonCharacter_CTakeDamage TakeDamage;                                  // 0x0778 (size: 0x10)
    void TakeDamage();
    FHitResult Inital;                                                                // 0x0788 (size: 0xF8)
    FHitResult hit2;                                                                  // 0x0880 (size: 0xF8)
    FHitResult Hit3;                                                                  // 0x0978 (size: 0xF8)
    FVector TargetLocation;                                                           // 0x0A70 (size: 0x18)
    FRotator TargetRotation;                                                          // 0x0A88 (size: 0x18)
    FBP_ThirdPersonCharacter_CCoolDownStarted CoolDownStarted;                        // 0x0AA0 (size: 0x10)
    void CoolDownStarted();
    bool OnWall?;                                                                     // 0x0AB0 (size: 0x1)
    char padding_6[0x7];                                                              // 0x0AB1 (size: 0x7)
    class ABP_FirstPersonCharacter_C* Victim;                                         // 0x0AB8 (size: 0x8)
    class UMonsterRespawn_C* RespawnHud;                                              // 0x0AC0 (size: 0x8)

    void TraceFloor();
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void RotateToMonster__FinishedFunc();
    void RotateToMonster__UpdateFunc();
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_7FBE720B4B6F4DD99632C3A884B4B146(FName NotifyName);
    void OnNotifyBegin_7FBE720B4B6F4DD99632C3A884B4B146(FName NotifyName);
    void OnInterrupted_7FBE720B4B6F4DD99632C3A884B4B146(FName NotifyName);
    void OnBlendOut_7FBE720B4B6F4DD99632C3A884B4B146(FName NotifyName);
    void OnCompleted_7FBE720B4B6F4DD99632C3A884B4B146(FName NotifyName);
    void InpActEvt_IAMonsterAttack_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_B78009D04F3B5BAAE615F7A7F3E8AA82(FName NotifyName);
    void OnNotifyBegin_B78009D04F3B5BAAE615F7A7F3E8AA82(FName NotifyName);
    void OnInterrupted_B78009D04F3B5BAAE615F7A7F3E8AA82(FName NotifyName);
    void OnBlendOut_B78009D04F3B5BAAE615F7A7F3E8AA82(FName NotifyName);
    void OnCompleted_B78009D04F3B5BAAE615F7A7F3E8AA82(FName NotifyName);
    void OnNotifyEnd_CA3C99454AE32C0BF0024B865617B94B(FName NotifyName);
    void OnNotifyBegin_CA3C99454AE32C0BF0024B865617B94B(FName NotifyName);
    void OnInterrupted_CA3C99454AE32C0BF0024B865617B94B(FName NotifyName);
    void OnBlendOut_CA3C99454AE32C0BF0024B865617B94B(FName NotifyName);
    void OnCompleted_CA3C99454AE32C0BF0024B865617B94B(FName NotifyName);
    void OnNotifyEnd_1B5D122244E62BFFD3CFF4BA27E1B355(FName NotifyName);
    void OnNotifyBegin_1B5D122244E62BFFD3CFF4BA27E1B355(FName NotifyName);
    void OnInterrupted_1B5D122244E62BFFD3CFF4BA27E1B355(FName NotifyName);
    void OnBlendOut_1B5D122244E62BFFD3CFF4BA27E1B355(FName NotifyName);
    void OnCompleted_1B5D122244E62BFFD3CFF4BA27E1B355(FName NotifyName);
    void OnNotifyEnd_3A165C564BAE3CAD5A1C1A93637A6F0A(FName NotifyName);
    void OnNotifyBegin_3A165C564BAE3CAD5A1C1A93637A6F0A(FName NotifyName);
    void OnInterrupted_3A165C564BAE3CAD5A1C1A93637A6F0A(FName NotifyName);
    void OnBlendOut_3A165C564BAE3CAD5A1C1A93637A6F0A(FName NotifyName);
    void OnCompleted_3A165C564BAE3CAD5A1C1A93637A6F0A(FName NotifyName);
    void InpActEvt_IA_Sprint_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_AA99383C480678A0A06D02A83463BDB5(FName NotifyName);
    void OnNotifyBegin_AA99383C480678A0A06D02A83463BDB5(FName NotifyName);
    void OnInterrupted_AA99383C480678A0A06D02A83463BDB5(FName NotifyName);
    void OnBlendOut_AA99383C480678A0A06D02A83463BDB5(FName NotifyName);
    void OnCompleted_AA99383C480678A0A06D02A83463BDB5(FName NotifyName);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_9F94D16B4CC461A40B8651B8D8899614(FName NotifyName);
    void OnNotifyBegin_9F94D16B4CC461A40B8651B8D8899614(FName NotifyName);
    void OnInterrupted_9F94D16B4CC461A40B8651B8D8899614(FName NotifyName);
    void OnBlendOut_9F94D16B4CC461A40B8651B8D8899614(FName NotifyName);
    void OnCompleted_9F94D16B4CC461A40B8651B8D8899614(FName NotifyName);
    void OnNotifyEnd_F65F6A0E4E3F4CDCBE410A8A04ED2BA5(FName NotifyName);
    void OnNotifyBegin_F65F6A0E4E3F4CDCBE410A8A04ED2BA5(FName NotifyName);
    void OnInterrupted_F65F6A0E4E3F4CDCBE410A8A04ED2BA5(FName NotifyName);
    void OnBlendOut_F65F6A0E4E3F4CDCBE410A8A04ED2BA5(FName NotifyName);
    void OnCompleted_F65F6A0E4E3F4CDCBE410A8A04ED2BA5(FName NotifyName);
    void InpActEvt_IA_HideHud_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_HideHud_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_SprintController_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Reload_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Reload_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ReceiveBeginPlay();
    void ReceivePossessed(class AController* NewController);
    void ReceiveTick(float DeltaSeconds);
    void Attack(bool Lunge, class ABP_FirstPersonCharacter_C* Victim);
    void AttackAll(bool Lunge, class ABP_FirstPersonCharacter_C* Victim);
    void Sprint(bool bool);
    void SprintAll(bool bool);
    void FlameThrowerDamage();
    void FlameThrowerDamageAll();
    void SmellPlayer();
    void StartSmell();
    void Spectate();
    void SpawnSpecator(class AController* Controller);
    void SpawnSpectorMulti(class AController* Controller);
    void MoreDeathFX();
    void BndEvt__BP_ThirdPersonCharacter_Mesh_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void DeathServer(FName Bone Name, FVector Location);
    void DeathAllSkip(FName A, FVector Location);
    void DeathAll();
    void Move();
    void RPCSetLocation(FVector Loc);
    void RPCSetLocationAll(FVector Loc);
    void Finished();
    void ExecuteUbergraph_BP_ThirdPersonCharacter(int32 EntryPoint);
    void CoolDownStarted__DelegateSignature();
    void TakeDamage__DelegateSignature();
}; // Size: 0xAC8

#endif
