#ifndef UE4SS_SDK_FieldNotification_HPP
#define UE4SS_SDK_FieldNotification_HPP

struct FFieldNotificationId
{
    FName FieldName;                                                                  // 0x0000 (size: 0x8)

}; // Size: 0x8

class INotifyFieldValueChanged : public IInterface
{
}; // Size: 0x28

#endif
