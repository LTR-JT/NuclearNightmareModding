namespace ENiagaraRingDiscMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraRingDiscMode_MAX = 2,
    };
}

