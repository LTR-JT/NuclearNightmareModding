#ifndef UE4SS_SDK_BTTask_HuskyInfectedMoveTo_HPP
#define UE4SS_SDK_BTTask_HuskyInfectedMoveTo_HPP

class UBTTask_HuskyInfectedMoveTo_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_D7A9FCDB45EEF19C1A9C01A16B0B676C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_D7A9FCDB45EEF19C1A9C01A16B0B676C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_HuskyInfectedMoveTo(int32 EntryPoint);
}; // Size: 0xB0

#endif
