#ifndef UE4SS_SDK_DaysReached_UI_HPP
#define UE4SS_SDK_DaysReached_UI_HPP

class UDaysReached_UI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UImage* Image_54;                                                           // 0x02F0 (size: 0x8)
    class UTextBlock* TextBlock_33;                                                   // 0x02F8 (size: 0x8)
    int32 DaysElpased;                                                                // 0x0300 (size: 0x4)

    FText GetText();
    void Construct();
    void CustomEvent();
    void ExecuteUbergraph_DaysReached_UI(int32 EntryPoint);
}; // Size: 0x304

#endif
