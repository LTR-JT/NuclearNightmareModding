#ifndef UE4SS_SDK_BFL_Generic_HPP
#define UE4SS_SDK_BFL_Generic_HPP

class UBFL_Generic_C : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void Set Float Precision(double InFloat, int32 Length, class UObject* __WorldContext, FString& Precisioned string);
    void One Minus Integer(int32 X, class UObject* __WorldContext, int32& Return Value);
    void One Minus Float(double X, class UObject* __WorldContext, double& Return Value);
    void Link Input Mapping Context(bool Remove, int32 Priority, class UInputMappingContext* Mapping Context, bool Override Existing Mapping Context, class APlayerController* Player Controller, class UObject* __WorldContext);
    void On Text Changed To Only Numeric(FText Text in, class UObject* __WorldContext, FText& Numeric text only, int32& Int);
    void Does Component contain any of the tags?(class UActorComponent* Component, TArray<FName>& Has one of these tags, class UObject* __WorldContext, bool& Contains Tag);
    void Does actor contain any of the tags?(class AActor* Actor, TArray<FName>& Has one of these tags, class UObject* __WorldContext, bool& Contains Tag);
    void Trace From Active Camera(class APlayerController* Player Controller, TEnumAsByte<ETraceTypeQuery> TraceChannel, const TArray<class AActor*>& ActorsToIgnore, double Front offset start position, double Trace Lenght, TEnumAsByte<EDrawDebugTrace::Type> Draw Debug Type, class UObject* __WorldContext, FHitResult& OutHit, bool& Hit, class AActor*& HitActor, class UPrimitiveComponent*& HitComponent, FVector& Location);
    void chance(double chance, class UObject* __WorldContext, bool& Win, double& Percent);
    void Calculate_Percentage_Text(double Current Value, double Maximum Value, class UObject* __WorldContext, FText& Percentage Text, double& Percentage value);
}; // Size: 0x28

#endif
