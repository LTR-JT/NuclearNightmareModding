#ifndef UE4SS_SDK_BPI_PowerSystem_HPP
#define UE4SS_SDK_BPI_PowerSystem_HPP

class IBPI_PowerSystem_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void CheckActive(bool& Active?, double& Amount);
    void ConsumePower();
}; // Size: 0x28

#endif
