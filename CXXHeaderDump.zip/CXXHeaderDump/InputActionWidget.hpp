#ifndef UE4SS_SDK_InputActionWidget_HPP
#define UE4SS_SDK_InputActionWidget_HPP

class UInputActionWidget_C : public UCommonActionWidget
{
}; // Size: 0x490

#endif
