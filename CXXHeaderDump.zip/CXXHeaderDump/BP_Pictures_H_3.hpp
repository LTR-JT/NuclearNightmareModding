#ifndef UE4SS_SDK_BP_Pictures_H_3_HPP
#define UE4SS_SDK_BP_Pictures_H_3_HPP

class ABP_Pictures_H_3_C : public AActor
{
    class UStaticMeshComponent* SM_Picture_1_1;                                       // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)

}; // Size: 0x2A0

#endif
