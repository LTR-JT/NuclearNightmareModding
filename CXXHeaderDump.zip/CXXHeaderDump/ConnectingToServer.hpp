#ifndef UE4SS_SDK_ConnectingToServer_HPP
#define UE4SS_SDK_ConnectingToServer_HPP

class UConnectingToServer_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* flash;                                                    // 0x02E8 (size: 0x8)
    class UWidgetAnimation* fade;                                                     // 0x02F0 (size: 0x8)
    class UCircularThrobber* CircularThrobber_0;                                      // 0x02F8 (size: 0x8)
    class UImage* Glow;                                                               // 0x0300 (size: 0x8)
    class UImage* Image;                                                              // 0x0308 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0310 (size: 0x8)
    class UImage* SwirlingSmoke;                                                      // 0x0318 (size: 0x8)
    class UImage* SwirlingSmoke_1;                                                    // 0x0320 (size: 0x8)
    class UTextBlock* TextBlock_60;                                                   // 0x0328 (size: 0x8)
    class UVerticalBox* VerticalBox_0;                                                // 0x0330 (size: 0x8)

    void GetClosetGenLocation(FVector Start Location, FString& Location Name);
    void Construct();
    void ExecuteUbergraph_ConnectingToServer(int32 EntryPoint);
}; // Size: 0x338

#endif
