#ifndef UE4SS_SDK_BP_ShowcaseControlsInterface_HPP
#define UE4SS_SDK_BP_ShowcaseControlsInterface_HPP

class IBP_ShowcaseControlsInterface_C : public IInterface
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    void SetButtonsVariable7(int32 NewIndex);
    void SetButtonsVariable6(int32 NewIndex);
    void SetButtonsVariable5(int32 NewIndex);
    void SetButtonsVariable4(int32 NewIndex);
    void SetButtonsVariable3(int32 NewIndex);
    void SetButtonsVariable2(int32 NewIndex);
    void SetButtonsVariable1(int32 NewIndex);
    void SetButtonsVariable0(int32 NewIndex);
    void SetTwinSliderVariable7(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable6(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable5(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable4(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable3(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable2(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable1(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetTwinSliderVariable0(bool bFirstSlider?, double NewFirstValue, double NewSecondValue);
    void SetCheckboxVariable7(bool NewState);
    void SetCheckboxVariable6(bool NewState);
    void SetCheckboxVariable5(bool NewState);
    void SetCheckboxVariable4(bool NewState);
    void SetCheckboxVariable3(bool NewState);
    void SetCheckboxVariable2(bool NewState);
    void SetSliderVariable7(double NewValue);
    void SetSliderVariable6(double NewValue);
    void SetSliderVariable5(double NewValue);
    void SetSliderVariable4(double NewValue);
    void SetSliderVariable3(double NewValue);
    void SetSliderVariable2(double NewValue);
    void SetSliderVariable1(double NewValue);
    void SetSliderVariable0(double NewValue);
    void SetCheckboxVariable1(bool NewState);
    void SetCheckboxVariable0(bool NewState);
}; // Size: 0x28

#endif
