namespace ENiagaraChannelCorrelation {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraChannelCorrelation_MAX = 3,
    };
}

