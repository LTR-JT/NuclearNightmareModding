#ifndef UE4SS_SDK_HUDIconBase_HPP
#define UE4SS_SDK_HUDIconBase_HPP

class UHUDIconBase_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UTextBlock* ButtonText;                                                     // 0x02E8 (size: 0x8)
    class UImage* IconImage;                                                          // 0x02F0 (size: 0x8)
    class UTexture2D* Icon;                                                           // 0x02F8 (size: 0x8)

    void PreConstruct(bool IsDesignTime);
    void ExecuteUbergraph_HUDIconBase(int32 EntryPoint);
}; // Size: 0x300

#endif
