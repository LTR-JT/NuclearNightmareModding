#ifndef UE4SS_SDK_BP_ButtonStyle_Basic_HPP
#define UE4SS_SDK_BP_ButtonStyle_Basic_HPP

class UBP_ButtonStyle_Basic_C : public UBP_ButtonStyle_Master_C
{
}; // Size: 0x7B0

#endif
