#ifndef UE4SS_SDK_FriendsList_Item_HPP
#define UE4SS_SDK_FriendsList_Item_HPP

class UFriendsList_Item_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Create;                                                            // 0x02E8 (size: 0x8)
    class UImage* I_Avatar;                                                           // 0x02F0 (size: 0x8)
    class UTextBlock* T_PlayerName;                                                   // 0x02F8 (size: 0x8)
    class UTextBlock* T_PlayerName_1;                                                 // 0x0300 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_0;                                          // 0x0308 (size: 0x8)
    FBPFriendInfo FriendData;                                                         // 0x0310 (size: 0x68)
    FLinearColor Specified Color;                                                     // 0x0378 (size: 0x10)
    bool Succed;                                                                      // 0x0388 (size: 0x1)

    FSlateColor Get_T_PlayerName_1_ColorAndOpacity();
    FText Get_T_PlayerName_1_Text();
    void UpdateData(FBPFriendInfo FriendData);
    void BndEvt__FriendsList_Item_Create_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_FriendsList_Item(int32 EntryPoint);
}; // Size: 0x389

#endif
