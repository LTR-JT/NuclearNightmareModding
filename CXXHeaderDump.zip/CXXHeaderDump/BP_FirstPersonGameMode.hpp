#ifndef UE4SS_SDK_BP_FirstPersonGameMode_HPP
#define UE4SS_SDK_BP_FirstPersonGameMode_HPP

class ABP_FirstPersonGameMode_C : public ANuclearNightmareGameMode
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0330 (size: 0x8)
    TArray<class APlayerController*> AllPCs;                                          // 0x0338 (size: 0x10)
    TArray<class ALobbyPlayerPlatform_C*> PlayerPlatforms;                            // 0x0348 (size: 0x10)
    bool bPlatformsSetupDone;                                                         // 0x0358 (size: 0x1)
    bool InMainMenu;                                                                  // 0x0359 (size: 0x1)
    int32 CurrentPlayers;                                                             // 0x035C (size: 0x4)
    int32 PCIndex;                                                                    // 0x0360 (size: 0x4)
    int32 ReturnedKey;                                                                // 0x0364 (size: 0x4)

    void RetryGame();
    class AActor* ChoosePlayerStart(class AController* Player);
    void UpdatePlayersOnPlatforms();
    void SetUpPlatforms();
    void SpawnPlayer(class APlayerController* PlayerController);
    FTransform FindRandomPlayerStart();
    void OnFailure_85983DF8489082316B193CA9135EE825();
    void OnSuccess_85983DF8489082316B193CA9135EE825();
    void K2_PostLogin(class APlayerController* NewPlayer);
    void K2_OnSwapPlayerControllers(class APlayerController* OldPC, class APlayerController* NewPC);
    void K2_OnLogout(class AController* ExitingController);
    void ReceiveBeginPlay();
    void ServerTravelToMap(FString URL);
    void UpdateMovement(class ABP_FirstPersonCharacter_C* Character);
    void CallRetryGame();
    void HostLeave();
    void HostLeaveAll();
    void StartedMatch();
    void RequestedReplay();
    void ExecuteUbergraph_BP_FirstPersonGameMode(int32 EntryPoint);
}; // Size: 0x368

#endif
