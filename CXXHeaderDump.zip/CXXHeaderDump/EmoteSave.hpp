#ifndef UE4SS_SDK_EmoteSave_HPP
#define UE4SS_SDK_EmoteSave_HPP

class UEmoteSave_C : public USaveGame
{
    TArray<FSEmote> Emotes;                                                           // 0x0028 (size: 0x10)

}; // Size: 0x38

#endif
