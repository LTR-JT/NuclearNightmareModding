#ifndef UE4SS_SDK_BP_Snowmobile_HPP
#define UE4SS_SDK_BP_Snowmobile_HPP

class ABP_Snowmobile_C : public ADeformingWheeledVehiclePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)
    class UOnsetNameplateComponent* OnsetNameplate;                                   // 0x0340 (size: 0x8)
    class UOnsetVoipAudioComponent* OnsetVoipAudio;                                   // 0x0348 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem2;                                  // 0x0350 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem1;                                  // 0x0358 (size: 0x8)
    class UNiagaraComponent* NS_Signal_Mini_Smoke_Grey;                               // 0x0360 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0368 (size: 0x8)
    class UStaticMeshComponent* Rocket_EngineUE;                                      // 0x0370 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x0378 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction2;                                     // 0x0380 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0388 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0390 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0398 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x03A0 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x03A8 (size: 0x8)
    class UAudioComponent* EngineSound;                                               // 0x03B0 (size: 0x8)
    class UParticleSystemComponent* P_dirt_wheel_kickup;                              // 0x03B8 (size: 0x8)
    class UCameraComponent* FrontCamera;                                              // 0x03C0 (size: 0x8)
    class USpringArmComponent* SpringArm1;                                            // 0x03C8 (size: 0x8)
    class UCameraComponent* BackCamera;                                               // 0x03D0 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x03D8 (size: 0x8)
    class UChaosWheeledVehicleMovementComponent* Chaos Wheeled Vehicle Movement Component; // 0x03E0 (size: 0x8)
    double CmPerV;                                                                    // 0x03E8 (size: 0x8)
    double TrackOffset;                                                               // 0x03F0 (size: 0x8)
    class UMaterialInstanceDynamic* Tread;                                            // 0x03F8 (size: 0x8)
    class UMaterialInstanceDynamic* Lights;                                           // 0x0400 (size: 0x8)
    double RotatorBp;                                                                 // 0x0408 (size: 0x8)
    bool InCarView;                                                                   // 0x0410 (size: 0x1)
    char padding_0[0x7];                                                              // 0x0411 (size: 0x7)
    class ABP_FirstPersonCharacter_C* DriverCharacter;                                // 0x0418 (size: 0x8)
    TArray<FName> AllSitSockets;                                                      // 0x0420 (size: 0x10)
    class ABP_FirstPersonCharacter_C* PassengerCharacter;                             // 0x0430 (size: 0x8)
    TArray<FName> AllExitSockets;                                                     // 0x0438 (size: 0x10)
    bool Driver;                                                                      // 0x0448 (size: 0x1)
    bool Passenger;                                                                   // 0x0449 (size: 0x1)
    bool IsBrakeEnabled;                                                              // 0x044A (size: 0x1)
    char padding_1[0x5];                                                              // 0x044B (size: 0x5)
    TArray<class UMaterialInstanceDynamic*> BrakeLightsMaterialInstances;             // 0x0450 (size: 0x10)
    FTimerHandle Handle_Engine_audio;                                                 // 0x0460 (size: 0x8)
    double Forward_Speed;                                                             // 0x0468 (size: 0x8)
    FVector Event_Hit_location;                                                       // 0x0470 (size: 0x18)
    FName hit_bone_name;                                                              // 0x0488 (size: 0x8)
    class UPrimitiveComponent* Hit_component;                                         // 0x0490 (size: 0x8)
    double Max_velocity_MAX;                                                          // 0x0498 (size: 0x8)
    float Speed;                                                                      // 0x04A0 (size: 0x4)
    bool RagdollCharacter;                                                            // 0x04A4 (size: 0x1)
    char padding_2[0x3];                                                              // 0x04A5 (size: 0x3)
    double Fuel;                                                                      // 0x04A8 (size: 0x8)
    bool EngineON;                                                                    // 0x04B0 (size: 0x1)
    bool NeedsToSpawn;                                                                // 0x04B1 (size: 0x1)
    char padding_3[0x6];                                                              // 0x04B2 (size: 0x6)
    FBP_Snowmobile_CGotInVechile GotInVechile;                                        // 0x04B8 (size: 0x10)
    void GotInVechile(double Fuel);
    double OverallDamage;                                                             // 0x04C8 (size: 0x8)
    bool GlassBroken;                                                                 // 0x04D0 (size: 0x1)
    bool Destroyed;                                                                   // 0x04D1 (size: 0x1)
    char padding_4[0x6];                                                              // 0x04D2 (size: 0x6)
    class UJournal_C* Map;                                                            // 0x04D8 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void ExitVehicle(class ABP_FirstPersonCharacter_C* Character);
    void EnterVehicle(class ABP_FirstPersonCharacter_C* Character);
    void OnRep_IsBrakeEnabled();
    bool CheckDriverSocket(class ABP_FirstPersonCharacter_C*& Character);
    bool CheckGunnerSocket(class ABP_FirstPersonCharacter_C*& Character);
    bool FindExitSocket(FVector& LeaveLocation);
    void Enter/ExitVehicle(class ABP_FirstPersonCharacter_C* Character);
    void ChangeCamera();
    void UpdateTrack();
    void UserConstructionScript();
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraToggle_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Notebook_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Map_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Igniton_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void SetNameplatePlayerName(FString PlayerName);
    void SetOwningPlayerState(class APlayerState* PlayerState);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void RPC Enter/Exit Vehicle "Multicast"(class ABP_FirstPersonCharacter_C* Character);
    void RPC Enter/Exit Vehicle "Server"(class ABP_FirstPersonCharacter_C* Character);
    void SwitchCamera();
    void ReceivePossessed(class AController* NewController);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void CE Engine audio();
    void ReceiveHit(class UPrimitiveComponent* MyComp, class AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit);
    void EngineAudioServer();
    void EngineAudoMulti();
    void MulticastEngineSound();
    void ServerEngineSound();
    void TurnOn/OffEngine(bool Off?);
    void TurnOn/OffMulticast(bool Off?);
    void Drown();
    void DrownMulti();
    void DeSpawn();
    void DespawnMulti();
    void SetFuelLevel();
    void SetFuelLevelMulti(double Amount);
    void UpdateThrottleServer(double Throttle, double Brake);
    void RPCExitVehicle(class ABP_FirstPersonCharacter_C* Character);
    void RPCExitVehicleALL(class ABP_FirstPersonCharacter_C* Character);
    void RPCEnterVehicle(class ABP_FirstPersonCharacter_C* Character);
    void RPCEnterVehicleMulti(class ABP_FirstPersonCharacter_C* Character);
    void Steer(double Speed, double Brake Left, double Brake Right, double Wheels);
    void EnableBoost();
    void EnableBoostServer();
    void BoostSpeedDemon(double Input, FVector A);
    void BoostSpeedDemonServer(double Speed, FVector A);
    void KickOfSnowmobile();
    void KOSS();
    void ExecHideFaceClient();
    void HideFServer();
    void Add/RemoveVehicleChannel(class APlayerState* PlayerState, bool bAdd);
    void SetNameplateSpeaking(bool bIsSpeaking);
    void WheelsRotator(double Axis);
    void Lightsinonclient();
    void LightsonServer();
    void ExecuteUbergraph_BP_Snowmobile(int32 EntryPoint);
    void GotInVechile__DelegateSignature(double Fuel);
}; // Size: 0x4E0

#endif
