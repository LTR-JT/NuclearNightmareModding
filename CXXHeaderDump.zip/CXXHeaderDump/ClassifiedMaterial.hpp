#ifndef UE4SS_SDK_ClassifiedMaterial_HPP
#define UE4SS_SDK_ClassifiedMaterial_HPP

class UClassifiedMaterial_C : public UUserWidget
{
    class UImage* Image;                                                              // 0x02E0 (size: 0x8)
    class UImage* Image_38;                                                           // 0x02E8 (size: 0x8)

}; // Size: 0x2F0

#endif
