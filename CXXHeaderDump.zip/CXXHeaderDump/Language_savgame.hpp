#ifndef UE4SS_SDK_Language_savgame_HPP
#define UE4SS_SDK_Language_savgame_HPP

class ULanguage_savgame_C : public USaveGame
{
    FString Language;                                                                 // 0x0028 (size: 0x10)

}; // Size: 0x38

#endif
