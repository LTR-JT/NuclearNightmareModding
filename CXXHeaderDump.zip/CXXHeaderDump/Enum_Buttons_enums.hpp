namespace Enum_Buttons {
    enum Type {
        NewEnumerator3 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator4 = 4,
        NewEnumerator5 = 5,
        NewEnumerator6 = 6,
        Enum_MAX = 7,
    };
}

