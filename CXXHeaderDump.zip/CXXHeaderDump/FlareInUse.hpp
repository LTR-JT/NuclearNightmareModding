#ifndef UE4SS_SDK_FlareInUse_HPP
#define UE4SS_SDK_FlareInUse_HPP

class AFlareInUse_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNiagaraComponent* NS_Signal_Flare_Red1;                                    // 0x0298 (size: 0x8)
    class UNiagaraComponent* NS_Signal_Flare_Red;                                     // 0x02A0 (size: 0x8)
    class UAudioComponent* Flare_Loop;                                                // 0x02A8 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x02B0 (size: 0x8)
    class UParticleSystemComponent* P_Flare_Flame;                                    // 0x02B8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x02C0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02C8 (size: 0x8)
    float Timeline_NewTrack_0_B6AA4D7A4E156ADD12394B88A54DA971;                       // 0x02D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_B6AA4D7A4E156ADD12394B88A54DA971; // 0x02D4 (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02D8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02E0 (size: 0x8)
    bool Out;                                                                         // 0x02E8 (size: 0x1)

    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_FlareInUse(int32 EntryPoint);
}; // Size: 0x2E9

#endif
