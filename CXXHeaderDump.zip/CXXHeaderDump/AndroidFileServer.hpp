#ifndef UE4SS_SDK_AndroidFileServer_HPP
#define UE4SS_SDK_AndroidFileServer_HPP

#include "AndroidFileServer_enums.hpp"

class UAndroidFileServerBPLibrary : public UBlueprintFunctionLibrary
{
    char padding_0[0x28];                                                             // 0x0000 (size: 0x0)

    bool StopFileServer(bool bUSB, bool bNetwork);
    bool StartFileServer(bool bUSB, bool bNetwork, int32 Port);
    TEnumAsByte<EAFSActiveType::Type> IsFileServerRunning();
}; // Size: 0x28

#endif
