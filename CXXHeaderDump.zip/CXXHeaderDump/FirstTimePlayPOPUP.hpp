#ifndef UE4SS_SDK_FirstTimePlayPOPUP_HPP
#define UE4SS_SDK_FirstTimePlayPOPUP_HPP

class UFirstTimePlayPOPUP_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UBorder* Border_4;                                                          // 0x02E8 (size: 0x8)
    class UClassifiedMaterial_C* ClassifiedMaterial;                                  // 0x02F0 (size: 0x8)
    class UFlareUI_C* FlareUI;                                                        // 0x02F8 (size: 0x8)
    class UHelicopterUI_C* HelicopterUI;                                              // 0x0300 (size: 0x8)
    class UHuskyUI_C* HuskyUI;                                                        // 0x0308 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0310 (size: 0x8)
    class UImage* Image_62;                                                           // 0x0318 (size: 0x8)
    class ULevelLocationUI_C* LevelLocationUI;                                        // 0x0320 (size: 0x8)
    class USateliteUI_C* SateliteUI;                                                  // 0x0328 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master;                                      // 0x0330 (size: 0x8)
    class UWaypoint_C* Waypoint;                                                      // 0x0338 (size: 0x8)
    FFirstTimePlayPOPUP_CClose Close;                                                 // 0x0340 (size: 0x10)
    void Close();

    FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent);
    FEventReply OnMouseButtonDown(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    void BndEvt__PlayerControlsPopUp_UI_Button_Master_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void ExecuteUbergraph_FirstTimePlayPOPUP(int32 EntryPoint);
    void Close__DelegateSignature();
}; // Size: 0x350

#endif
