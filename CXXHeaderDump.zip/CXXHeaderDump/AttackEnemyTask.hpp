#ifndef UE4SS_SDK_AttackEnemyTask_HPP
#define UE4SS_SDK_AttackEnemyTask_HPP

class UAttackEnemyTask_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    FBlackboardKeySelector bool;                                                      // 0x00D8 (size: 0x28)

    void OnFail_BD0ACB8B4E5D8C43D347EFB21F12D650(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_BD0ACB8B4E5D8C43D347EFB21F12D650(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_AttackEnemyTask(int32 EntryPoint);
}; // Size: 0x100

#endif
