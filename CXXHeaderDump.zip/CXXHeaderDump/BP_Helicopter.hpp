#ifndef UE4SS_SDK_BP_Helicopter_HPP
#define UE4SS_SDK_BP_Helicopter_HPP

class ABP_Helicopter_C : public ADeformingWheeledVehiclePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0338 (size: 0x8)
    class UCapsuleComponent* Pass2Exit;                                               // 0x0340 (size: 0x8)
    class UCapsuleComponent* Pass1Exit;                                               // 0x0348 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x0350 (size: 0x8)
    class UStaticMeshComponent* Dashboard_Screen;                                     // 0x0358 (size: 0x8)
    class UOnsetNameplateComponent* OnsetNameplate;                                   // 0x0360 (size: 0x8)
    class UOnsetVoipAudioComponent* OnsetVoipAudio;                                   // 0x0368 (size: 0x8)
    class UNiagaraComponent* Niagara1;                                                // 0x0370 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0378 (size: 0x8)
    class UParticleSystemComponent* P_Fire_Wall1;                                     // 0x0380 (size: 0x8)
    class UParticleSystemComponent* P_Explosion_Smoke;                                // 0x0388 (size: 0x8)
    class UAudioComponent* helicopter-loop1;                                          // 0x0390 (size: 0x8)
    class UWidgetComponent* Widget2;                                                  // 0x0398 (size: 0x8)
    class UWidgetComponent* Widget1;                                                  // 0x03A0 (size: 0x8)
    class USceneCaptureComponent2D* SceneCaptureComponent2D;                          // 0x03A8 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x03B0 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x03B8 (size: 0x8)
    class USpotLightComponent* SpotLight1;                                            // 0x03C0 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x03C8 (size: 0x8)
    class UNiagaraComponent* NS_Explosion_Big_1;                                      // 0x03D0 (size: 0x8)
    class UAudioComponent* helicopter-loop;                                           // 0x03D8 (size: 0x8)
    class UCameraComponent* FPCamera1;                                                // 0x03E0 (size: 0x8)
    class USpringArmComponent* SpringArm1;                                            // 0x03E8 (size: 0x8)
    class UCameraComponent* FPCamera;                                                 // 0x03F0 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x03F8 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x0400 (size: 0x8)
    float Timeline_0_NewTrack_0_1D0C31F24669981F61FA58AA626F9CBB;                     // 0x0408 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_1D0C31F24669981F61FA58AA626F9CBB; // 0x040C (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0410 (size: 0x8)
    float Timeline_NewTrack_0_E7D5199D4EF5CCF9AD475DBE76F59C63;                       // 0x0418 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_E7D5199D4EF5CCF9AD475DBE76F59C63; // 0x041C (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x0420 (size: 0x8)
    double AxisY;                                                                     // 0x0428 (size: 0x8)
    double Height;                                                                    // 0x0430 (size: 0x8)
    float RotorSpeed;                                                                 // 0x0438 (size: 0x4)
    double Action Value X;                                                            // 0x0440 (size: 0x8)
    bool EnableAutoRoll;                                                              // 0x0448 (size: 0x1)
    float EngineIdle;                                                                 // 0x044C (size: 0x4)
    bool EngineStart;                                                                 // 0x0450 (size: 0x1)
    bool EngineOn;                                                                    // 0x0451 (size: 0x1)
    FVector Event_Hit_location;                                                       // 0x0458 (size: 0x18)
    FName hit_bone_name;                                                              // 0x0470 (size: 0x8)
    class UPrimitiveComponent* Hit_component;                                         // 0x0478 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Driver;                                         // 0x0480 (size: 0x8)
    bool EngineDead;                                                                  // 0x0488 (size: 0x1)
    double Fuel;                                                                      // 0x0490 (size: 0x8)
    bool Destroyed;                                                                   // 0x0498 (size: 0x1)
    class UHelicopterFuelPublic_C* FuelHud;                                           // 0x04A0 (size: 0x8)
    bool Shift;                                                                       // 0x04A8 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Passenger1;                                     // 0x04B0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger2;                                     // 0x04B8 (size: 0x8)
    bool AlwaysSpawn;                                                                 // 0x04C0 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Passenger3;                                     // 0x04C8 (size: 0x8)
    double Throttle;                                                                  // 0x04D0 (size: 0x8)
    bool EngineDestroyed;                                                             // 0x04D8 (size: 0x1)
    double LocalValue;                                                                // 0x04E0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Passenger4;                                     // 0x04E8 (size: 0x8)
    FBP_Helicopter_CMasterWarning MasterWarning;                                      // 0x04F0 (size: 0x10)
    void MasterWarning(bool Cleared);
    class UJournal_C* Map;                                                            // 0x0500 (size: 0x8)
    class UMaterialInstanceDynamic* DynamicExternalMaterial;                          // 0x0508 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_12(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_11(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_CameraToggle_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Igniton_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_48B54A0C4678F33915CE1BB80F92AA7D(FName NotifyName);
    void OnNotifyBegin_48B54A0C4678F33915CE1BB80F92AA7D(FName NotifyName);
    void OnInterrupted_48B54A0C4678F33915CE1BB80F92AA7D(FName NotifyName);
    void OnBlendOut_48B54A0C4678F33915CE1BB80F92AA7D(FName NotifyName);
    void OnCompleted_48B54A0C4678F33915CE1BB80F92AA7D(FName NotifyName);
    void InpActEvt_IA_Interact_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_89CCB2134865C8A198D827835019B162(FName NotifyName);
    void OnNotifyBegin_89CCB2134865C8A198D827835019B162(FName NotifyName);
    void OnInterrupted_89CCB2134865C8A198D827835019B162(FName NotifyName);
    void OnBlendOut_89CCB2134865C8A198D827835019B162(FName NotifyName);
    void OnCompleted_89CCB2134865C8A198D827835019B162(FName NotifyName);
    void OnNotifyEnd_F636108D4CFFDD9C1C1D2AAA248D503C(FName NotifyName);
    void OnNotifyBegin_F636108D4CFFDD9C1C1D2AAA248D503C(FName NotifyName);
    void OnInterrupted_F636108D4CFFDD9C1C1D2AAA248D503C(FName NotifyName);
    void OnBlendOut_F636108D4CFFDD9C1C1D2AAA248D503C(FName NotifyName);
    void OnCompleted_F636108D4CFFDD9C1C1D2AAA248D503C(FName NotifyName);
    void InpActEvt_IA_Notebook_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Map_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Flashlight_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Sprint_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Sprint_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_HideHud_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void OnNotifyEnd_628A00D3460D07D26586AB9E8D995CA3(FName NotifyName);
    void OnNotifyBegin_628A00D3460D07D26586AB9E8D995CA3(FName NotifyName);
    void OnInterrupted_628A00D3460D07D26586AB9E8D995CA3(FName NotifyName);
    void OnBlendOut_628A00D3460D07D26586AB9E8D995CA3(FName NotifyName);
    void OnCompleted_628A00D3460D07D26586AB9E8D995CA3(FName NotifyName);
    void OnNotifyEnd_C71ECFC74BE6BEF4E1F47FA8006BF5AC(FName NotifyName);
    void OnNotifyBegin_C71ECFC74BE6BEF4E1F47FA8006BF5AC(FName NotifyName);
    void OnInterrupted_C71ECFC74BE6BEF4E1F47FA8006BF5AC(FName NotifyName);
    void OnBlendOut_C71ECFC74BE6BEF4E1F47FA8006BF5AC(FName NotifyName);
    void OnCompleted_C71ECFC74BE6BEF4E1F47FA8006BF5AC(FName NotifyName);
    void OnNotifyEnd_BDFA51824F5F13A3F325589A6E99F73E(FName NotifyName);
    void OnNotifyBegin_BDFA51824F5F13A3F325589A6E99F73E(FName NotifyName);
    void OnInterrupted_BDFA51824F5F13A3F325589A6E99F73E(FName NotifyName);
    void OnBlendOut_BDFA51824F5F13A3F325589A6E99F73E(FName NotifyName);
    void OnCompleted_BDFA51824F5F13A3F325589A6E99F73E(FName NotifyName);
    void OnNotifyEnd_35F49CF54218F3766ADA32B022E859C5(FName NotifyName);
    void OnNotifyBegin_35F49CF54218F3766ADA32B022E859C5(FName NotifyName);
    void OnInterrupted_35F49CF54218F3766ADA32B022E859C5(FName NotifyName);
    void OnBlendOut_35F49CF54218F3766ADA32B022E859C5(FName NotifyName);
    void OnCompleted_35F49CF54218F3766ADA32B022E859C5(FName NotifyName);
    void OnNotifyEnd_9B22BD9049CA146D3739C8B008EC05F4(FName NotifyName);
    void OnNotifyBegin_9B22BD9049CA146D3739C8B008EC05F4(FName NotifyName);
    void OnInterrupted_9B22BD9049CA146D3739C8B008EC05F4(FName NotifyName);
    void OnBlendOut_9B22BD9049CA146D3739C8B008EC05F4(FName NotifyName);
    void OnCompleted_9B22BD9049CA146D3739C8B008EC05F4(FName NotifyName);
    void OnNotifyEnd_4A3099744CD67D960E5DEB917AD67A72(FName NotifyName);
    void OnNotifyBegin_4A3099744CD67D960E5DEB917AD67A72(FName NotifyName);
    void OnInterrupted_4A3099744CD67D960E5DEB917AD67A72(FName NotifyName);
    void OnBlendOut_4A3099744CD67D960E5DEB917AD67A72(FName NotifyName);
    void OnCompleted_4A3099744CD67D960E5DEB917AD67A72(FName NotifyName);
    void OnNotifyEnd_CD54ADCA49FD070A6E744DB5F5B696CD(FName NotifyName);
    void OnNotifyBegin_CD54ADCA49FD070A6E744DB5F5B696CD(FName NotifyName);
    void OnInterrupted_CD54ADCA49FD070A6E744DB5F5B696CD(FName NotifyName);
    void OnBlendOut_CD54ADCA49FD070A6E744DB5F5B696CD(FName NotifyName);
    void OnCompleted_CD54ADCA49FD070A6E744DB5F5B696CD(FName NotifyName);
    void OnNotifyEnd_CE10C2944EF3249DD9E331AB628777B6(FName NotifyName);
    void OnNotifyBegin_CE10C2944EF3249DD9E331AB628777B6(FName NotifyName);
    void OnInterrupted_CE10C2944EF3249DD9E331AB628777B6(FName NotifyName);
    void OnBlendOut_CE10C2944EF3249DD9E331AB628777B6(FName NotifyName);
    void OnCompleted_CE10C2944EF3249DD9E331AB628777B6(FName NotifyName);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void SetNameplatePlayerName(FString PlayerName);
    void SetOwningPlayerState(class APlayerState* PlayerState);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void ReceivePossessed(class AController* NewController);
    void ReceiveTick(float DeltaSeconds);
    void BndEvt__BP_Helicopter_Mesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(class UPrimitiveComponent* HitComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void KillPilot();
    void StartPilotDeath();
    void UpdateThrottleServer(float Throttle);
    void PilotExit(double Fuel);
    void ExecPilotExit(double Fuel);
    void UpdateThrottleAll(float Throttle);
    void LightsonServer();
    void Lightsinonclient();
    void TurnLightsOnServer();
    void KillEngine();
    void KillEngineServer();
    void SetFuelLevel();
    void SetFuelLevelAll(double Fuel);
    void ReceiveBeginPlay();
    void PassengerExitServer();
    void PassengerExitAll();
    void ResetPassengerEntrance();
    void RandomSpawn();
    void DespawnOnAll();
    void ResetPass2Entry();
    void ResetPassenger3Entry();
    void Update Fuel(double Fuel);
    void Update FuelALL(double Fuel);
    void UpdateIgnition(bool EngineOn);
    void UpdateIgnitionAll(bool EngineOn);
    void IgnitionToggle();
    void ParkHeli();
    void PlaySoundServer();
    void PlaySoundAll();
    void RPCCockpitSound(class USoundBase* Sound);
    void RpcCockpitSoundAll(class USoundBase* Sound);
    void KillEngineRotorDeath();
    void KillEngineRotorServer();
    void UpdateDeviceScreen();
    void UpdatePass4Entry();
    void SetNameplateSpeaking(bool bIsSpeaking);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void ExecuteUbergraph_BP_Helicopter(int32 EntryPoint);
    void MasterWarning__DelegateSignature(bool Cleared);
}; // Size: 0x510

#endif
