#ifndef UE4SS_SDK_MaterialObjective_HPP
#define UE4SS_SDK_MaterialObjective_HPP

class UMaterialObjective_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UModular_ObjectiveComplete_C* Modular_ObjectiveComplete;                    // 0x02E8 (size: 0x8)
    class UObject* Avatar;                                                            // 0x02F0 (size: 0x8)
    FString UserName;                                                                 // 0x02F8 (size: 0x10)
    int32 MaterialAt;                                                                 // 0x0308 (size: 0x4)
    int32 OutOf;                                                                      // 0x030C (size: 0x4)
    FText Text;                                                                       // 0x0310 (size: 0x10)
    FText Text_0;                                                                     // 0x0320 (size: 0x10)

    void Construct();
    void ExecuteUbergraph_MaterialObjective(int32 EntryPoint);
}; // Size: 0x330

#endif
