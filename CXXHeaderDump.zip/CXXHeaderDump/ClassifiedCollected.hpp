#ifndef UE4SS_SDK_ClassifiedCollected_HPP
#define UE4SS_SDK_ClassifiedCollected_HPP

class UClassifiedCollected_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UScrollBox* GraphicsScroll;                                                 // 0x02E8 (size: 0x8)
    class UHorizontalBox* HorizontalBox_84;                                           // 0x02F0 (size: 0x8)
    class UTextBlock* Shadow_1;                                                       // 0x02F8 (size: 0x8)
    class UTextBlock* Shadow_3;                                                       // 0x0300 (size: 0x8)
    class UTextBlock* Shadow_5;                                                       // 0x0308 (size: 0x8)
    class UTextBlock* Shadow_8;                                                       // 0x0310 (size: 0x8)
    class UTextBlock* Shadow_9;                                                       // 0x0318 (size: 0x8)
    class UVerticalBox* VerticalBox_0;                                                // 0x0320 (size: 0x8)
    FLinearColor Specified Color;                                                     // 0x0328 (size: 0x10)
    int32 TimesInfected;                                                              // 0x0338 (size: 0x4)
    int32 Points Added in Game;                                                       // 0x033C (size: 0x4)
    double AmountOfPoints;                                                            // 0x0340 (size: 0x8)

    FText Get_shadow_9_Text();
    FText Get_shadow_8_Text();
    FText Get_shadow_5_Text();
    FText Get_shadow_3_Text();
    FSlateColor Get_shadow_1_ColorAndOpacity();
    FText Get_shadow_1_Text();
    void PreConstruct(bool IsDesignTime);
    void Construct();
    void Tick(FGeometry MyGeometry, float InDeltaTime);
    void ExecuteUbergraph_ClassifiedCollected(int32 EntryPoint);
}; // Size: 0x348

#endif
