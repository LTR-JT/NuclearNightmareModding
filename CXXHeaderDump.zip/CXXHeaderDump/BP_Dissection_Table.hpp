#ifndef UE4SS_SDK_BP_Dissection_Table_HPP
#define UE4SS_SDK_BP_Dissection_Table_HPP

class ABP_Dissection_Table_C : public AActor
{
    class UStaticMeshComponent* SM_Hose;                                              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Wheel_4;                                              // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_4;                                      // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Wheel_3;                                              // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_3;                                      // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Wheel_2;                                              // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_2;                                      // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Wheel_1;                                              // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Wheel_element_1;                                      // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_Bucket_handle;                                     // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* SM_Bucket_body;                                       // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* SM_Dissection_Table_handle;                           // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* SM_Dissection_Table_cap_2;                            // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* SM_Dissection_Table_cap_1;                            // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* SM_Dissection_Table_body;                             // 0x0300 (size: 0x8)
    class UStaticMeshComponent* SM_Dissection_Table_legs;                             // 0x0308 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0310 (size: 0x8)

}; // Size: 0x318

#endif
