#ifndef UE4SS_SDK_BP_OpenLand_RVT_Volume_Material_HPP
#define UE4SS_SDK_BP_OpenLand_RVT_Volume_Material_HPP

class ABP_OpenLand_RVT_Volume_Material_C : public ARuntimeVirtualTextureVolume
{
    char padding_0[0x298];                                                            // 0x0000 (size: 0x0)
}; // Size: 0x298

#endif
