#ifndef UE4SS_SDK_BP_OpenLand_RVT_Volume_Material_HPP
#define UE4SS_SDK_BP_OpenLand_RVT_Volume_Material_HPP

class ABP_OpenLand_RVT_Volume_Material_C : public ARuntimeVirtualTextureVolume
{
}; // Size: 0x298

#endif
