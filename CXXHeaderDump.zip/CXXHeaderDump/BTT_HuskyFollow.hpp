#ifndef UE4SS_SDK_BTT_HuskyFollow_HPP
#define UE4SS_SDK_BTT_HuskyFollow_HPP

class UBTT_HuskyFollow_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void OnFail_798E0980404BC5096EC3D6914FC61226(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_798E0980404BC5096EC3D6914FC61226(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_FF6FE2B64243C872E87D469AD4109FDC(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_FF6FE2B64243C872E87D469AD4109FDC(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_HuskyFollow(int32 EntryPoint);
}; // Size: 0xB0

#endif
