enum class ESplineType {
    BSpline = 0,
    Hermite = 1,
    Max = 2,
};

