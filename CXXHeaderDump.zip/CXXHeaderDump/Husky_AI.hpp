#ifndef UE4SS_SDK_Husky_AI_HPP
#define UE4SS_SDK_Husky_AI_HPP

class AHusky_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UStaticMeshComponent* head_idle_STATIC;                                     // 0x0678 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0680 (size: 0x8)
    class UNavigationInvokerComponent* NavigationInvoker;                             // 0x0688 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0690 (size: 0x8)
    class USphereComponent* Sphere1;                                                  // 0x0698 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x06A0 (size: 0x8)
    float Timeline_1_NewTrack_0_6F8C2CA8404038AE9BD367A62FCF7F15;                     // 0x06A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_6F8C2CA8404038AE9BD367A62FCF7F15; // 0x06AC (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x06B0 (size: 0x8)
    float Timeline_0_NewTrack_0_8F802CB043E7BEC850ECDD90ACD8B38A;                     // 0x06B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_8F802CB043E7BEC850ECDD90ACD8B38A; // 0x06BC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x06C0 (size: 0x8)
    float Timeline_NewTrack_0_1C1D89BF429EBF55AA85D9851F635C83;                       // 0x06C8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_1C1D89BF429EBF55AA85D9851F635C83; // 0x06CC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x06D0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* DogOwnerCharacter;                              // 0x06D8 (size: 0x8)
    TEnumAsByte<HuskyState::Type> State;                                              // 0x06E0 (size: 0x1)
    TEnumAsByte<HuskyBehavior::Type> Behavior;                                        // 0x06E1 (size: 0x1)
    class ABP_FirstPersonCharacter_C* OverlappedPlayer;                               // 0x06E8 (size: 0x8)
    bool RunAway;                                                                     // 0x06F0 (size: 0x1)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x06F8 (size: 0x10)
    bool DeSpawn;                                                                     // 0x0708 (size: 0x1)
    bool despawn2;                                                                    // 0x0709 (size: 0x1)
    class UMaterialInstanceDynamic* Material;                                         // 0x0710 (size: 0x8)
    bool Infected;                                                                    // 0x0718 (size: 0x1)
    bool IsInfected;                                                                  // 0x0719 (size: 0x1)
    bool OpeningDoor;                                                                 // 0x071A (size: 0x1)
    class UStaticMeshComponent* Door;                                                 // 0x0720 (size: 0x8)
    bool SetBarking;                                                                  // 0x0728 (size: 0x1)
    bool Dead?;                                                                       // 0x0729 (size: 0x1)
    class AItemActor* ItemActor;                                                      // 0x0730 (size: 0x8)
    TArray<class AItemActor*> PickedUpItems;                                          // 0x0738 (size: 0x10)
    class UHuskyInteract_C* HuskyHUD;                                                 // 0x0748 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void UpdateBasedOnGround();
    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void OnNotifyEnd_EE8DC77045518B8C7AC12A9B041E4FB3(FName NotifyName);
    void OnNotifyBegin_EE8DC77045518B8C7AC12A9B041E4FB3(FName NotifyName);
    void OnInterrupted_EE8DC77045518B8C7AC12A9B041E4FB3(FName NotifyName);
    void OnBlendOut_EE8DC77045518B8C7AC12A9B041E4FB3(FName NotifyName);
    void OnCompleted_EE8DC77045518B8C7AC12A9B041E4FB3(FName NotifyName);
    void OnNotifyEnd_68A032E347D9BAD3E7924FB07931BB71(FName NotifyName);
    void OnNotifyBegin_68A032E347D9BAD3E7924FB07931BB71(FName NotifyName);
    void OnInterrupted_68A032E347D9BAD3E7924FB07931BB71(FName NotifyName);
    void OnBlendOut_68A032E347D9BAD3E7924FB07931BB71(FName NotifyName);
    void OnCompleted_68A032E347D9BAD3E7924FB07931BB71(FName NotifyName);
    void OnNotifyEnd_FE3DDF36419C950C160EC48E82507BC5(FName NotifyName);
    void OnNotifyBegin_FE3DDF36419C950C160EC48E82507BC5(FName NotifyName);
    void OnInterrupted_FE3DDF36419C950C160EC48E82507BC5(FName NotifyName);
    void OnBlendOut_FE3DDF36419C950C160EC48E82507BC5(FName NotifyName);
    void OnCompleted_FE3DDF36419C950C160EC48E82507BC5(FName NotifyName);
    void OnNotifyEnd_B7AE10D2489C5FE65AEBCAA040C0D44A(FName NotifyName);
    void OnNotifyBegin_B7AE10D2489C5FE65AEBCAA040C0D44A(FName NotifyName);
    void OnInterrupted_B7AE10D2489C5FE65AEBCAA040C0D44A(FName NotifyName);
    void OnBlendOut_B7AE10D2489C5FE65AEBCAA040C0D44A(FName NotifyName);
    void OnCompleted_B7AE10D2489C5FE65AEBCAA040C0D44A(FName NotifyName);
    void OnNotifyEnd_C02D6D2E428EA98A3BE3F98BE54AF025(FName NotifyName);
    void OnNotifyBegin_C02D6D2E428EA98A3BE3F98BE54AF025(FName NotifyName);
    void OnInterrupted_C02D6D2E428EA98A3BE3F98BE54AF025(FName NotifyName);
    void OnBlendOut_C02D6D2E428EA98A3BE3F98BE54AF025(FName NotifyName);
    void OnCompleted_C02D6D2E428EA98A3BE3F98BE54AF025(FName NotifyName);
    void OnNotifyEnd_281F9E5B44BFDCCAB91144BA7BEE9BA7(FName NotifyName);
    void OnNotifyBegin_281F9E5B44BFDCCAB91144BA7BEE9BA7(FName NotifyName);
    void OnInterrupted_281F9E5B44BFDCCAB91144BA7BEE9BA7(FName NotifyName);
    void OnBlendOut_281F9E5B44BFDCCAB91144BA7BEE9BA7(FName NotifyName);
    void OnCompleted_281F9E5B44BFDCCAB91144BA7BEE9BA7(FName NotifyName);
    void OnNotifyEnd_38409368459184F1394C119754292804(FName NotifyName);
    void OnNotifyBegin_38409368459184F1394C119754292804(FName NotifyName);
    void OnInterrupted_38409368459184F1394C119754292804(FName NotifyName);
    void OnBlendOut_38409368459184F1394C119754292804(FName NotifyName);
    void OnCompleted_38409368459184F1394C119754292804(FName NotifyName);
    void OnNotifyEnd_6DFDA0B84656EC067014538794CE2C68(FName NotifyName);
    void OnNotifyBegin_6DFDA0B84656EC067014538794CE2C68(FName NotifyName);
    void OnInterrupted_6DFDA0B84656EC067014538794CE2C68(FName NotifyName);
    void OnBlendOut_6DFDA0B84656EC067014538794CE2C68(FName NotifyName);
    void OnCompleted_6DFDA0B84656EC067014538794CE2C68(FName NotifyName);
    void OnFailure_2B0C88604CAA5ACF6999B4B4D2B80423();
    void OnSuccess_2B0C88604CAA5ACF6999B4B4D2B80423();
    void OnFailure_8538A48545B54B03FB2E8F8EB1B0C0A0(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_8538A48545B54B03FB2E8F8EB1B0C0A0(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_D6DDAB12478DDDF447B65194C0C8828B();
    void OnSuccess_D6DDAB12478DDDF447B65194C0C8828B();
    void OnFailure_E6EAD790492F1E17BB5CC3A1F70D5F81(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_E6EAD790492F1E17BB5CC3A1F70D5F81(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void SecondaryInteraction();
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void BndEvt__Husky_AI_Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BeginAI();
    void ReceivePossessed(class AController* NewController);
    void UpdateMovementServer();
    void ReceiveTick(float DeltaSeconds);
    void BndEvt__Husky_AI_Sphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void UpdatePlayerInRange(bool InRange, class ABP_FirstPersonCharacter_C* Player);
    void PlayMontage(class UAnimMontage* MontageToPlay, bool StopALL);
    void PlayMontageRPC(class UAnimMontage* MontageToPlay, bool StopAll?);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void UpdateStateAndOwner(uint8 EnumValue, class UObject* ObjectValue);
    void Tame(class ABP_FirstPersonCharacter_C* Character);
    void TameServer(class ABP_FirstPersonCharacter_C* Character);
    void BndEvt__Husky_AI_Sphere1_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void RunAwayServer();
    void RunAwayAll();
    void ReceiveBeginPlay();
    void DeSpawnServer();
    void DeSpawnAll();
    void UpdateEnemyInRange(bool InRange, class APawn* Pawn);
    void BndEvt__Husky_AI_Sphere1_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void RandomScale();
    void RandomScaleAll(double Scale);
    void StartInfection();
    void StartInfectionBrain();
    void NormalDeath();
    void NormalDeathFire();
    void OpenDoor();
    void OpenDoorAll(class UObject* Target);
    void OpenDoorServer(class UObject* Target);
    void PlayMontageALL(bool StopALL, class UAnimMontage* Montage);
    void PlayMontageServer(bool StopALL, class UAnimMontage* Montage);
    void AttackEnemy();
    void AttackEnemyServer();
    void DeathServer(FVector Location, bool Fire);
    void DeathAll(FVector Location, bool Fire);
    void BecomeInfected();
    void PickUpDropItemHusky(bool Drop, class AItemActor* Item);
    void PickUpDropItemHuskyServer(bool Drop, class AItemActor* Item);
    void StartInfectionProcess();
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_Husky_AI(int32 EntryPoint);
}; // Size: 0x750

#endif
