#ifndef UE4SS_SDK_BP_West_Heli_UH60A_HPP
#define UE4SS_SDK_BP_West_Heli_UH60A_HPP

class ABP_West_Heli_UH60A_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNiagaraComponent* DustPlume;                                               // 0x0298 (size: 0x8)
    class UNiagaraComponent* LeftExhaust;                                             // 0x02A0 (size: 0x8)
    class UNiagaraComponent* RightExhaust;                                            // 0x02A8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x02B0 (size: 0x8)
    class UABP_West_Heli_UH60A_C* AnimInstance;                                       // 0x02B8 (size: 0x8)
    class UMaterialInstanceDynamic* BodyMaterial;                                     // 0x02C0 (size: 0x8)
    bool Is Dust Plume Visible;                                                       // 0x02C8 (size: 0x1)

    void UserConstructionScript();
    void SetTailRotorSpeed(double TailRotorSpeed);
    void SetMainRotorSpeed(double MainRotorSpeed);
    void SetFrontWheels(double FrontWheelsState);
    void SetRearWheels(double RearWheelsState);
    void SetRearElevator(double ElevatorState);
    void SetExhaustFumes(double FumesIntensity);
    void SetDustPlumeIntensity(double Intensity);
    void SetRightWindowShield(double First, double Second);
    void SetLeftWindowShield(double First, double Second);
    void SetFrontDoors(double Right, double Left);
    void SetRearDoors(double Right, double Left);
    void ShowDustPlume(bool bIsDustPlumeVisible);
    void SetShowDamaged(bool ShowDamage);
    void SetLightsEmissivity(double LightEmissivity);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_West_Heli_UH60A(int32 EntryPoint);
}; // Size: 0x2C9

#endif
