#ifndef UE4SS_SDK_DroneClassified_HPP
#define UE4SS_SDK_DroneClassified_HPP

class ADroneClassified_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    float Timeline_NewTrack_0_CA83B47D40BF896C828000840A5E2E4F;                       // 0x02A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_CA83B47D40BF896C828000840A5E2E4F; // 0x02AC (size: 0x1)
    char padding_0[0x3];                                                              // 0x02AD (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x02B0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02B8 (size: 0x8)
    double Closest;                                                                   // 0x02C0 (size: 0x8)
    class ABP_Radio_C* Radio;                                                         // 0x02C8 (size: 0x8)
    FString Name;                                                                     // 0x02D0 (size: 0x10)
    bool Interacting;                                                                 // 0x02E0 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_1070CFB24E2058175CF222A8D23C1DEF(FName NotifyName);
    void OnNotifyBegin_1070CFB24E2058175CF222A8D23C1DEF(FName NotifyName);
    void OnInterrupted_1070CFB24E2058175CF222A8D23C1DEF(FName NotifyName);
    void OnBlendOut_1070CFB24E2058175CF222A8D23C1DEF(FName NotifyName);
    void OnCompleted_1070CFB24E2058175CF222A8D23C1DEF(FName NotifyName);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void ExecuteUbergraph_DroneClassified(int32 EntryPoint);
}; // Size: 0x2E1

#endif
