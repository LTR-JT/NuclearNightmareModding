#ifndef UE4SS_SDK_HelicopterWaypointUI_HPP
#define UE4SS_SDK_HelicopterWaypointUI_HPP

class UHelicopterWaypointUI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UImage* Image_24;                                                           // 0x02E8 (size: 0x8)
    class UTextBlock* TextBlock_57;                                                   // 0x02F0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02F8 (size: 0x8)
    class AWaypointActor_C* Waypoint;                                                 // 0x0300 (size: 0x8)
    int32 Minutes;                                                                    // 0x0308 (size: 0x4)
    int32 Seconds;                                                                    // 0x030C (size: 0x4)
    FTimerHandle MinutesTimer;                                                        // 0x0310 (size: 0x8)
    FTimerHandle HeliTimer;                                                           // 0x0318 (size: 0x8)
    FHelicopterWaypointUI_CTimerDone TimerDone;                                       // 0x0320 (size: 0x10)
    void TimerDone();

    FText GetText_1();
    FText GetText_0();
    FLinearColor GetColorAndOpacity();
    FText GetText();
    void Construct();
    void Timer();
    void ExecuteUbergraph_HelicopterWaypointUI(int32 EntryPoint);
    void TimerDone__DelegateSignature();
}; // Size: 0x330

#endif
