#ifndef UE4SS_SDK_HelicopterWaypoint_HPP
#define UE4SS_SDK_HelicopterWaypoint_HPP

class AHelicopterWaypoint_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02A8 (size: 0x8)
    int32 Minutes;                                                                    // 0x02B0 (size: 0x4)
    int32 Seconds;                                                                    // 0x02B4 (size: 0x4)
    FHelicopterWaypoint_CTimerDoneAgain TimerDoneAgain;                               // 0x02B8 (size: 0x10)
    void TimerDoneAgain();

    void ReceiveBeginPlay();
    void Timer Done();
    void ExecuteUbergraph_HelicopterWaypoint(int32 EntryPoint);
    void TimerDoneAgain__DelegateSignature();
}; // Size: 0x2C8

#endif
