namespace ENiagaraCoordinateSpace {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ENiagaraCoordinateSpace_MAX = 3,
    };
}

