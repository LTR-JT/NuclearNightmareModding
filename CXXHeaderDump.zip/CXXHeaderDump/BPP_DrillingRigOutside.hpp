#ifndef UE4SS_SDK_BPP_DrillingRigOutside_HPP
#define UE4SS_SDK_BPP_DrillingRigOutside_HPP

class ABPP_DrillingRigOutside_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0330 (size: 0x8)
    class UHierarchicalInstancedStaticMeshComponent* HierarchicalInstancedStaticMesh1; // 0x0338 (size: 0x8)
    class UHierarchicalInstancedStaticMeshComponent* HierarchicalInstancedStaticMesh; // 0x0340 (size: 0x8)

}; // Size: 0x348

#endif
