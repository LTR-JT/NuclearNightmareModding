#ifndef UE4SS_SDK_EndGameState_HPP
#define UE4SS_SDK_EndGameState_HPP

class UEndGameState_C : public UUserWidget
{
}; // Size: 0x2E0

#endif
