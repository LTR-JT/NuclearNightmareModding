namespace EDayNightCycle {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EDayNightCycle_MAX = 3,
    };
}

