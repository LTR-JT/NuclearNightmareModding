#ifndef UE4SS_SDK_AnimNotify_PlaySoundAtLocation_HPP
#define UE4SS_SDK_AnimNotify_PlaySoundAtLocation_HPP

class UAnimNotify_PlaySoundAtLocation_C : public UAnimNotify
{
    class USoundBase* Sound;                                                          // 0x0038 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x40

#endif
