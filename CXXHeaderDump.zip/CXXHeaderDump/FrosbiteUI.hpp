#ifndef UE4SS_SDK_FrosbiteUI_HPP
#define UE4SS_SDK_FrosbiteUI_HPP

class UFrosbiteUI_C : public UUserWidget
{
    class UProgressBar* ProgressBar_0;                                                // 0x02E0 (size: 0x8)
    class UProgressBar* ProgressBar_1;                                                // 0x02E8 (size: 0x8)
    class UTextBlock* TextBlock_47;                                                   // 0x02F0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Player;                                         // 0x02F8 (size: 0x8)

    float GetPercent_0();
    FSlateColor GetColorAndOpacity();
    FText GetText();
    float GetPercent();
}; // Size: 0x300

#endif
