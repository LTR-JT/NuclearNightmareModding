#ifndef UE4SS_SDK_BP_CommonTabListWidget_Base_HPP
#define UE4SS_SDK_BP_CommonTabListWidget_Base_HPP

class UBP_CommonTabListWidget_Base_C : public UCommonTabListWidgetBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0488 (size: 0x8)
    class UCommonActionWidget* LeftTabAction;                                         // 0x0490 (size: 0x8)
    class UCommonActionWidget* RightTabAction;                                        // 0x0498 (size: 0x8)
    class UHorizontalBox* TabButtonBox;                                               // 0x04A0 (size: 0x8)
    class UCommonAnimatedSwitcher* LinkedSwitcherWidget;                              // 0x04A8 (size: 0x8)
    TMap<class UCommonActivatableWidget*, class FText> TabEntries;                    // 0x04B0 (size: 0x50)
    TMap<class FName, class UCommonActivatableWidget*> NewVar_0;                      // 0x0500 (size: 0x50)

    void Create Dynamic Tab Menu(class UCommonAnimatedSwitcher* Target Switcher, const TMap<class UCommonActivatableWidget*, class FText>& Dynamic Tab Entries);
    void PreConstruct(bool IsDesignTime);
    void ExecuteUbergraph_BP_CommonTabListWidget_Base(int32 EntryPoint);
}; // Size: 0x550

#endif
