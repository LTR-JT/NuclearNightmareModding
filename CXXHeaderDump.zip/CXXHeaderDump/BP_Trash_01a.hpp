#ifndef UE4SS_SDK_BP_Trash_01a_HPP
#define UE4SS_SDK_BP_Trash_01a_HPP

class ABP_Trash_01a_C : public AActor
{
    class UStaticMeshComponent* SM_DisposalBin_02b;                                   // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_DisposalBin_02a;                                   // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)

}; // Size: 0x2A8

#endif
