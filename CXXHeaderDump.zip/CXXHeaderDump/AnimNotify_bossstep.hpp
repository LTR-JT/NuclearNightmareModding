#ifndef UE4SS_SDK_AnimNotify_bossstep_HPP
#define UE4SS_SDK_AnimNotify_bossstep_HPP

class UAnimNotify_bossstep_C : public UAnimNotify
{
    FName In Socket Name;                                                             // 0x0038 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x40

#endif
