#ifndef UE4SS_SDK_FastLearner_AI_HPP
#define UE4SS_SDK_FastLearner_AI_HPP

class AFastLearner_AI_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class USkeletalMeshComponent* CharacterMesh1;                                     // 0x0678 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x0680 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction2;                                     // 0x0688 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction1;                                     // 0x0690 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0698 (size: 0x8)
    class UAudioComponent* big_monster1_Cue1;                                         // 0x06A0 (size: 0x8)
    float Timeline_NewTrack_0_6E1D85BF42E359604A52D0940E711096;                       // 0x06A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_6E1D85BF42E359604A52D0940E711096; // 0x06AC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x06B0 (size: 0x8)
    float Timeline_0_NewTrack_0_9BF427AC4EA9C5CF53851A824DE1F286;                     // 0x06B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_9BF427AC4EA9C5CF53851A824DE1F286; // 0x06BC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x06C0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Target;                                         // 0x06C8 (size: 0x8)
    bool OpeningDoor;                                                                 // 0x06D0 (size: 0x1)
    class UStaticMeshComponent* Door;                                                 // 0x06D8 (size: 0x8)
    bool BPIsDead;                                                                    // 0x06E0 (size: 0x1)
    bool FlamethrowerAttack;                                                          // 0x06E1 (size: 0x1)
    FVector Relative Location;                                                        // 0x06E8 (size: 0x18)
    TArray<class ABP_FirstPersonCharacter_C*> AllPlayers;                             // 0x0700 (size: 0x10)
    bool DeSpawn;                                                                     // 0x0710 (size: 0x1)
    bool BpIsAttacking;                                                               // 0x0711 (size: 0x1)
    bool SeePlayer;                                                                   // 0x0712 (size: 0x1)
    class AMusicManager_C* MusicManager;                                              // 0x0718 (size: 0x8)
    FRotator OldControlRot;                                                           // 0x0720 (size: 0x18)
    bool BPCanSeePlayer;                                                              // 0x0738 (size: 0x1)
    bool ElusiveFighter;                                                              // 0x0739 (size: 0x1)
    bool ForceRunawayBool;                                                            // 0x073A (size: 0x1)
    int32 Type;                                                                       // 0x073C (size: 0x4)

    bool Attacking();
    bool CanSeePlayer();
    bool Dead();
    bool CanBeSensed(class ANuclearNightmareCharacter* ResponsibleCharacter);
    bool InfectionDetector();
    void UserConstructionScript();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_675B48FD4185F163F4C9C2A55F98AE90(FName NotifyName);
    void OnNotifyBegin_675B48FD4185F163F4C9C2A55F98AE90(FName NotifyName);
    void OnInterrupted_675B48FD4185F163F4C9C2A55F98AE90(FName NotifyName);
    void OnBlendOut_675B48FD4185F163F4C9C2A55F98AE90(FName NotifyName);
    void OnCompleted_675B48FD4185F163F4C9C2A55F98AE90(FName NotifyName);
    void OnNotifyEnd_1A46BCDB49FD46EBAF2423A2BD3A48E9(FName NotifyName);
    void OnNotifyBegin_1A46BCDB49FD46EBAF2423A2BD3A48E9(FName NotifyName);
    void OnInterrupted_1A46BCDB49FD46EBAF2423A2BD3A48E9(FName NotifyName);
    void OnBlendOut_1A46BCDB49FD46EBAF2423A2BD3A48E9(FName NotifyName);
    void OnCompleted_1A46BCDB49FD46EBAF2423A2BD3A48E9(FName NotifyName);
    void OnNotifyEnd_CAC761E74C8830D5BBCB8B94DC253DDB(FName NotifyName);
    void OnNotifyBegin_CAC761E74C8830D5BBCB8B94DC253DDB(FName NotifyName);
    void OnInterrupted_CAC761E74C8830D5BBCB8B94DC253DDB(FName NotifyName);
    void OnBlendOut_CAC761E74C8830D5BBCB8B94DC253DDB(FName NotifyName);
    void OnCompleted_CAC761E74C8830D5BBCB8B94DC253DDB(FName NotifyName);
    void OnNotifyEnd_6C517D1B4419AA66FB92E1B4DFB42D7D(FName NotifyName);
    void OnNotifyBegin_6C517D1B4419AA66FB92E1B4DFB42D7D(FName NotifyName);
    void OnInterrupted_6C517D1B4419AA66FB92E1B4DFB42D7D(FName NotifyName);
    void OnBlendOut_6C517D1B4419AA66FB92E1B4DFB42D7D(FName NotifyName);
    void OnCompleted_6C517D1B4419AA66FB92E1B4DFB42D7D(FName NotifyName);
    void OnNotifyEnd_D4DE190F46DEB2A34F053E944BA0CC6C(FName NotifyName);
    void OnNotifyBegin_D4DE190F46DEB2A34F053E944BA0CC6C(FName NotifyName);
    void OnInterrupted_D4DE190F46DEB2A34F053E944BA0CC6C(FName NotifyName);
    void OnBlendOut_D4DE190F46DEB2A34F053E944BA0CC6C(FName NotifyName);
    void OnCompleted_D4DE190F46DEB2A34F053E944BA0CC6C(FName NotifyName);
    void OnNotifyEnd_00D7A37C405DF030363F27A9515D8F37(FName NotifyName);
    void OnNotifyBegin_00D7A37C405DF030363F27A9515D8F37(FName NotifyName);
    void OnInterrupted_00D7A37C405DF030363F27A9515D8F37(FName NotifyName);
    void OnBlendOut_00D7A37C405DF030363F27A9515D8F37(FName NotifyName);
    void OnCompleted_00D7A37C405DF030363F27A9515D8F37(FName NotifyName);
    void OnFailure_1B61912F45F274240DCE2B9D589780FC();
    void OnSuccess_1B61912F45F274240DCE2B9D589780FC();
    void OnFailure_4888378942B6D7DF60B897B6C83A9D36(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_4888378942B6D7DF60B897B6C83A9D36(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnNotifyEnd_A557B0584E9E45AABA36F3AFA3374432(FName NotifyName);
    void OnNotifyBegin_A557B0584E9E45AABA36F3AFA3374432(FName NotifyName);
    void OnInterrupted_A557B0584E9E45AABA36F3AFA3374432(FName NotifyName);
    void OnBlendOut_A557B0584E9E45AABA36F3AFA3374432(FName NotifyName);
    void OnCompleted_A557B0584E9E45AABA36F3AFA3374432(FName NotifyName);
    void OnNotifyEnd_8F6637064200F8E46CB6CC9EAB91221C(FName NotifyName);
    void OnNotifyBegin_8F6637064200F8E46CB6CC9EAB91221C(FName NotifyName);
    void OnInterrupted_8F6637064200F8E46CB6CC9EAB91221C(FName NotifyName);
    void OnBlendOut_8F6637064200F8E46CB6CC9EAB91221C(FName NotifyName);
    void OnCompleted_8F6637064200F8E46CB6CC9EAB91221C(FName NotifyName);
    void OnNotifyEnd_34445C7044BEC268DDD534849BA6482A(FName NotifyName);
    void OnNotifyBegin_34445C7044BEC268DDD534849BA6482A(FName NotifyName);
    void OnInterrupted_34445C7044BEC268DDD534849BA6482A(FName NotifyName);
    void OnBlendOut_34445C7044BEC268DDD534849BA6482A(FName NotifyName);
    void OnCompleted_34445C7044BEC268DDD534849BA6482A(FName NotifyName);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void ReceiveBeginPlay();
    void AttackAll(double Chance);
    void AttackServer();
    void StartBehavior();
    void ReceiveTick(float DeltaSeconds);
    void CheckIfLooking();
    void ExecCheck(bool bool);
    void DeathMulti();
    void DeSpawnServer();
    void DeSpawnAll();
    void ReceivePossessed(class AController* NewController);
    void dEATHsEVER();
    void DeathSkip();
    void DeathServer();
    void BndEvt__FastLearner_AI_PawnSensing_K2Node_ComponentBoundEvent_1_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void SeeCharacter(class ABP_FirstPersonCharacter_C* Player);
    void UpdateSound(bool TRUE);
    void EnemyAttack(class AStalker_AI_C* Stalker);
    void ForceRunAway();
    void MoveToGenerator(class ABP_GeneratorGameplayNew_C* Generator, bool MoveTo?);
    void DestroyGen();
    void PlayMontageALL();
    void PlayMontageServer();
    void CheckForGenerator();
    void PlaySpawnAnimation();
    void PlaySpawnAnimationServer();
    void RPCSpawnAnimation();
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void ExecuteUbergraph_FastLearner_AI(int32 EntryPoint);
}; // Size: 0x740

#endif
