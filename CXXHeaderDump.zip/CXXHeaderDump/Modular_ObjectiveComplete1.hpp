#ifndef UE4SS_SDK_Modular_ObjectiveComplete1_HPP
#define UE4SS_SDK_Modular_ObjectiveComplete1_HPP

class UModular_ObjectiveComplete1_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UImage* Image_228;                                                          // 0x02F0 (size: 0x8)
    class UImage* Image_279;                                                          // 0x02F8 (size: 0x8)
    class UImage* Symbol;                                                             // 0x0300 (size: 0x8)
    class UTextBlock* TextBlock_130;                                                  // 0x0308 (size: 0x8)
    FText ObjectiveDescription;                                                       // 0x0310 (size: 0x10)
    class UObject* Avatar;                                                            // 0x0320 (size: 0x8)
    bool EnableSound;                                                                 // 0x0328 (size: 0x1)
    FLinearColor Specified Color;                                                     // 0x032C (size: 0x10)
    class UTexture2D* SymbolHud;                                                      // 0x0340 (size: 0x8)

    FSlateBrush Get_Symbol_Brush();
    FLinearColor Get_Symbol_ColorAndOpacity();
    FSlateColor GetColorAndOpacity();
    FSlateBrush GetBrush();
    FText GetText();
    void PreConstruct(bool IsDesignTime);
    void Construct();
    void ExecuteUbergraph_Modular_ObjectiveComplete1(int32 EntryPoint);
}; // Size: 0x348

#endif
