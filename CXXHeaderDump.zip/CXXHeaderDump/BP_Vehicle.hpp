#ifndef UE4SS_SDK_BP_Vehicle_HPP
#define UE4SS_SDK_BP_Vehicle_HPP

class ABP_Vehicle_C : public AWheeledVehiclePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UBoxComponent* Seat4Exit;                                                   // 0x0330 (size: 0x8)
    class UBoxComponent* Seat3Exit;                                                   // 0x0338 (size: 0x8)
    class UBoxComponent* Seat2Exit;                                                   // 0x0340 (size: 0x8)
    class UBoxComponent* Seat1Exit;                                                   // 0x0348 (size: 0x8)
    class USpotLightComponent* SpotLight1;                                            // 0x0350 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0358 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0360 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0368 (size: 0x8)
    class UStaticMeshComponent* SM_Brake_Pad_R;                                       // 0x0370 (size: 0x8)
    class UStaticMeshComponent* SM_Brake_Pad_L;                                       // 0x0378 (size: 0x8)
    class UStaticMeshComponent* SM_All_Trans;                                         // 0x0380 (size: 0x8)
    class UStaticMeshComponent* SM_Frame;                                             // 0x0388 (size: 0x8)
    class UStaticMeshComponent* SM_Wheel_Rear_R;                                      // 0x0390 (size: 0x8)
    class UStaticMeshComponent* SM_Wheel_Rear_L;                                      // 0x0398 (size: 0x8)
    class UStaticMeshComponent* SM_Wheel_Front_L;                                     // 0x03A0 (size: 0x8)
    class UStaticMeshComponent* SM_Wheel_Front_R;                                     // 0x03A8 (size: 0x8)
    TEnumAsByte<E_VehicleColor::Type> Vehicle Color;                                  // 0x03B0 (size: 0x1)
    char padding_0[0x7];                                                              // 0x03B1 (size: 0x7)
    class UInputMappingContext* Input Mapping;                                        // 0x03B8 (size: 0x8)
    class UInputMappingContext* Input Look Mapping;                                   // 0x03C0 (size: 0x8)
    bool Seat 1;                                                                      // 0x03C8 (size: 0x1)
    bool Seat 3;                                                                      // 0x03C9 (size: 0x1)
    bool Seat 4;                                                                      // 0x03CA (size: 0x1)
    bool Seat 2;                                                                      // 0x03CB (size: 0x1)
    char padding_1[0x4];                                                              // 0x03CC (size: 0x4)
    class ABP_FirstPersonCharacter_C* Seat1Player;                                    // 0x03D0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat2Player;                                    // 0x03D8 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat3Player;                                    // 0x03E0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Seat4Player;                                    // 0x03E8 (size: 0x8)
    TEnumAsByte<ESeatNumber::Type> SeatNumber;                                        // 0x03F0 (size: 0x1)
    char padding_2[0x7];                                                              // 0x03F1 (size: 0x7)
    class APlayerController* As Player Controller;                                    // 0x03F8 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void GetEmptySeat(TEnumAsByte<ESeatNumber::Type>& SeatNumber);
    void GetSeatStatus(bool& Seat1, bool& Seat2, bool& Seat3, bool& Seat4);
    void Num Wheels On Ground(int32& Value);
    void get driving state(double& Throttle, double& Brake, double& Steering, bool& Handbrake On, double& Forward Speed, double& RPM, int32& Gear, bool& Automatic, bool& All Wheels on Ground, bool& No Wheels on Ground);
    void SetColorWhite();
    void SetColorRed();
    void SetColorBeige();
    void SetColorGreen();
    void SetColorBlack();
    void SetColorGrey();
    void SetColorSilver();
    void SetColorBlue();
    void SetColor();
    void Attach Nanite To Skeletal Mesh();
    void UserConstructionScript();
    void InpActEvt_IA_VH_Throttle_K2Node_EnhancedInputActionEvent_13(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Throttle_K2Node_EnhancedInputActionEvent_12(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Brake_K2Node_EnhancedInputActionEvent_11(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Brake_K2Node_EnhancedInputActionEvent_10(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Handbrake_K2Node_EnhancedInputActionEvent_9(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Handbrake_K2Node_EnhancedInputActionEvent_8(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Handbrake_K2Node_EnhancedInputActionEvent_7(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Handbrake_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Steering_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Steering_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Steering_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_Steering_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_LC_LookDelta_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_VH_ExitCar_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ReceivePossessed(class AController* NewController);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void ReceiveUnpossessed(class AController* OldController);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void ClientAddInput(class AController* Controller);
    void ExitCar();
    void ClientRemoveInput(class AController* Controller);
    void ExecuteUbergraph_BP_Vehicle(int32 EntryPoint);
}; // Size: 0x400

#endif
