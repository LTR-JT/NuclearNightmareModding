#ifndef UE4SS_SDK_JsonUtilities_HPP
#define UE4SS_SDK_JsonUtilities_HPP

struct FJsonObjectWrapper
{
    FString JsonString;                                                               // 0x0000 (size: 0x10)

}; // Size: 0x20

class UJsonUtilitiesDummyObject : public UObject
{
}; // Size: 0x28

#endif
