#ifndef UE4SS_SDK_FuseBox1_HPP
#define UE4SS_SDK_FuseBox1_HPP

class AFuseBox1_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_18;                                           // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_17;                                           // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_16;                                           // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_15;                                           // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_14;                                           // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_13;                                           // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_12;                                           // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* SM_Fuse_11;                                           // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x02E0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02E8 (size: 0x8)
    float Timeline_0_NewTrack_0_9A964C8C496C52EC488367AF129E9BC2;                     // 0x02F0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_9A964C8C496C52EC488367AF129E9BC2; // 0x02F4 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x02F8 (size: 0x8)
    bool PoweredOn;                                                                   // 0x0300 (size: 0x1)
    class ABP_FirstPersonCharacter_C* CharacterInteracting;                           // 0x0308 (size: 0x8)
    class AComputer_Interaction1_C* Computer;                                         // 0x0310 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_6D6ADC904E6235340E3215B86FC81441(FName NotifyName);
    void OnNotifyBegin_6D6ADC904E6235340E3215B86FC81441(FName NotifyName);
    void OnInterrupted_6D6ADC904E6235340E3215B86FC81441(FName NotifyName);
    void OnBlendOut_6D6ADC904E6235340E3215B86FC81441(FName NotifyName);
    void OnCompleted_6D6ADC904E6235340E3215B86FC81441(FName NotifyName);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_FuseBox1(int32 EntryPoint);
}; // Size: 0x318

#endif
