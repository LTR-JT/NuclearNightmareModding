#ifndef UE4SS_SDK_BP_Ceiling_Lamp_2_HPP
#define UE4SS_SDK_BP_Ceiling_Lamp_2_HPP

class ABP_Ceiling_Lamp_2_C : public AActor
{
    class USpotLightComponent* SpotLight;                                             // 0x0290 (size: 0x8)
    class UStaticMeshComponent* SM_Ceiling_Lamp_2_element_2;                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Ceiling_Lamp_2_element_1;                          // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Ceiling_Lamp_2_main;                               // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    bool Hang_1;                                                                      // 0x02B8 (size: 0x1)
    bool Hang_2;                                                                      // 0x02B9 (size: 0x1)

    void UserConstructionScript();
}; // Size: 0x2BA

#endif
