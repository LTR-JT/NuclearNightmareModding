#ifndef UE4SS_SDK_Alchol_interact_HPP
#define UE4SS_SDK_Alchol_interact_HPP

class AAlchol_interact_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* bottle;                                               // 0x0298 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A0 (size: 0x8)
    float Timeline_NewTrack_0_19DFA9684FF9AA748F87A7AE61F6745F;                       // 0x02A8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_19DFA9684FF9AA748F87A7AE61F6745F; // 0x02AC (size: 0x1)
    char padding_0[0x3];                                                              // 0x02AD (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x02B0 (size: 0x8)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x02B8 (size: 0x8)
    FVector StartLocation;                                                            // 0x02C0 (size: 0x18)
    int32 ManyTimeDrank;                                                              // 0x02D8 (size: 0x4)
    bool Drinking?;                                                                   // 0x02DC (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_C73EE9B84648109B130374A42BC450BD(FName NotifyName);
    void OnNotifyBegin_C73EE9B84648109B130374A42BC450BD(FName NotifyName);
    void OnInterrupted_C73EE9B84648109B130374A42BC450BD(FName NotifyName);
    void OnBlendOut_C73EE9B84648109B130374A42BC450BD(FName NotifyName);
    void OnCompleted_C73EE9B84648109B130374A42BC450BD(FName NotifyName);
    void OnNotifyEnd_7C6B550E487C0C8F4AA0648A481A15F8(FName NotifyName);
    void OnNotifyBegin_7C6B550E487C0C8F4AA0648A481A15F8(FName NotifyName);
    void OnInterrupted_7C6B550E487C0C8F4AA0648A481A15F8(FName NotifyName);
    void OnBlendOut_7C6B550E487C0C8F4AA0648A481A15F8(FName NotifyName);
    void OnCompleted_7C6B550E487C0C8F4AA0648A481A15F8(FName NotifyName);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_Alchol_interact(int32 EntryPoint);
}; // Size: 0x2DD

#endif
