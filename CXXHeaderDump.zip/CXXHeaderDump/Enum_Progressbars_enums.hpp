namespace Enum_Progressbars {
    enum Type {
        NewEnumerator18 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator3 = 3,
        NewEnumerator4 = 4,
        NewEnumerator5 = 5,
        NewEnumerator6 = 6,
        NewEnumerator7 = 7,
        NewEnumerator8 = 8,
        NewEnumerator9 = 9,
        NewEnumerator17 = 10,
        NewEnumerator10 = 11,
        NewEnumerator11 = 12,
        NewEnumerator12 = 13,
        NewEnumerator13 = 14,
        NewEnumerator14 = 15,
        NewEnumerator15 = 16,
        NewEnumerator16 = 17,
        NewEnumerator19 = 18,
        NewEnumerator20 = 19,
        Enum_MAX = 20,
    };
}

