#ifndef UE4SS_SDK_BP_Door_Base_HPP
#define UE4SS_SDK_BP_Door_Base_HPP

class ABP_Door_Base_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x0298 (size: 0x8)
    class UStaticMeshComponent* SM_Door_1_L;                                          // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    float Timeline_DoorFloat_A94E08ED428373D8BE9323AE6BFAA76B;                        // 0x02B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_A94E08ED428373D8BE9323AE6BFAA76B; // 0x02B4 (size: 0x1)
    char padding_0[0x3];                                                              // 0x02B5 (size: 0x3)
    class UTimelineComponent* Timeline;                                               // 0x02B8 (size: 0x8)
    float Timeline_0_DoorFloat_FBE3E56A48721FD8DB0C78B901AE537B;                      // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_FBE3E56A48721FD8DB0C78B901AE537B; // 0x02C4 (size: 0x1)
    char padding_1[0x3];                                                              // 0x02C5 (size: 0x3)
    class UTimelineComponent* Timeline_0;                                             // 0x02C8 (size: 0x8)
    double DoorAngle;                                                                 // 0x02D0 (size: 0x8)
    bool DoorOpen;                                                                    // 0x02D8 (size: 0x1)
    char padding_2[0x7];                                                              // 0x02D9 (size: 0x7)
    class USoundBase* DoorOpenSound;                                                  // 0x02E0 (size: 0x8)
    class USoundBase* DoorCloseSound;                                                 // 0x02E8 (size: 0x8)
    bool Inverse;                                                                     // 0x02F0 (size: 0x1)
    char padding_3[0x7];                                                              // 0x02F1 (size: 0x7)
    class USoundBase* DoorLockedSound;                                                // 0x02F8 (size: 0x8)
    bool Locked?;                                                                     // 0x0300 (size: 0x1)
    bool Interacting;                                                                 // 0x0301 (size: 0x1)
    char padding_4[0x6];                                                              // 0x0302 (size: 0x6)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0308 (size: 0x8)
    bool HasBeenOpened;                                                               // 0x0310 (size: 0x1)
    bool Broken;                                                                      // 0x0311 (size: 0x1)
    bool InitatedDoorOpen?;                                                           // 0x0312 (size: 0x1)
    bool PlayerInteracting?;                                                          // 0x0313 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void OnRep_Interacting();
    void OnRep_GlassBroken();
    void OnRep_DoorOpen();
    void OnRep_Broken();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_90E28B8841D1C8A94E997B8543043587(FName NotifyName);
    void OnNotifyBegin_90E28B8841D1C8A94E997B8543043587(FName NotifyName);
    void OnInterrupted_90E28B8841D1C8A94E997B8543043587(FName NotifyName);
    void OnBlendOut_90E28B8841D1C8A94E997B8543043587(FName NotifyName);
    void OnCompleted_90E28B8841D1C8A94E997B8543043587(FName NotifyName);
    void SecondaryInteraction();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void DoorClose();
    void BreakDoorServer();
    void RPC_DoorOpen(bool DoorOpen?);
    void SetInteractingState(bool Interacting?);
    void ExecuteUbergraph_BP_Door_Base(int32 EntryPoint);
}; // Size: 0x314

#endif
