#ifndef UE4SS_SDK_BP_Door_Base_HPP
#define UE4SS_SDK_BP_Door_Base_HPP

class ABP_Door_Base_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USkeletalMeshComponent* Door_Barricade;                                     // 0x0298 (size: 0x8)
    class UNetworkPhysicsSettingsComponent* NetworkPhysicsSettings;                   // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* SM_Door_1_L;                                          // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    float Timeline_DoorFloat_A94E08ED428373D8BE9323AE6BFAA76B;                        // 0x02B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_A94E08ED428373D8BE9323AE6BFAA76B; // 0x02BC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02C0 (size: 0x8)
    double DoorAngle;                                                                 // 0x02C8 (size: 0x8)
    bool DoorOpen;                                                                    // 0x02D0 (size: 0x1)
    class USoundBase* DoorOpenSound;                                                  // 0x02D8 (size: 0x8)
    class USoundBase* DoorCloseSound;                                                 // 0x02E0 (size: 0x8)
    bool Inverse;                                                                     // 0x02E8 (size: 0x1)
    class USoundBase* DoorLockedSound;                                                // 0x02F0 (size: 0x8)
    bool Locked?;                                                                     // 0x02F8 (size: 0x1)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0300 (size: 0x8)
    bool HasBeenOpened;                                                               // 0x0308 (size: 0x1)
    bool Broken;                                                                      // 0x0309 (size: 0x1)
    bool PlayerInteracting?;                                                          // 0x030A (size: 0x1)
    FVector HitAtLocation;                                                            // 0x0310 (size: 0x18)
    bool Barricaded;                                                                  // 0x0328 (size: 0x1)
    bool Destroybarricadeevent;                                                       // 0x0329 (size: 0x1)
    bool DoingBreakEvent;                                                             // 0x032A (size: 0x1)
    class AItem_Barricade_C* Barricade Item;                                          // 0x0330 (size: 0x8)

    void PassiveInteraction(FText& ActorName);
    void OnRep_Destroybarricadeevent();
    void OnRep_Barricaded();
    void OnRep_GlassBroken();
    void OnRep_DoorOpen();
    void OnRep_Broken();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void OnNotifyEnd_B025D9CB4A30D883350A77AE0E407E07(FName NotifyName);
    void OnNotifyBegin_B025D9CB4A30D883350A77AE0E407E07(FName NotifyName);
    void OnInterrupted_B025D9CB4A30D883350A77AE0E407E07(FName NotifyName);
    void OnBlendOut_B025D9CB4A30D883350A77AE0E407E07(FName NotifyName);
    void OnCompleted_B025D9CB4A30D883350A77AE0E407E07(FName NotifyName);
    void BulletDamage(class AActor* ResponsibleActor, float Damage, FVector HitLocation, FVector HitImpulse, FName HitBone, bool IsSniper);
    void BurnDamage(class AActor* ResponsibleActor, float Damage);
    void FlareDamage(class AActor* ResponsibleActor, float Damage, FName HitBone);
    void WhermboDamage(class AActor* ResponsibleWhermbo);
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void SecondaryInteraction();
    void DoorClose();
    void RPC_DoorOpen(bool DoorOpen?, class ABP_FirstPersonCharacter_C* Character);
    void ExplosionDamage(class AActor* ResponsibleActor, float Damage);
    void PrimaryInteractionServer(class ABP_FirstPersonCharacter_C* Character);
    void SetPlayerAnimState(class ABP_FirstPersonCharacter_C* Player);
    void PrimaryInteractionClient(class ABP_FirstPersonCharacter_C* Character);
    void MeleeDamage(class AActor* ResponsibleActor, float Damage, FName HitBone, FVector HitPoint);
    void DoorBashFX(FVector Location);
    void DestroyBarricade();
    void RemoveItemMulticast(class AItemActor* Item, class ABP_FirstPersonCharacter_C* Character);
    void addbarricadeItem(class AItem_Barricade_C* Barricade, class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_BP_Door_Base(int32 EntryPoint);
}; // Size: 0x338

#endif
