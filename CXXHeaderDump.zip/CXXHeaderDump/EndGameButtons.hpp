#ifndef UE4SS_SDK_EndGameButtons_HPP
#define UE4SS_SDK_EndGameButtons_HPP

class UEndGameButtons_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_36;                                                         // 0x02E8 (size: 0x8)
    FEndGameButtons_CBackToMenu BackToMenu;                                           // 0x02F0 (size: 0x10)
    void BackToMenu();

    void BndEvt__EndGameButtons_Button_36_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_EndGameButtons(int32 EntryPoint);
    void BackToMenu__DelegateSignature();
}; // Size: 0x300

#endif
