#ifndef UE4SS_SDK_GameStartService_HPP
#define UE4SS_SDK_GameStartService_HPP

class AGameStartService_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    class ABP_FirstPersonCharacter_C* LocalPlayer;                                    // 0x02A0 (size: 0x8)
    TArray<class APlayerStart*> BaseCampStarts;                                       // 0x02A8 (size: 0x10)
    TArray<class APlayerStart*> ResearchCenterStarts;                                 // 0x02B8 (size: 0x10)
    TArray<class APlayerStart*> AirportStarts;                                        // 0x02C8 (size: 0x10)
    TArray<class APlayerStart*> SlaughterHouseStarts;                                 // 0x02D8 (size: 0x10)
    TArray<class APlayerStart*> BaseCampStarts2;                                      // 0x02E8 (size: 0x10)
    TArray<class APlayerStart*> OilRigStarts;                                         // 0x02F8 (size: 0x10)
    TArray<class APlayerStart*> ShelterStarts;                                        // 0x0308 (size: 0x10)
    TArray<class APlayerStart*> UndergroundStarts;                                    // 0x0318 (size: 0x10)
    TArray<class APlayerStart*> MedbayStarts;                                         // 0x0328 (size: 0x10)
    TArray<class APlayerStart*> DrillingRigStarts;                                    // 0x0338 (size: 0x10)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_GameStartService(int32 EntryPoint);
}; // Size: 0x348

#endif
