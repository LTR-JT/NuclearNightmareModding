#ifndef UE4SS_SDK_BP_DV_Default_Damage_Type_HPP
#define UE4SS_SDK_BP_DV_Default_Damage_Type_HPP

class UBP_DV_Default_Damage_Type_C : public UDamageType
{
    char padding_0[0x40];                                                             // 0x0000 (size: 0x0)
}; // Size: 0x40

#endif
