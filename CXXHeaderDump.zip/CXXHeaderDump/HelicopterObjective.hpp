#ifndef UE4SS_SDK_HelicopterObjective_HPP
#define UE4SS_SDK_HelicopterObjective_HPP

class UHelicopterObjective_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UModular_ObjectiveComplete_C* Modular_ObjectiveComplete;                    // 0x02E8 (size: 0x8)
    class UObject* Avatar;                                                            // 0x02F0 (size: 0x8)
    FString UserName;                                                                 // 0x02F8 (size: 0x10)
    int32 MaterialAt;                                                                 // 0x0308 (size: 0x4)
    int32 OutOf;                                                                      // 0x030C (size: 0x4)
    FString Location;                                                                 // 0x0310 (size: 0x10)
    FText text1;                                                                      // 0x0320 (size: 0x10)
    FText text1_0;                                                                    // 0x0330 (size: 0x10)

    void Construct();
    void ExecuteUbergraph_HelicopterObjective(int32 EntryPoint);
}; // Size: 0x340

#endif
