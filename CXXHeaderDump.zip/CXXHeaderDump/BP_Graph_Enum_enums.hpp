namespace BP_Graph_Enum {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        BP_Graph_MAX = 2,
    };
}

