#ifndef UE4SS_SDK_InfectedDogAnimBPV3_HPP
#define UE4SS_SDK_InfectedDogAnimBPV3_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    float __FloatProperty_57;                                                         // 0x0004 (size: 0x4)
    FName __NameProperty_58;                                                          // 0x0008 (size: 0x8)
    FName __NameProperty_59;                                                          // 0x0010 (size: 0x8)
    bool __BoolProperty_60;                                                           // 0x0018 (size: 0x1)
    float __FloatProperty_61;                                                         // 0x001C (size: 0x4)
    FInputScaleBiasClampConstants __StructProperty_62;                                // 0x0020 (size: 0x2C)
    float __FloatProperty_63;                                                         // 0x004C (size: 0x4)
    float __FloatProperty_64;                                                         // 0x0050 (size: 0x4)
    EAnimSyncMethod __EnumProperty_65;                                                // 0x0054 (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_66;                              // 0x0055 (size: 0x1)
    FName __NameProperty_67;                                                          // 0x0058 (size: 0x8)
    class UBlendProfile* __BlendProfile_68;                                           // 0x0060 (size: 0x8)
    class UCurveFloat* __CurveFloat_69;                                               // 0x0068 (size: 0x8)
    bool __BoolProperty_70;                                                           // 0x0070 (size: 0x1)
    EAlphaBlendOption __EnumProperty_71;                                              // 0x0071 (size: 0x1)
    EBlendListTransitionType __EnumProperty_72;                                       // 0x0072 (size: 0x1)
    TArray<float> __ArrayProperty_73;                                                 // 0x0078 (size: 0x10)
    FAnimNodeFunctionRef __StructProperty_74;                                         // 0x0088 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x00A8 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x0128 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x0140 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace_1; // 0x0170 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x01A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x01D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1;       // 0x0200 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend;       // 0x0230 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x0260 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer;         // 0x0290 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool;        // 0x02C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x02F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0320 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0350 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1;           // 0x0380 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x03B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x03E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0410 (size: 0x30)

}; // Size: 0x440

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    bool __BoolProperty;                                                              // 0x0001 (size: 0x1)

}; // Size: 0x2

class UInfectedDogAnimBPV3_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0x2)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0380 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0388 (size: 0x8)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x0390 (size: 0x168)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x04F8 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x0518 (size: 0x20)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x0538 (size: 0x168)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1;                          // 0x06A0 (size: 0x48)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x06E8 (size: 0xF0)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x07D8 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07F8 (size: 0x48)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x0840 (size: 0x48)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0888 (size: 0x80)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x0908 (size: 0x28)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x0930 (size: 0x28)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x0958 (size: 0x128)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0A80 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0AA0 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0AC0 (size: 0x128)
    class ADog_Infected_AI_C* As Dog Infected AI;                                     // 0x0BE8 (size: 0x8)
    FVector HeadLocation;                                                             // 0x0BF0 (size: 0x18)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_InfectedDogAnimBPV3_AnimGraphNode_BlendListByBool_740A9D5546ACD584BA22D8ADAAF936E4();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_InfectedDogAnimBPV3(int32 EntryPoint);
}; // Size: 0xC08

#endif
