#ifndef UE4SS_SDK_FCheckboxControls_HPP
#define UE4SS_SDK_FCheckboxControls_HPP

struct FFCheckboxControls
{
    int32 Priority_10_E04421BD42003493FCCC7A9F81BC17F7;                               // 0x0000 (size: 0x4)
    FString Label_2_58F367ED41E6F6F389B8F2895C4D806A;                                 // 0x0008 (size: 0x10)
    bool Default_6_B88F3B3E48B114680562BBB89555AD2D;                                  // 0x0018 (size: 0x1)

}; // Size: 0x19

#endif
