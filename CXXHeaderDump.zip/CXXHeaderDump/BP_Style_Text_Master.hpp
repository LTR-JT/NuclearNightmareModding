#ifndef UE4SS_SDK_BP_Style_Text_Master_HPP
#define UE4SS_SDK_BP_Style_Text_Master_HPP

class UBP_Style_Text_Master_C : public UCommonTextStyle
{
}; // Size: 0x1B0

#endif
