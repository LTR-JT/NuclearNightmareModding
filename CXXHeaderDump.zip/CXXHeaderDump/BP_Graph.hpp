#ifndef UE4SS_SDK_BP_Graph_HPP
#define UE4SS_SDK_BP_Graph_HPP

class ABP_Graph_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCapsuleComponent* Capsule1;                                                // 0x0298 (size: 0x8)
    class UTextRenderComponent* Formulaheader;                                        // 0x02A0 (size: 0x8)
    class UTextRenderComponent* FormulaText;                                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x02B0 (size: 0x8)
    class UTextRenderComponent* Y-Min;                                                // 0x02B8 (size: 0x8)
    class UTextRenderComponent* Y-Max;                                                // 0x02C0 (size: 0x8)
    class UTextRenderComponent* X-min;                                                // 0x02C8 (size: 0x8)
    class UTextRenderComponent* X-Max;                                                // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* GraphMesh;                                            // 0x02D8 (size: 0x8)
    class UMaterial* Graph Material;                                                  // 0x02E0 (size: 0x8)
    class UMaterialInstanceDynamic* GraphMID;                                         // 0x02E8 (size: 0x8)
    FLinearColor Default Range;                                                       // 0x02F0 (size: 0x10)
    class ABP_Slider_C* X-Slider;                                                     // 0x0300 (size: 0x8)
    class ABP_Slider_C* Y-Slider;                                                     // 0x0308 (size: 0x8)
    double VariableDefault;                                                           // 0x0310 (size: 0x8)
    FText Formula;                                                                    // 0x0318 (size: 0x10)
    bool UsesVariable;                                                                // 0x0328 (size: 0x1)
    bool UsesVariable2;                                                               // 0x0329 (size: 0x1)
    char padding_0[0x6];                                                              // 0x032A (size: 0x6)
    class ABP_Slider_C* VariableSlider;                                               // 0x0330 (size: 0x8)
    class ABP_Slider_C* VariableSlider2;                                              // 0x0338 (size: 0x8)
    int32 VariableMax;                                                                // 0x0340 (size: 0x4)
    int32 SliderMax;                                                                  // 0x0344 (size: 0x4)
    bool PlayerNear;                                                                  // 0x0348 (size: 0x1)
    TEnumAsByte<BP_Graph_Enum::Type> FunctionType;                                    // 0x0349 (size: 0x1)
    bool ShowFormula;                                                                 // 0x034A (size: 0x1)
    char padding_1[0x5];                                                              // 0x034B (size: 0x5)
    FText EmptyText;                                                                  // 0x0350 (size: 0x10)
    class UMaterialInstanceDynamic* Rim_MID;                                          // 0x0360 (size: 0x8)

    void SetRange();
    void UserConstructionScript();
    void ReceiveTick(float DeltaSeconds);
    void BndEvt__Capsule1_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__Capsule1_K2Node_ComponentBoundEvent_8_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_BP_Graph(int32 EntryPoint);
}; // Size: 0x368

#endif
