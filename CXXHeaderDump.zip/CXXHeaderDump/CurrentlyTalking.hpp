#ifndef UE4SS_SDK_CurrentlyTalking_HPP
#define UE4SS_SDK_CurrentlyTalking_HPP

class UCurrentlyTalking_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* NewAnimation;                                             // 0x02E8 (size: 0x8)
    class UImage* Image_45;                                                           // 0x02F0 (size: 0x8)
    bool Reversed;                                                                    // 0x02F8 (size: 0x1)

    void Construct();
    void ExecuteUbergraph_CurrentlyTalking(int32 EntryPoint);
}; // Size: 0x2F9

#endif
