#ifndef UE4SS_SDK_FadeIn_HPP
#define UE4SS_SDK_FadeIn_HPP

class UFadeIn_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* fade;                                                     // 0x02E8 (size: 0x8)
    class UImage* Image_0;                                                            // 0x02F0 (size: 0x8)
    float Playback Speed;                                                             // 0x02F8 (size: 0x4)

    void Construct();
    void ExecuteUbergraph_FadeIn(int32 EntryPoint);
}; // Size: 0x2FC

#endif
