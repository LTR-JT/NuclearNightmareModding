#ifndef UE4SS_SDK_BTT_PlayMontage_HPP
#define UE4SS_SDK_BTT_PlayMontage_HPP

class UBTT_PlayMontage_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    bool FinishExec;                                                                  // 0x00D8 (size: 0x1)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_PlayMontage(int32 EntryPoint);
}; // Size: 0xD9

#endif
