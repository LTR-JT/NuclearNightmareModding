#ifndef UE4SS_SDK_Creature_Player_HPP
#define UE4SS_SDK_Creature_Player_HPP

class ACreature_Player_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0678 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0680 (size: 0x8)

    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_Creature_Player(int32 EntryPoint);
}; // Size: 0x688

#endif
