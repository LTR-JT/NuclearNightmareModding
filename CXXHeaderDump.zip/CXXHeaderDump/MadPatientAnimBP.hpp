#ifndef UE4SS_SDK_MadPatientAnimBP_HPP
#define UE4SS_SDK_MadPatientAnimBP_HPP

struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
    FName __NameProperty_91;                                                          // 0x0004 (size: 0x8)
    int32 __IntProperty_92;                                                           // 0x000C (size: 0x4)
    bool __BoolProperty_93;                                                           // 0x0010 (size: 0x1)
    float __FloatProperty_94;                                                         // 0x0014 (size: 0x4)
    float __FloatProperty_95;                                                         // 0x0018 (size: 0x4)
    bool __BoolProperty_96;                                                           // 0x001C (size: 0x1)
    EAnimSyncMethod __EnumProperty_97;                                                // 0x001D (size: 0x1)
    TEnumAsByte<EAnimGroupRole::Type> __ByteProperty_98;                              // 0x001E (size: 0x1)
    FName __NameProperty_99;                                                          // 0x0020 (size: 0x8)
    FName __NameProperty_100;                                                         // 0x0028 (size: 0x8)
    int32 __IntProperty_101;                                                          // 0x0030 (size: 0x4)
    FName __NameProperty_102;                                                         // 0x0034 (size: 0x8)
    FName __NameProperty_103;                                                         // 0x003C (size: 0x8)
    FAnimNodeFunctionRef __StructProperty_104;                                        // 0x0048 (size: 0x20)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;              // 0x0068 (size: 0x80)
    FAnimSubsystem_Base AnimBlueprintExtension_Base;                                  // 0x00E8 (size: 0x18)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace_1; // 0x0100 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_2; // 0x0130 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1;        // 0x0160 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_3;           // 0x0190 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_2;           // 0x01C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone_1;           // 0x01F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SpringBone;             // 0x0220 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose;          // 0x0250 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot;                   // 0x0280 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose;         // 0x02B0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1;     // 0x02E0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult;       // 0x0310 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1;     // 0x0340 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1;          // 0x0370 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace;  // 0x03A0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace_1; // 0x03D0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone;             // 0x0400 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer;       // 0x0430 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult;            // 0x0460 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine;           // 0x0490 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root;                   // 0x04C0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace;  // 0x04F0 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonFeetSolver;       // 0x0520 (size: 0x30)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_DragonSpineSolver;      // 0x0550 (size: 0x30)

}; // Size: 0x580

struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
    float __FloatProperty;                                                            // 0x0004 (size: 0x4)
    float __FloatProperty_0;                                                          // 0x0008 (size: 0x4)

}; // Size: 0xC

class UMadPatientAnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0370 (size: 0x8)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;                       // 0x0378 (size: 0xC)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;                     // 0x0388 (size: 0x8)
    FAnimSubsystemInstance AnimBlueprintExtension_Base;                               // 0x0390 (size: 0x8)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x0398 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;     // 0x03B8 (size: 0x20)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1;                            // 0x03D8 (size: 0x28)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_3;                                  // 0x0400 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_2;                                  // 0x0568 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone_1;                                  // 0x06D0 (size: 0x168)
    FAnimNode_SpringBone AnimGraphNode_SpringBone;                                    // 0x0838 (size: 0x168)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;                              // 0x09A0 (size: 0x28)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x09C8 (size: 0x48)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;                            // 0x0A10 (size: 0x80)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0A90 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0AB8 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1;                      // 0x0AE0 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0B50 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0B70 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;     // 0x0B90 (size: 0x20)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0BB0 (size: 0x128)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0CD8 (size: 0x70)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0D48 (size: 0x20)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0D68 (size: 0xC8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x0E30 (size: 0x20)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0E50 (size: 0x20)
    FAnimNode_DragonFeetSolver AnimGraphNode_DragonFeetSolver;                        // 0x0E70 (size: 0x9C0)
    FAnimNode_DragonSpineSolver AnimGraphNode_DragonSpineSolver;                      // 0x1830 (size: 0xEC0)
    class APawn* K2Node_PropertyAccess_2;                                             // 0x26F0 (size: 0x8)
    FVector K2Node_PropertyAccess;                                                    // 0x26F8 (size: 0x18)
    double Speed;                                                                     // 0x2710 (size: 0x8)
    bool ShotInLeg;                                                                   // 0x2718 (size: 0x1)
    float Alpha;                                                                      // 0x271C (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    class AMadPatent_AI_C* TryGetMadPatient();
    void BlueprintThreadSafeUpdateAnimation(float DeltaTime);
    void ExecuteUbergraph_MadPatientAnimBP(int32 EntryPoint);
}; // Size: 0x2720

#endif
