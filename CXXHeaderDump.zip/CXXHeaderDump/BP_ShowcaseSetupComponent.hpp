#ifndef UE4SS_SDK_BP_ShowcaseSetupComponent_HPP
#define UE4SS_SDK_BP_ShowcaseSetupComponent_HPP

class UBP_ShowcaseSetupComponent_C : public UActorComponent
{
    int32 Slot;                                                                       // 0x00A0 (size: 0x4)
    char padding_0[0x4];                                                              // 0x00A4 (size: 0x4)
    FString Name;                                                                     // 0x00A8 (size: 0x10)
    TArray<class ACameraActor*> ShowcaseCameras;                                      // 0x00B8 (size: 0x10)
    TArray<FFSliderControls> SliderControls;                                          // 0x00C8 (size: 0x10)
    TArray<FFTwinSliderControls> TwinSliderControls;                                  // 0x00D8 (size: 0x10)
    TArray<FFCheckboxControls> CheckboxControls;                                      // 0x00E8 (size: 0x10)
    TArray<FFButtonsControls> ButtonsControls;                                        // 0x00F8 (size: 0x10)
    TArray<FFSeparator> Separators;                                                   // 0x0108 (size: 0x10)

    void GetSeparators(TArray<FFSeparator>& Separators);
    void GetButtonListControls(TArray<FFButtonsControls>& ButtonListControls);
    void GetTwinSliderControls(TArray<FFTwinSliderControls>& TwinSliderControls);
    void GetCheckboxControls(TArray<FFCheckboxControls>& CheckboxControls);
    void GetSliderControls(TArray<FFSliderControls>& SliderControls);
    void GetShowcaseCamera(int32 Index, class ACameraActor*& Camera);
    void GetShowcaseCameraCount(int32& Count);
    void GetShowcaseSlot(int32& Slot);
    void GetShowcaseName(FString& Name);
    void GetShowcaseControls(TScriptInterface<class IBP_ShowcaseControlsInterface_C>& ControlsInterface);
}; // Size: 0x118

#endif
