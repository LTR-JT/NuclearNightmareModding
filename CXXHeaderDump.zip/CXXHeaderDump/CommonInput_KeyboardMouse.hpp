#ifndef UE4SS_SDK_CommonInput_KeyboardMouse_HPP
#define UE4SS_SDK_CommonInput_KeyboardMouse_HPP

class UCommonInput_KeyboardMouse_C : public UCommonInputBaseControllerData
{
    char padding_0[0xE8];                                                             // 0x0000 (size: 0x0)
}; // Size: 0xE8

#endif
