#ifndef UE4SS_SDK_BP_West_Bomber_B2_HPP
#define UE4SS_SDK_BP_West_Bomber_B2_HPP

class ABP_West_Bomber_B2_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0298 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x02A0 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x02A8 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x02B0 (size: 0x8)
    float Timeline_NewTrack_0_40A3F1D5499815311A3CB59D159A7723;                       // 0x02B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline__Direction_40A3F1D5499815311A3CB59D159A7723; // 0x02BC (size: 0x1)
    class UTimelineComponent* Timeline;                                               // 0x02C0 (size: 0x8)
    TArray<class UMaterialInstanceDynamic*> BodyMaterial;                             // 0x02C8 (size: 0x10)
    class UBPA_West_Bomber_B2_C* AnimInstance;                                        // 0x02D8 (size: 0x8)
    float Interp Speed;                                                               // 0x02E0 (size: 0x4)
    FVector Location;                                                                 // 0x02E8 (size: 0x18)

    void UserConstructionScript();
    void Timeline__FinishedFunc();
    void Timeline__UpdateFunc();
    void ReceiveBeginPlay();
    void SetLightsEmissivity(double LightEmissivity);
    void SetShowDamaged(bool ShowDamaged);
    void SetRudderLeftWing(double RudderLeftWingAngle);
    void SetRearWheelLSuspension(double RearWheelLSuspension);
    void SetRearWheelRSuspension(double RearWheelRSuspension);
    void SetRudderRightWing(double SetRudderRightWing);
    void SetInboardEvelons(double InboardEvelonsAngle);
    void SetMidEvelons(double MidEvelonsAngle);
    void SetOutboardEvelons(double OutBoardEvelonsangle);
    void SetBombHatchLeft(double BombHatchLOpen);
    void SetBombHatchRight(double BombHatchROpen);
    void RetractFrontwheel(double FrontWheelPostion);
    void RetractRearLWheel(double RearWheelLPosition);
    void RetractRearRWheel(double RearWheelLPosition);
    void SetFrontWheelSuspension(double RearWheelLSuspension);
    void OpenEngineCoverLeft1(double EngineCoverLeft1Angle);
    void OpenEngineCoverLeft2(double EngineCoverLeft2Angle);
    void OpenEngineCoverRight1(double EngineCoverRight1Angle);
    void OpenEngineCoverRight2(double EngineCoverRight2Angle);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_West_Bomber_B2(int32 EntryPoint);
}; // Size: 0x300

#endif
