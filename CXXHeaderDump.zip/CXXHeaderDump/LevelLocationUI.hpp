#ifndef UE4SS_SDK_LevelLocationUI_HPP
#define UE4SS_SDK_LevelLocationUI_HPP

class ULevelLocationUI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button_28;                                                         // 0x02E8 (size: 0x8)
    class UImage* Image;                                                              // 0x02F0 (size: 0x8)
    FText Name;                                                                       // 0x02F8 (size: 0x10)
    FVector WorldLocation;                                                            // 0x0308 (size: 0x18)
    class ABP_FirstPersonCharacter_C* Character;                                      // 0x0320 (size: 0x8)
    class ALevelWaypointActor_C* LevelWaypoint;                                       // 0x0328 (size: 0x8)
    bool Deleted;                                                                     // 0x0330 (size: 0x1)
    bool Selected;                                                                    // 0x0331 (size: 0x1)

    FLinearColor GetColorAndOpacity();
    class UWidget* GetToolTipWidget_0();
    class UWidget* GetToolTipWidget();
    FText GetText();
    void Construct();
    void BndEvt__LevelLocationUI_Button_28_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_LevelLocationUI(int32 EntryPoint);
}; // Size: 0x332

#endif
