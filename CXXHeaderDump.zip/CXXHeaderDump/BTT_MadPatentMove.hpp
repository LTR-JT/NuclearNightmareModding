#ifndef UE4SS_SDK_BTT_MadPatentMove_HPP
#define UE4SS_SDK_BTT_MadPatentMove_HPP

class UBTT_MadPatentMove_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    bool FinishedMove;                                                                // 0x00B0 (size: 0x1)

    void OnFail_3918F75B430E19AB781FF7BA11F3548B(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_3918F75B430E19AB781FF7BA11F3548B(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_0F9B073A472EA3C4EE96069C5369C36C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_0F9B073A472EA3C4EE96069C5369C36C(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_6755B3E0449824EC8C6CB783EC177FE0(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_6755B3E0449824EC8C6CB783EC177FE0(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTT_MadPatentMove(int32 EntryPoint);
}; // Size: 0xB1

#endif
