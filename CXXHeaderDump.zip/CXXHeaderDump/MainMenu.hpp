#ifndef UE4SS_SDK_MainMenu_HPP
#define UE4SS_SDK_MainMenu_HPP

class UMainMenu_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UWidgetAnimation* SelectJoin;                                               // 0x02E8 (size: 0x8)
    class UWidgetAnimation* SelectQuit;                                               // 0x02F0 (size: 0x8)
    class UWidgetAnimation* SelectOptions;                                            // 0x02F8 (size: 0x8)
    class UWidgetAnimation* SelectPlay;                                               // 0x0300 (size: 0x8)
    class UButton* DiscordButton;                                                     // 0x0308 (size: 0x8)
    class UButton* DiscordButton_1;                                                   // 0x0310 (size: 0x8)
    class UImage* Gradient_Left;                                                      // 0x0318 (size: 0x8)
    class UImage* Gradient_Left_1;                                                    // 0x0320 (size: 0x8)
    class UImage* Image;                                                              // 0x0328 (size: 0x8)
    class UImage* Image_0;                                                            // 0x0330 (size: 0x8)
    class UImage* Image_304;                                                          // 0x0338 (size: 0x8)
    class UMatchMakingMenu_C* MatchMakingMenu;                                        // 0x0340 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master;                                      // 0x0348 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_1;                                    // 0x0350 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_2;                                    // 0x0358 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_3;                                    // 0x0360 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_4;                                    // 0x0368 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_5;                                    // 0x0370 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_6;                                    // 0x0378 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_7;                                    // 0x0380 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_8;                                    // 0x0388 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_89;                                   // 0x0390 (size: 0x8)
    class UUI_Button_Master_C* UI_Button_Master_104;                                  // 0x0398 (size: 0x8)
    class UUI_ClothingMenu_C* UI_ClothingMenu;                                        // 0x03A0 (size: 0x8)
    class UUI_Emote_Menu_C* UI_Emote_Menu;                                            // 0x03A8 (size: 0x8)
    class UVerticalBox* VerticalBox_43;                                               // 0x03B0 (size: 0x8)
    class UVerticalBox* VerticalBox_104;                                              // 0x03B8 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_0;                                          // 0x03C0 (size: 0x8)
    class UWidgetSwitcher* WidgetSwitcher_1;                                          // 0x03C8 (size: 0x8)
    FMainMenu_CGotoLobby GotoLobby;                                                   // 0x03D0 (size: 0x10)
    void GotoLobby();
    class UBP_GameInstance_C* GameInstance;                                           // 0x03E0 (size: 0x8)
    FMainMenu_CGotoClothes GotoClothes;                                               // 0x03E8 (size: 0x10)
    void GotoClothes();
    FMainMenu_CGotoMainMenu GotoMainMenu;                                             // 0x03F8 (size: 0x10)
    void GotoMainMenu();

    FEventReply OnMouseButtonUp(FGeometry MyGeometry, const FPointerEvent& MouseEvent);
    void Construct();
    void BndEvt__MainMenu_UI_Button_Master_K2Node_ComponentBoundEvent_11_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_1_K2Node_ComponentBoundEvent_12_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_3_K2Node_ComponentBoundEvent_13_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_2_K2Node_ComponentBoundEvent_14_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_6_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_5_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_4_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_89_K2Node_ComponentBoundEvent_3_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BackButton();
    void BackButton2();
    void BndEvt__MainMenu_UI_Button_Master_104_K2Node_ComponentBoundEvent_4_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_7_K2Node_ComponentBoundEvent_5_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void BndEvt__MainMenu_UI_Button_Master_8_K2Node_ComponentBoundEvent_6_CommonButtonBaseClicked__DelegateSignature(class UCommonButtonBase* Button);
    void GoBack();
    void FindControllerGamepadFocus();
    void Exit();
    void BndEvt__MainMenu_DiscordButton_1_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__MainMenu_DiscordButton_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_MainMenu(int32 EntryPoint);
    void GotoMainMenu__DelegateSignature();
    void GotoClothes__DelegateSignature();
    void GotoLobby__DelegateSignature();
}; // Size: 0x408

#endif
