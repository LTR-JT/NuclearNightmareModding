namespace ENiagaraRestitutionMergeType {
    enum Type {
        NewEnumerator3 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        ENiagaraRestitutionMergeType_MAX = 4,
    };
}

