#ifndef UE4SS_SDK_BP_NiceColorWheel_SaveGame_HPP
#define UE4SS_SDK_BP_NiceColorWheel_SaveGame_HPP

class UBP_NiceColorWheel_SaveGame_C : public USaveGame
{
    FString AllColorWheelAndHandleHSV_SaveData;                                       // 0x0028 (size: 0x10)

}; // Size: 0x38

#endif
