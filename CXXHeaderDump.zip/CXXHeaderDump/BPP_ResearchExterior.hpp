#ifndef UE4SS_SDK_BPP_ResearchExterior_HPP
#define UE4SS_SDK_BPP_ResearchExterior_HPP

class ABPP_ResearchExterior_C : public APackedLevelActor
{
    class UInstancedStaticMeshComponent* InstancedStaticMesh1;                        // 0x0330 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0338 (size: 0x8)

}; // Size: 0x340

#endif
