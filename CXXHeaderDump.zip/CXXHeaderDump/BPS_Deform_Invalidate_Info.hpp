#ifndef UE4SS_SDK_BPS_Deform_Invalidate_Info_HPP
#define UE4SS_SDK_BPS_Deform_Invalidate_Info_HPP

struct FBPS_Deform_Invalidate_Info
{
    FVector Origin_5_E201A62846539043DF678FA29707A8FA;                                // 0x0000 (size: 0x18)
    float Radius_2_E6173387404B40A1079013B238BB660C;                                  // 0x0018 (size: 0x4)

}; // Size: 0x1C

#endif
