#ifndef UE4SS_SDK_InterchangeExport_HPP
#define UE4SS_SDK_InterchangeExport_HPP

class UInterchangeTextureWriter : public UInterchangeWriterBase
{
}; // Size: 0x28

#endif
