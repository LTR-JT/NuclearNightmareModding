namespace HuskyState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        HuskyState_MAX = 2,
    };
}

