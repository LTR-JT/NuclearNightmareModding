#ifndef UE4SS_SDK_BP_PowerConsumer_HPP
#define UE4SS_SDK_BP_PowerConsumer_HPP

class ABP_PowerConsumer_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    double PowerConsumption;                                                          // 0x02A0 (size: 0x8)
    bool Active;                                                                      // 0x02A8 (size: 0x1)

    void PassiveInteraction(FText& ActorName);
    void CheckActive(bool& Active?, double& Amount);
    void SecondaryInteraction();
    void ConsumePower();
    void PrimaryInteraction(class ABP_FirstPersonCharacter_C* Character);
    void ExecuteUbergraph_BP_PowerConsumer(int32 EntryPoint);
}; // Size: 0x2A9

#endif
