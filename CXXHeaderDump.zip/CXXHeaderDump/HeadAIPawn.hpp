#ifndef UE4SS_SDK_HeadAIPawn_HPP
#define UE4SS_SDK_HeadAIPawn_HPP

class AHeadAIPawn_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0670 (size: 0x8)
    class UNiagaraComponent* Niagara1;                                                // 0x0678 (size: 0x8)
    class UDLWE_Interaction_C* DLWE_Interaction;                                      // 0x0680 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0688 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0690 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0698 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x06A0 (size: 0x8)
    class UMonster_Inventory_C* Inv;                                                  // 0x06A8 (size: 0x8)
    bool CanSpawn;                                                                    // 0x06B0 (size: 0x1)
    class UMonsterRespawn_C* RespawnHud;                                              // 0x06B8 (size: 0x8)

    void InpActEvt_IA_Move_K2Node_EnhancedInputActionEvent_6(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Look_K2Node_EnhancedInputActionEvent_5(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Jump_K2Node_EnhancedInputActionEvent_4(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_UseItem_K2Node_EnhancedInputActionEvent_3(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_HideHud_K2Node_EnhancedInputActionEvent_2(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Reload_K2Node_EnhancedInputActionEvent_1(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void InpActEvt_IA_Reload_K2Node_EnhancedInputActionEvent_0(FInputActionValue ActionValue, float ElapsedTime, float TriggeredTime, const class UInputAction* SourceAction);
    void ReceiveBeginPlay();
    void ReceivePossessed(class AController* NewController);
    void SpawnFullGrown(class AController* Target);
    void SpawnFullGrownAll(class AController* Target);
    void Finished();
    void RPCSetLocation(FVector Loc);
    void RPCSetLocationAll(FVector Loc);
    void ExecuteUbergraph_HeadAIPawn(int32 EntryPoint);
}; // Size: 0x6C0

#endif
