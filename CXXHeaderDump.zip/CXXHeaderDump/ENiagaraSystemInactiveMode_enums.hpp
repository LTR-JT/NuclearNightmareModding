namespace ENiagaraSystemInactiveMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraSystemInactiveMode_MAX = 2,
    };
}

