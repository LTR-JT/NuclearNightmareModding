#ifndef UE4SS_SDK_HuskyInteract_HPP
#define UE4SS_SDK_HuskyInteract_HPP

class UHuskyInteract_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02E0 (size: 0x8)
    class UButton* Button;                                                            // 0x02E8 (size: 0x8)
    class UButton* Button_0;                                                          // 0x02F0 (size: 0x8)
    class UButton* Button_1;                                                          // 0x02F8 (size: 0x8)
    class UButton* Button_2;                                                          // 0x0300 (size: 0x8)
    class URetainerBox* RetainerBox_0;                                                // 0x0308 (size: 0x8)
    class UTextBlock* TextBlock;                                                      // 0x0310 (size: 0x8)
    class UTextBlock* TextBlock_1;                                                    // 0x0318 (size: 0x8)
    class UTextBlock* TextBlock_2;                                                    // 0x0320 (size: 0x8)
    class UTextBlock* TextBlock_32;                                                   // 0x0328 (size: 0x8)
    FHuskyInteract_CReturnState ReturnState;                                          // 0x0330 (size: 0x10)
    void ReturnState(TEnumAsByte<HuskyBehavior::Type> State);
    TEnumAsByte<HuskyBehavior::Type> InValue;                                         // 0x0340 (size: 0x1)
    class AHusky_AI_C* HuskyRef;                                                      // 0x0348 (size: 0x8)

    FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent);
    void Construct();
    void BndEvt__HuskyInteract_Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__HuskyInteract_Button_2_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__HuskyInteract_Button_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__HuskyInteract_Button_1_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_HuskyInteract(int32 EntryPoint);
    void ReturnState__DelegateSignature(TEnumAsByte<HuskyBehavior::Type> State);
}; // Size: 0x350

#endif
