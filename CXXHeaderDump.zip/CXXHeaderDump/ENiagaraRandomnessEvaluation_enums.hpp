namespace ENiagaraRandomnessEvaluation {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        ENiagaraRandomnessEvaluation_MAX = 2,
    };
}

