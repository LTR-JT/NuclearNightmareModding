#ifndef UE4SS_SDK_BP_Snowmobile_Wheel_Back_Chaos_HPP
#define UE4SS_SDK_BP_Snowmobile_Wheel_Back_Chaos_HPP

class UBP_Snowmobile_Wheel_Back_Chaos_C : public UChaosVehicleWheel
{
}; // Size: 0x2E0

#endif
