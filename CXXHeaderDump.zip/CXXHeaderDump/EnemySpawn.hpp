#ifndef UE4SS_SDK_EnemySpawn_HPP
#define UE4SS_SDK_EnemySpawn_HPP

class AEnemySpawn_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0290 (size: 0x8)

}; // Size: 0x298

#endif
