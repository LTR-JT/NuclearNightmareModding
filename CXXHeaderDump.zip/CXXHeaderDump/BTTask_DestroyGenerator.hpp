#ifndef UE4SS_SDK_BTTask_DestroyGenerator_HPP
#define UE4SS_SDK_BTTask_DestroyGenerator_HPP

class UBTTask_DestroyGenerator_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector Key;                                                       // 0x00B0 (size: 0x28)
    FBlackboardKeySelector bool;                                                      // 0x00D8 (size: 0x28)

    void OnFail_0C045C044C1BA6EFEA8107B809746DB4(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_0C045C044C1BA6EFEA8107B809746DB4(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_DestroyGenerator(int32 EntryPoint);
}; // Size: 0x100

#endif
