#ifndef UE4SS_SDK_BP_Snowmobile_Destroyed_HPP
#define UE4SS_SDK_BP_Snowmobile_Destroyed_HPP

class ABP_Snowmobile_Destroyed_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USkeletalMeshComponent* Body;                                               // 0x0298 (size: 0x8)
    class UAudioComponent* SC_Fire_burning;                                           // 0x02A0 (size: 0x8)
    class UParticleSystemComponent* PS_Fire_2;                                        // 0x02A8 (size: 0x8)
    class UParticleSystemComponent* PS_Fire;                                          // 0x02B0 (size: 0x8)
    class UParticleSystemComponent* PS_Explosion;                                     // 0x02B8 (size: 0x8)
    bool Wreck_destroyed_?;                                                           // 0x02C0 (size: 0x1)

    void ReceiveTick(float DeltaSeconds);
    void CE_Destroy_Wreck();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Snowmobile_Destroyed(int32 EntryPoint);
}; // Size: 0x2C1

#endif
